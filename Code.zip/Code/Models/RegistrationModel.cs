﻿namespace AIS.Models
{
    interface IEmplCreatorRegistration
    {
        string CreateTableRegistration();
    }
    interface IEmplInsertRegistration
    {
        string InsertDataRegistration(InsertArgRegistration insertArgRegistration);
    }

    interface IEpmlUpdateRegistration
    {
        string UpdateDataRegistration(UpdateArgRegistration updateArgRegistration);
    }

    internal class RegistrationModel : IEmplCreatorRegistration, IEmplInsertRegistration, IEpmlUpdateRegistration
    {
        public static string USER_TABLE_User = "usersLogin"; // Название таблицы для регистрации пользователя
        public static string ID = "id";
        public static string NAME_USER = "nameUser"; // Имя
        public static string SURNAME_USER = "surnameUser"; // Фамилия
        public static string MIDDLE_NAME = "middleName"; // Отчество
        public static string DISCRIPTOR_NAME = "discriptor"; // Имя учётной зависи Виндовс
        public static string NAME_ORGANIZATION = OrganizationModel.NAME_ORGANIZATION;
        public static string NAME_OTDEL = "nameOtdel"; // Отдел
        public static string E_MAIL = "email"; // Электронная почта
        public static string PASSWORD = "password"; // Пароль
        public static string HASHPASSWORD = "hashpassword"; // Хеш пароля
        public static string NAME_STAFF = "nameStaff"; // Должность
        public static string USER_TABLE_Organization = OrganizationModel.USER_TABLE_Organization;
        public static string USER_TABLE_OTDEL = "otdels";
        public static string USER_TABLE_STAFF = "staff";
        public static string NAME_ROLE = RoleModel.NAME_ROLE;



        // Запрос на создание таблицы регистрации пользователя
        public string CreateTableRegistration()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_User + @"')
                        BEGIN 
                            CREATE TABLE " + USER_TABLE_User + @" (                                  
                            " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                            " + SURNAME_USER + @" VARCHAR(20) NOT NULL,
                            " + NAME_USER + @" VARCHAR(20) NOT NULL,
                            " + MIDDLE_NAME + @" VARCHAR(20),
                            " + NAME_ORGANIZATION + @" VARCHAR(30) NOT NULL,
                            " + NAME_OTDEL + @" VARCHAR(25) NOT NULL,
                            " + NAME_STAFF + @" VARCHAR(40) NOT NULL,
                            " + E_MAIL + @" VARCHAR(35) NOT NULL UNIQUE,
                            " + PASSWORD + @" VARCHAR(20) NOT NULL,                         
                            " + NAME_ROLE + @" VARCHAR(25) NOT NULL)                         
                        END";
        }

        // Запрос на добавление регистрации пользователя
        public string InsertDataRegistration(InsertArgRegistration insertArgRegistration)
        {
            return "INSERT INTO " +
                    USER_TABLE_User + "(" +
                    SURNAME_USER + "," +
                    NAME_USER + "," +
                    MIDDLE_NAME + "," +
                    NAME_ORGANIZATION + "," +
                    NAME_OTDEL + "," +
                    NAME_STAFF + "," +
                    E_MAIL + "," +
                    PASSWORD + "," +
                    NAME_ROLE + ") " + $"VALUES ('{insertArgRegistration.surname}', " +
                                               $"'{insertArgRegistration.name}'," +
                                               $"'{insertArgRegistration.middleName}'," +
                                               $"'{insertArgRegistration.nameOrganization}'," +
                                               $"'{insertArgRegistration.otdel}'," +
                                               $"'{insertArgRegistration.nameStaff}'," +
                                               $"'{insertArgRegistration.email}'," +
                                               $"'{insertArgRegistration.password}'," +
                                               $"'{insertArgRegistration.nameRole}')";
        }

        public string UpdateDataRegistration(UpdateArgRegistration updateArgRegistration)
        {
            return $"UPDATE {updateArgRegistration.nameTable} SET " +
                                                  $"{SURNAME_USER} = '{updateArgRegistration.surname}'," +
                                                  $"{NAME_USER} = '{updateArgRegistration.name}'," +
                                                  $"{MIDDLE_NAME} = '{updateArgRegistration.middleName}'," +
                                                  $"{NAME_ORGANIZATION} = '{updateArgRegistration.nameOrganization}'," +
                                                  $"{NAME_OTDEL} = '{updateArgRegistration.otdel}'," +
                                                  $"{NAME_STAFF} = '{updateArgRegistration.nameStaff}'," +
                                                  $"{E_MAIL} = '{updateArgRegistration.email}'," +
                                                  $"{PASSWORD} = '{updateArgRegistration.password}'," +
                                                  $"{NAME_ROLE} = '{updateArgRegistration.nameRole}' WHERE {ID} = {updateArgRegistration.id}";
        }
    }

    class InsertArgRegistration
    {
        public string surname { get; init; }
        public string name { get; init; }
        public string middleName { get; init; }
        public string nameOrganization { get; init; }
        public string otdel { get; init; }
        public string nameStaff { get; init; }
        public string email { get; init; }
        public string password { get; init; }
        public string nameRole { get; init; }
    }

    class UpdateArgRegistration
    {
        public string nameTable { get; init; }
        public string surname { get; init; }
        public string name { get; init; }
        public string middleName { get; init; }
        public string nameOrganization { get; init; }
        public string otdel { get; init; }
        public string nameStaff { get; init; }
        public string email { get; init; }
        public string password { get; init; }
        public string nameRole { get; init; }
        public string id { get; init; }

    }

}
