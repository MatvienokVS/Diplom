﻿namespace AIS.Models
{
    internal class AddOperationModel
    {
        public static string USER_TABLE_KASSA = KassaModel.USER_TABLE_KASSA;
        public static string DATA_OPERATION = KassaModel.DATA_OPERATION;
        public static string NAME_ARTICLE = ArticleBDDSModel.NAME_ARTICLE;
        public static string SURNAME_USER = EmployeesModel.SURNAME_USER;
        public static string PAYMENT = KassaModel.PAYMENT; // Назначение платежа
        public static string FORM_PAY = FormPayModel.NAME_FORM_PAY;
        public static string SUMM = KassaModel.SUMM;
        public static string TYPE_OPERATION = KassaModel.TYPE_OPERATION;
        public static string DISCRIPTOR_NAME = KassaModel.DISCRIPTOR_NAME;
        public static string NAME_ORGANIZATION = OrganizationModel.NAME_ORGANIZATION;
        public static string NAME_OTDEL = OtdelModel.NAME_OTDEL;
        public static string LINK_DOCUMENT = "linkDocument";


        // Запрос на получение типа операции 
        public static string ShowType(string nameTable, string typeOperation, string nameArticle)
        {
            return $"SELECT {typeOperation} FROM {nameTable} WHERE nameArticle = '{nameArticle}'";
        }

    }
}
