﻿namespace AIS.Models
{
    interface IEmplCreatorRoleOrganizationAccess
    {
        string CreateTableRoleOrganizationAccess();
    }

    interface IEmplInsertRoleOrganizationAccess
    {
        string InsertDataRoleOrganizationAccess(InsertArgRoleOrganizationAccess insertArgRoleOrganizationAccess);
    }

    interface IEmplUpdateRoleOrganizationAccess
    {
        string UpdateDataRoleOrganizationAccess(UpdateArgRoleOrganizationAccess updateArgRoleOrganizationAccess);
    }

    internal class RoleAccessOrganizationModel : IEmplCreatorRoleOrganizationAccess, IEmplInsertRoleOrganizationAccess, IEmplUpdateRoleOrganizationAccess
    {
        public static string USER_TABLE_ROLE_ORGANIZATION_ACCESS = "roleOrganizationAccess";
        public static string ID = "id";
        public static string ID_ORGANIZATION = "idOrganization";
        public static string ID_ROLES = "idRoles";

        public string CreateTableRoleOrganizationAccess()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_ROLE_ORGANIZATION_ACCESS + @"')
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_ROLE_ORGANIZATION_ACCESS + @" (                                  
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + ID_ORGANIZATION + @" VARCHAR(30) NOT NULL,
                        " + ID_ROLES + @" VARCHAR(30) NOT NULL)                       
                    END";
        }

        public string InsertDataRoleOrganizationAccess(InsertArgRoleOrganizationAccess insertArgRoleOrganizationAccess)
        {
            return @$"INSERT INTO {insertArgRoleOrganizationAccess.nameTable} ({ID_ORGANIZATION}, 
                                  {ID_ROLES}) VALUES ('{insertArgRoleOrganizationAccess.id_organization}',
                                  '{insertArgRoleOrganizationAccess.id_role}')";
        }

        public string UpdateDataRoleOrganizationAccess(UpdateArgRoleOrganizationAccess updateArgRoleOrganizationAccess)
        {
            return @$"UPDATE {updateArgRoleOrganizationAccess.nameTable} SET 
                                                            {ID_ORGANIZATION} = '{updateArgRoleOrganizationAccess.id_organization}',
                                                            {ID_ROLES} = '{updateArgRoleOrganizationAccess.id_role}' 
                                                             WHERE 
                                                            {ID} = {updateArgRoleOrganizationAccess.id}";
        }

    }
    class InsertArgRoleOrganizationAccess
    {
        public string nameTable { get; init; }
        public string id_organization { get; init; }
        public string id_role { get; init; }

    }

    class UpdateArgRoleOrganizationAccess
    {
        public string id { get; init; }
        public string nameTable { get; init; }
        public string id_organization { get; init; }
        public string id_role { get; init; }
    }
}
