﻿namespace AIS.Models
{

    interface IEmplCreatorRole
    {
        string CreateTableRole();
    }

    interface IEmplInsertRole
    {
        string InsertDataRole(InsertArgRole insertArgRole);
    }

    interface IEmplUpdateRole
    {
        string UpdateDateRole(UpdateArgRole updateArgRole);
    }


    internal class RoleModel : IEmplUpdateRole, IEmplInsertRole, IEmplCreatorRole
    {
        public static string USER_TABLE_ROLE = "role"; // Название таблицы прав доступа
        public static string ID = "id";
        public static string NAME_ROLE = "nameRole"; // Наименование роли
        public static string NAME_OTDEL = OtdelModel.NAME_OTDEL;

        // Запрос на создание таблицы ролей
        public string CreateTableRole()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_ROLE + @"')
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_ROLE + @" (                                  
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + NAME_ROLE + @" VARCHAR(30) NOT NULL)                         
                    END";
        }

        public string InsertDataRole(InsertArgRole insertArgRole)
        {
            return $"INSERT INTO {insertArgRole.nameTable} ({NAME_ROLE}) VALUES ('{insertArgRole.role}')";
        }

        public string UpdateDateRole(UpdateArgRole updateArgRole)
        {
            return $"UPDATE {updateArgRole.nameTable} SET {NAME_ROLE} = '{updateArgRole.nameRole}' WHERE {ID} = {updateArgRole.id}";
        }

    }
    class InsertArgRole
    {
        public string nameTable { get; init; }
        public string role { get; init; }

    }
    class UpdateArgRole
    {
        public string nameTable { get; init; }
        public string nameRole { get; init; }
        public string id { get; init; }
    }

}
