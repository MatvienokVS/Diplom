﻿namespace AIS.Models
{
    interface IEmplCreatorMotivation
    {
        string CreateTableMotivation();
    }

    interface IEmplInsertMotivation
    {
        string InsertMotivation(InsertArgMotivation insertArgMotivation);
    }
    interface IEmplUpdateMotivation
    {
        string UpdateMotivation(UpdateArgMotivation updateArgMotivation);
    }

    internal class MotivationModel : IEmplCreatorMotivation, IEmplInsertMotivation, IEmplUpdateMotivation
    {
        public static string USER_TABLE_MOTIVATION = "motivation"; // Название таблицы мотивация
        public static string ID = RegistrationModel.ID;
        public static string NAME_OTDEL = OtdelModel.NAME_OTDEL; // Отдел
        public static string NAME_STAFF = StaffModel.NAME_STAFF; // Должность
        public static string NAME_ORGANIZATION = OrganizationModel.NAME_ORGANIZATION;
        public static string OKLAD = "oklad";
        public static string PERSENT_NALICHIE = "persentNalichie";
        public static string PERSENT_ZAKAZ = "persentZakaz";
        public static string PERSENT_SOPYTKA = "persentSopytka";
        public static string KPI_ONE = "kpiOne";
        public static string KPI_TWO = "kpiTwo";

        public static string KRITERIY_1 = "kriteriy1";
        public static string KRITERIY_2 = "kriteriy2";
        public static string KRITERIY_3 = "kriteriy3";
        public static string KRITERIY_4 = "kriteriy4";
        public static string KRITERIY_5 = "kriteriy5";
        public static string KRITERIY_6 = "kriteriy6";

        public string CreateTableMotivation() // создание таблицы мотивация
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_MOTIVATION + @"')
                        BEGIN 
                            CREATE TABLE " + USER_TABLE_MOTIVATION + @" (                                  
                            " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                            " + NAME_ORGANIZATION + @" VARCHAR(25) NOT NULL,
                            " + NAME_OTDEL + @" VARCHAR(30) NOT NULL,
                            " + NAME_STAFF + @" VARCHAR(30) NOT NULL,
                            " + OKLAD + @" DECIMAL(18, 2) NOT NULL,
                            " + KPI_ONE + @" DECIMAL(18, 2) NOT NULL,
                            " + KPI_TWO + @" DECIMAL(18, 2) NOT NULL,
                            " + PERSENT_NALICHIE + @" DECIMAL(5, 2) NOT NULL,
                            " + PERSENT_ZAKAZ + @" DECIMAL(5, 2) NOT NULL,
                            " + PERSENT_SOPYTKA + @" DECIMAL(5, 2) NOT NULL)                                                 
                        END";
        }

        public string InsertMotivation(InsertArgMotivation insertArgMotivation)
        {
            return "INSERT INTO " +
                    USER_TABLE_MOTIVATION + "(" +
                    NAME_ORGANIZATION + "," +
                    NAME_OTDEL + "," +
                    NAME_STAFF + "," +
                    OKLAD + "," +
                    KPI_ONE + "," +
                    KPI_TWO + "," +
                    PERSENT_NALICHIE + "," +
                    PERSENT_ZAKAZ + "," +
                    PERSENT_SOPYTKA + ") " + $"VALUES ('{insertArgMotivation.nameOrganization}'," +
                                                    $"'{insertArgMotivation.nameOtdel}'," +
                                                    $"'{insertArgMotivation.nameStaff}'," +
                                                    $"'{insertArgMotivation.oklad}'," +
                                                    $"'{insertArgMotivation.kpiOne}'," +
                                                    $"'{insertArgMotivation.kpiTwo}'," +
                                                    $"'{insertArgMotivation.persentNalichie}'," +
                                                    $"'{insertArgMotivation.persentZakaz}'," +
                                                    $"'{insertArgMotivation.persentSopytka}')";
        }

        public string UpdateMotivation(UpdateArgMotivation updateArgMotivation)
        {
            return $"UPDATE {updateArgMotivation.nameTable} SET " +                                                 
                                                  $"{NAME_ORGANIZATION} = '{updateArgMotivation.nameOrganization}'," +
                                                  $"{NAME_OTDEL} = '{updateArgMotivation.nameOtdel}'," +
                                                  $"{NAME_STAFF} = '{updateArgMotivation.nameStaff}'," +
                                                  $"{OKLAD} = '{updateArgMotivation.oklad}'," +
                                                  $"{KPI_ONE} = '{updateArgMotivation.kpiOne}'," +
                                                  $"{KPI_TWO} = '{updateArgMotivation.kpiTwo}'," +
                                                  $"{PERSENT_NALICHIE} = '{updateArgMotivation.persentNalichie}'," +
                                                  $"{PERSENT_ZAKAZ} = '{updateArgMotivation.persentZakaz}'," +
                                                  $"{PERSENT_SOPYTKA} = '{updateArgMotivation.persentSopytka}' WHERE {ID} = {updateArgMotivation.id}";
        }
    }

    class InsertArgMotivation
    {
        public string nameOrganization { get; init; }
        public string nameOtdel { get; init; }
        public string nameStaff { get; init; }
        public string oklad { get; init; }
        public string kpiOne { get; init; }
        public string kpiTwo { get; init; }
        public string persentNalichie { get; init; }
        public string persentZakaz { get; init; }
        public string persentSopytka { get; init; }
    } 
    class UpdateArgMotivation
    {
        public string nameTable { get; init; }
        public string nameOrganization { get; init; }
        public string nameOtdel { get; init; }
        public string nameStaff { get; init; }
        public string oklad { get; init; }
        public string kpiOne { get; init; }
        public string kpiTwo { get; init; }
        public string persentNalichie { get; init; }
        public string persentZakaz { get; init; }
        public string persentSopytka { get; init; }
        public string id { get; init; }
    }
}
