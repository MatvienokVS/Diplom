﻿using AIS.Forms;

namespace AIS.Models
{
    interface IEmplCreatorKassa
    {
        string CreateTableKassa();
    }

    interface IEmplInsertAddOperation
    {
        string InsertOperation(InsertArgAddOperation insertArgAddOperation);
    }
    interface IEmplUpdateOperation
    {
        string UpdateOperation(UpdateArgOperation updateArgOperation);
    }

    internal class KassaModel() : IEmplInsertAddOperation, IEmplUpdateOperation, IEmplCreatorKassa
    {
        public static string USER_TABLE_KASSA = "kassa";
        public static string ID = "id";
        public static string DATA_OPERATION = "dataOperation";
        public static string NAME_ARTICLE = ArticleBDDSModel.NAME_ARTICLE;
        public static string SURNAME_USER = RegistrationModel.SURNAME_USER;
        public static string PAYMENT = "payment";
        public static string FORM_PAY = "formPay";
        public static string SUMM = "summ";
        public static string TYPE_OPERATION = "typeOperation";
        public static string DISCRIPTOR_NAME = RegistrationModel.DISCRIPTOR_NAME;
        public static string NAME_ORGANIZATION = OrganizationModel.NAME_ORGANIZATION; 
        public static string NAME_OTDEL = "nameOtdel"; // Отдел
        public static string ARTICLE_BDDS = ArticleBDDSModel.ARTICLE_BDDS;
        public static string LINK_DOCUMENT = "linkDocument";
        public static string ROLE= RoleModel.NAME_ROLE;



        // Запрос на получение всех строк в таблице с учетом заданного фильтра
        public static string ShowAllStringFromTable(string nameTable,
                                                    string periodStart,
                                                    string periodStop,
                                                    string dataOperation,
                                                    string search,
                                                    string nameOrganization,
                                                    string nameOtdel,
                                                    string role)

        {
            var star = @$"{ID},
                          {DATA_OPERATION},
                          {NAME_ARTICLE},
                          {SURNAME_USER},
                          {PAYMENT},
                          {SUMM},
                          {TYPE_OPERATION},
                          {FORM_PAY},
                          {NAME_ORGANIZATION},
                          {NAME_OTDEL},
                          {ARTICLE_BDDS}";
            var query = $"SELECT {star} FROM {nameTable} WHERE ({NAME_ARTICLE} LIKE '%{search}%' OR " +
                                                    $"{SURNAME_USER} LIKE '%{search}%' OR " +
                                                    $"{DISCRIPTOR_NAME} LIKE '%{search}%' OR " +
                                                    $"{PAYMENT} LIKE '%{search}%' OR " +
                                                    $"{SUMM} LIKE '%{search}%' OR " +
                                                    $"{TYPE_OPERATION} LIKE '%{search}%' OR " +                                             
                                                    $"{ARTICLE_BDDS} LIKE '%{search}%') AND " +
                                                    $"({NAME_OTDEL} LIKE '%{nameOtdel}%' AND " +
                                                    $"{NAME_ORGANIZATION} LIKE '%{nameOrganization}%') AND " +
                                                    $" {ROLE} = '{role}' AND " +
                                                    $" {DATA_OPERATION} >= '{periodStart}' AND " +
                                                    $" {DATA_OPERATION} <= '{periodStop}' ";

            return $"{query} ORDER BY {dataOperation}";                
        }

        // Запрос на создание таблицы операции касса
        public string CreateTableKassa()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_KASSA + @"')
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_KASSA + @" (                                  
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + DATA_OPERATION + @" DATE NOT NULL,
                        " + NAME_ARTICLE + @" VARCHAR(40) NOT NULL,
                        " + SURNAME_USER + @" VARCHAR(30) NOT NULL,
                        " + PAYMENT + @" VARCHAR(210) NOT NULL,
                        " + FORM_PAY + @" VARCHAR(15) NOT NULL,
                        " + SUMM + @" DECIMAL(18, 2) NOT NULL,
                        " + TYPE_OPERATION + @" VARCHAR(15) NOT NULL,
                        " + DISCRIPTOR_NAME + @" VARCHAR(30) NOT NULL,
                        " + NAME_ORGANIZATION + @" VARCHAR(30) NOT NULL,
                        " + NAME_OTDEL + @" VARCHAR(30) NOT NULL,
                        " + ARTICLE_BDDS + @" VARCHAR(30) NOT NULL,                      
                        " + ROLE + @" VARCHAR(50) NOT NULL)                       
                    END";
        }
        // Запрос на запись в базу данных
        public string InsertOperation(InsertArgAddOperation insertArgAddOperation)
        {
            return "INSERT INTO " +
                    USER_TABLE_KASSA + "(" +
                    DATA_OPERATION + "," +
                    NAME_ARTICLE + "," +
                    SURNAME_USER + "," +
                    PAYMENT + "," +
                    FORM_PAY + "," +
                    SUMM + "," +
                    TYPE_OPERATION + "," +
                    DISCRIPTOR_NAME + "," +
                    NAME_ORGANIZATION + "," +
                    NAME_OTDEL + "," +
                    ARTICLE_BDDS + "," +
                    ROLE + ") " + $"VALUES ('{insertArgAddOperation.dataOperation}','{insertArgAddOperation.nameArticle}'," +
                                            $"'{insertArgAddOperation.nameEmployee}','{insertArgAddOperation.payment}','{insertArgAddOperation.formPay}'," +
                                            $"'{insertArgAddOperation.summ}','{insertArgAddOperation.type}','{insertArgAddOperation.discriptor}'," +
                                            $"'{insertArgAddOperation.organization}','{insertArgAddOperation.otdel}','{insertArgAddOperation.articleBDDS}'," +
                                            $"'{insertArgAddOperation.nameRole}')";
        }
        // Запрос на обновление информации в базе данных
        public string UpdateOperation(UpdateArgOperation updateArgOperation)
        {
            return $"UPDATE {updateArgOperation.nameTable} SET {DATA_OPERATION} = '{updateArgOperation.dataOperation}', " +
                                            $"{NAME_ARTICLE} = '{updateArgOperation.nameArticle}', " +
                                            $"{SURNAME_USER} = '{updateArgOperation.nameEmployee}', " +
                                            $"{PAYMENT} = '{updateArgOperation.payment}', " +
                                            $"{FORM_PAY} = '{updateArgOperation.formPay}', " +
                                            $"{SUMM} = '{updateArgOperation.summ}', " +
                                            $"{TYPE_OPERATION} = '{updateArgOperation.type}', " +
                                            $"{DISCRIPTOR_NAME} = '{updateArgOperation.discriptor}', " +
                                            $"{NAME_ORGANIZATION} = '{updateArgOperation.organization}', " +
                                            $"{NAME_OTDEL} = '{updateArgOperation.otdel}', " +
                                            $"{ARTICLE_BDDS} = '{updateArgOperation.articleBDDS}', " +
                                            $"{ROLE} = '{updateArgOperation.nameRole}' WHERE {ID} = '{updateArgOperation.id}'";
        }

        public static string SearchDateKASSA(string nameTable, string id, DateTime dataOperation, string nameArticle,
                                      string nameEmployee, string payment,
                                      string formPay, string summ, string type,
                                      string discriptor, string organization, string otdel,
                                      string articleBDDS, string nameRole)
        {
            return $"UPDATE {nameTable} SET {DATA_OPERATION} = '{dataOperation}', " +
                                            $"{NAME_ARTICLE} = '{nameArticle}', " +
                                            $"{SURNAME_USER} = '{nameEmployee}', " +
                                            $"{PAYMENT} = '{payment}', " +
                                            $"{FORM_PAY} = '{formPay}', " +
                                            $"{SUMM} = '{summ}', " +
                                            $"{TYPE_OPERATION} = '{type}', " +
                                            $"{DISCRIPTOR_NAME} = '{discriptor}', " +
                                            $"{NAME_ORGANIZATION} = '{organization}', " +
                                            $"{NAME_OTDEL} = '{otdel}', " +
                                            $"{ARTICLE_BDDS} = '{articleBDDS}', " +
                                            $"{ROLE} = '{nameRole}' WHERE {ID} = {id}";
        }


    }
    class InsertArgAddOperation
    {
        public DateTime dataOperation { get; init; }
        public string nameArticle { get; init; }
        public string nameEmployee { get; init; }
        public string payment { get; init; }
        public string formPay { get; init; }
        public string summ { get; init; }
        public string type { get; init; }
        public string discriptor { get; init; }
        public string organization { get; init; }
        public string otdel { get; init; }
        public string articleBDDS { get; init; }
        public string nameRole {  get; init; }
    }

    class UpdateArgOperation
    {
        public string nameTable { get; init; }
        public string id { get; init; }
        public DateTime dataOperation { get; init; }
        public string nameArticle { get; init; }
        public string nameEmployee { get; init; }
        public string payment { get; init; }
        public string formPay { get; init; }
        public string summ { get; init; }
        public string type { get; init; }
        public string discriptor { get; init; }
        public string organization { get; init; }
        public string otdel { get; init; }
        public string articleBDDS { get; init; }
        public string nameRole { get; init; }
    }
}

