﻿namespace AIS.Models
{
    interface IEmplCreatorArticle
    {
        string CheckTableQuery(string nameTable);
        string CreateTableArticleBDDS();
    }
    interface IEmplInsertArticle
    {
        string InsertDataArticleBDDS(InsertArgArticle insertArgOperation);
    }
    interface IEmplUpdateArticle
    {
        string UpdateDateArticle(UpdateArgArticle updateArgArticle);
    }


    internal class ArticleBDDSModel() : IEmplCreatorArticle, IEmplInsertArticle, IEmplUpdateArticle
    {
        public static string USER_TABLE_ARTICLE = "article";
        public static string ID = "id";
        public static string NAME_ARTICLE = "nameArticle";
        public static string ARTICLE_BDDS = "articleBDDS";
        public static string TYPE_OPERATION = "typeOperation";

        // Запрос на создание таблицы организаций если её не существует в базе данных
        public string CheckTableQuery(string nameTable)
        {
            return $"SELECT 1 FROM {nameTable}";
        }

        // Запрос на создание таблицы операций БДДС
        public string CreateTableArticleBDDS()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_ARTICLE + @"')
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_ARTICLE + @" (                                  
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + NAME_ARTICLE + @" VARCHAR(30) NOT NULL,
                        " + ARTICLE_BDDS + @" VARCHAR(7) NOT NULL,                         
                        " + TYPE_OPERATION + @" VARCHAR(6) NOT NULL)                         
                    END";
        }

        // Запрос на добавление операции в спровочник
        public string InsertDataArticleBDDS(InsertArgArticle insertArgArticle)
        {
            return "INSERT INTO " +
                    USER_TABLE_ARTICLE + "(" +
                    NAME_ARTICLE + "," +
                    ARTICLE_BDDS + "," +
                    TYPE_OPERATION + ") " + $"VALUES ('{insertArgArticle.nameArticle}','{insertArgArticle.articleBDDS}','{insertArgArticle.type}')";
        }

        public string UpdateDateArticle(UpdateArgArticle updateArgArticle)
        {
            return $"UPDATE {updateArgArticle.nameTable} SET {NAME_ARTICLE} = '{updateArgArticle.nameArticle}', " +
                                          $"{ARTICLE_BDDS} = '{updateArgArticle.articleBDDS}', " +
                                          $"{TYPE_OPERATION} = '{updateArgArticle.typeOperation}' WHERE {ID} = {updateArgArticle.id}";
        }

        // Запрос получение поля из базы данных

    }
    class InsertArgArticle
    {
        public string nameArticle { get; init; }
        public string articleBDDS { get; init; }
        public string type { get; init; }
    }
    class UpdateArgArticle
    {
        public string nameTable { get; init; }
        public string id { get; init; }
        public string nameArticle { get; init; }
        public string articleBDDS { get; init; }
        public string typeOperation { get; init; }
    }
    

}

