﻿namespace AIS.Models
{
    interface IEmplCreatorEmployee
    {
        string CreateTableEmployees();
    }

    interface IEmplInsertEmployee
    {
        string InsertDataEmployees(InsertArgEmployees insertArgEmployees);
    }
    interface IEmplUpdateEmployee
    {
        string UpdateDateEmployees(UpdateArgEmployees updateArgEmployees);
    }

    internal class EmployeesModel : IEmplCreatorEmployee, IEmplInsertEmployee, IEmplUpdateEmployee
    {
        // Данные таблицы сотрудников
        public static string USER_TABLE_EMPLOYEE = "employee"; // Название таблицы справочника сотрудников
        public static string ID = RegistrationModel.ID;
        public static string NAMBER_EMPLOYEE = "namberEmployee"; // Табельный номер
        public static string SURNAME_USER = RegistrationModel.SURNAME_USER; // Фамилия
        public static string NAME_USER = RegistrationModel.NAME_USER; // Имя
        public static string MIDDLE_NAME = RegistrationModel.MIDDLE_NAME; // Отчество
        public static string NAME_OTDEL = OtdelModel.NAME_OTDEL; // Отдел
        public static string NAME_STAFF = StaffModel.NAME_STAFF; // Должность

        public static string NAME_ORGANIZATION = OrganizationModel.NAME_ORGANIZATION;
        public static string BIRTHDAY = "birthday";

        // Запрос на создание таблицы сотрудников
        public string CreateTableEmployees()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_EMPLOYEE + @"')
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_EMPLOYEE + @" (                                  
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + NAMBER_EMPLOYEE + @" VARCHAR(20) NOT NULL,
                        " + SURNAME_USER + @" VARCHAR(25) NOT NULL,
                        " + NAME_USER + @" VARCHAR(25) NOT NULL,
                        " + MIDDLE_NAME + @" VARCHAR(25),
                        " + NAME_ORGANIZATION + @" VARCHAR(25) NOT NULL,
                        " + NAME_OTDEL + @" VARCHAR(30) NOT NULL,
                        " + NAME_STAFF + @" VARCHAR(30) NOT NULL,
                        " + BIRTHDAY + @" DATE NOT NULL)                                                 
                    END";
        }
        // Запрос на добавление сотрудников в спровочник

        public string InsertDataEmployees(InsertArgEmployees insertArgEmployees)
        {
            return "INSERT INTO " +
                    USER_TABLE_EMPLOYEE + "(" +
                    NAMBER_EMPLOYEE + "," +
                    SURNAME_USER + "," +
                    NAME_USER + "," +
                    MIDDLE_NAME + "," +
                    NAME_ORGANIZATION + "," +
                    NAME_OTDEL + "," +
                    NAME_STAFF + "," +
                    BIRTHDAY + ") " + $"VALUES ('{insertArgEmployees.numberEmployee}','{insertArgEmployees.surnameUser}'," +
                                            $"'{insertArgEmployees.nameUser}','{insertArgEmployees.middleName}','{insertArgEmployees.nameOrganization}'," +
                                            $"'{insertArgEmployees.nameOtdel}','{insertArgEmployees.nameStaff}','{insertArgEmployees.birthday}')";
        }

        public string UpdateDateEmployees(UpdateArgEmployees updateArgEmployees)
        {
            return $"UPDATE {updateArgEmployees.nameTable} SET " +
                                                  $"{NAMBER_EMPLOYEE} = '{updateArgEmployees.namberEmployee}'," +
                                                  $"{SURNAME_USER} = '{updateArgEmployees.surnameUser}'," +
                                                  $"{NAME_USER} = '{updateArgEmployees.nameUser}'," +
                                                  $"{MIDDLE_NAME} = '{updateArgEmployees.middleName}'," +
                                                  $"{NAME_ORGANIZATION} = '{updateArgEmployees.nameOrganization}'," +
                                                  $"{NAME_OTDEL} = '{updateArgEmployees.nameOtdel}'," +
                                                  $"{NAME_STAFF} = '{updateArgEmployees.nameStaff}'," +
                                                  $"{BIRTHDAY} = '{updateArgEmployees.birthday}' WHERE {ID} = {updateArgEmployees.id}";
        }

    }

    class InsertArgEmployees
    {
        public string numberEmployee { get; init; }
        public string surnameUser { get; init; }
        public string nameUser { get; init; }
        public string middleName { get; init; }
        public string nameOrganization { get; init; }
        public string nameOtdel { get; init; }
        public string nameStaff { get; init; }
        public DateTime birthday { get; init; }
    }

    class UpdateArgEmployees
    {
        public string nameTable { get; init; }
        public string namberEmployee { get; init; }
        public string surnameUser { get; init; }
        public string nameUser { get; init; }
        public string middleName { get; init; }
        public string nameOrganization { get; init; }
        public string nameOtdel { get; init; }
        public string nameStaff { get; init; }
        public DateTime birthday { get; init; }
        public string id { get; init; }
    }

}

