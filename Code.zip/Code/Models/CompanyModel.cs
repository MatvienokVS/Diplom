﻿namespace AIS.Models
{
    internal class CompanyModel
    {
        public static string USER_TABLE_COMPANY = "company";
        public static string ID = OrganizationModel.ID;
        public static string INN_COMPANY = "innCompany";
        public static string NAME_COMPANY = "nameCompany"; // Название компании
        public static string CONTACT_PERSON = "contactPerson"; // Контактное лицо


        public static String CreateTableCompany()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_COMPANY + @"')
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_COMPANY + @" (                                  
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + INN_COMPANY + @" VARCHAR(20) NOT NULL,
                        " + NAME_COMPANY + @" VARCHAR(30) NOT NULL,
                        " + CONTACT_PERSON + @" VARCHAR(25) NOT NULL)                         
                    END";
        }
        // Запрос на добавление должности
        public static String InsertDataCompany(string nameTable, string inn, string nameCompany, string contact)
        {
            return $"INSERT INTO {nameTable} ({INN_COMPANY}, {NAME_COMPANY}, {CONTACT_PERSON}) VALUES ('{inn}','{nameCompany}','{contact}')";
        }

        public static String UpdateDateOtdel(string nameTable, string id, string inn, string nameCompany, string contact)
        {
            return $"UPDATE {nameTable} SET {INN_COMPANY} = '{inn}', {NAME_COMPANY} = '{nameCompany}', {CONTACT_PERSON} = '{contact}' WHERE {ID} = {id}";
        }
    }
}
