﻿using AIS.Forms;
using System.Globalization;

namespace AIS.Models
{
    interface IEmplCreaterPayEmployee
    {
        string CreateTablePayEmployee();
    }
    
    interface IEmplInsertPayEmployee
    {
        string InsertPayEmployee(InsertArgPayEmployee insertArgPayEmployee);
    }

    interface IEmplShowPayEmployee
    {
        string ShowAllPayEmployee(ShowArgPayEmployee showArgPayEmployee);
    }

    interface IEmplUpdatePayEmployee
    {
        string UpdatePayEmployee(UpdateArgPayEmployee updateArgPayEmployee);
    }

    internal class PayEmployeeModel : IEmplCreaterPayEmployee, IEmplInsertPayEmployee, IEmplShowPayEmployee, IEmplUpdatePayEmployee
    {
        public static string USER_TABLE_PAY_EMPLOYEE = "payEmployee";
        public static string ID = RegistrationModel.ID;
        public static string DATA_OPERATION = KassaModel.DATA_OPERATION;
        public static string SURNAME_USER = RegistrationModel.SURNAME_USER; // Фамилия
        public static string NAME_OTDEL = OtdelModel.NAME_OTDEL; // Отдел
        public static string NAME_STAFF = StaffModel.NAME_STAFF; // Должность
        public static string NAME_ORGANIZATION = OrganizationModel.NAME_ORGANIZATION;
        public static string SUMM_PAY_NAL = "summNal";
        public static string SUMM_PAY_NOT_NAL = "summNotNal";
        public static string SUMM_NALICHIE = "summNalichie";
        public static string SUMM_ZAKAZ = "summZakaz";
        public static string SUMM_SOPYTKA = "summSopytka";
        // Начисления
        public static string BONUS = "bonus";
        public static string REFUND = "refund"; // Возврат
        public static string OKLAD = "oklad"; // Оклад
        public static string KPI_ONE = "kpiOne"; 
        public static string KPI_TWO = "kpiTwo";
        public static string PERSENT_PAY_NALICHIE = "persentPayNalichie";
        public static string PERSENT_PAY_ZAKAZ = "persentPayZakaz";
        public static string PERSENT_PAY_SOPYTKA = "persentPaySopytka";
        public static string OTPUSK = "otpusk";
        public static string TOTAL_ACCURED = "totalAccured"; // Итого начислено
        // Выплата
        public static string AVANS = "avans";
        public static string DATE_AVANS = "dataAvans";
        public static string OTPUSK_PAY = "otpuskPay";
        public static string DATE_OTPUSK_PAY = "dataOtpuskPay";
        public static string REMAINS = "remains"; // Задолженность

        public static string DISCRIPTOR_NAME = RegistrationModel.DISCRIPTOR_NAME;

        // string nameTable, string periodStart, string periodStop, string dataOperation, string search, string nameOrganization, string nameOtdel
        public string ShowAllPayEmployee(ShowArgPayEmployee showArgPayEmployee)
        {
            var query = $"SELECT * FROM {showArgPayEmployee.nameTable} WHERE ({SURNAME_USER} LIKE '%{showArgPayEmployee.search}%' OR " +                                                    
                                                    $"{DISCRIPTOR_NAME} LIKE '%{showArgPayEmployee.search}%' OR " +
                                                    $"{NAME_STAFF} LIKE '%{showArgPayEmployee.search}%' OR " +
                                                    $"{SUMM_NALICHIE} LIKE '%{showArgPayEmployee.search}%' OR " +
                                                    $"{SUMM_ZAKAZ} LIKE '%{showArgPayEmployee.search}%' OR " +
                                                    $"{SUMM_SOPYTKA} LIKE '%{showArgPayEmployee.search}%' OR " +
                                                    $"{BONUS} LIKE '%{showArgPayEmployee.search}%' OR " +
                                                    $"{REFUND} LIKE '%{showArgPayEmployee.search}%' OR " +
                                                    $"{OKLAD} LIKE '%{showArgPayEmployee.search}%' OR " +
                                                    $"{DISCRIPTOR_NAME} LIKE '%{showArgPayEmployee.search}%') AND " +
                                                    $"({NAME_OTDEL} LIKE '%{showArgPayEmployee.nameOtdel}%' AND " +
                                                    $"{NAME_ORGANIZATION} LIKE '%{showArgPayEmployee.nameOrganization}%') AND " +
                                                    $"{DATA_OPERATION} >= '{showArgPayEmployee.periodStart}' AND " +
                                                    $"{DATA_OPERATION} <= '{showArgPayEmployee.periodStop}' ";

            return $"{query} ORDER BY {DATA_OPERATION}";
        }

        public string CreateTablePayEmployee()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_PAY_EMPLOYEE + @"')
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_PAY_EMPLOYEE + @" (                                  
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + DATA_OPERATION + @" DATE NOT NULL,                       
                        " + SURNAME_USER + @" VARCHAR(30) NOT NULL,
                        " + NAME_ORGANIZATION + @" VARCHAR(30) NOT NULL,
                        " + NAME_OTDEL + @" VARCHAR(25) NOT NULL,
                        " + NAME_STAFF + @" VARCHAR(40) NOT NULL,
                        " + SUMM_NALICHIE + @" DECIMAL(18, 2),                        
                        " + SUMM_ZAKAZ + @" DECIMAL(18, 2),                        
                        " + SUMM_SOPYTKA + @" DECIMAL(18, 2),                        
                        " + BONUS + @" DECIMAL(18, 2),                        
                        " + REFUND + @" DECIMAL(18, 2),                        
                        " + OKLAD + @" DECIMAL(18, 2),                        
                        " + KPI_ONE + @" DECIMAL(18, 2),                        
                        " + KPI_TWO + @" DECIMAL(18, 2),                       
                        " + OTPUSK + @" DECIMAL(18, 2),                        
                        " + TOTAL_ACCURED + @" DECIMAL(18, 2),                        
                        " + AVANS + @" DECIMAL(18, 2),                        
                        " + DATE_AVANS + @" DATE,                        
                        " + OTPUSK_PAY + @" DECIMAL(18, 2),                        
                        " + DATE_OTPUSK_PAY + @" DATE,                        
                        " + REMAINS + @" DECIMAL(18, 2) NOT NULL,                        
                        " + DISCRIPTOR_NAME + @" VARCHAR(30) NOT NULL)                       
                    END";
        }

        public string InsertPayEmployee(InsertArgPayEmployee insertArgPayEmployee)
        {
            return "INSERT INTO " +
                    USER_TABLE_PAY_EMPLOYEE + "(" +
                    DATA_OPERATION + "," +
                    SURNAME_USER + "," +
                    NAME_ORGANIZATION + "," +
                    NAME_OTDEL + "," +
                    NAME_STAFF + "," +
                    SUMM_NALICHIE + "," +
                    SUMM_ZAKAZ + "," +
                    SUMM_SOPYTKA + "," +
                    BONUS + "," +
                    REFUND + "," +
                    OKLAD + "," +
                    KPI_ONE + "," +
                    KPI_TWO + "," +
                    OTPUSK + "," +
                    TOTAL_ACCURED + "," +
                    AVANS + "," +
                    DATE_AVANS + "," +
                    OTPUSK_PAY + "," +
                    DATE_OTPUSK_PAY + "," +
                    REMAINS + "," +
                    DISCRIPTOR_NAME + ") " + $"VALUES ('{insertArgPayEmployee.dataOperation}'," +
                                                    $"'{insertArgPayEmployee.surnameUser}'," +
                                                    $"'{insertArgPayEmployee.nameOrganization}'," +                                                   
                                                    $"'{insertArgPayEmployee.nameOtdel}'," +
                                                    $"'{insertArgPayEmployee.nameStaff}'," +                                                                                                    
                                                    $"'{insertArgPayEmployee.summNalichie.ToStringExt()}'," +                                                   
                                                    $"'{insertArgPayEmployee.summZakaz.ToStringExt()}'," +                                                   
                                                    $"'{insertArgPayEmployee.summSopytka.ToStringExt()}'," +                                                                          
                                                    $"'{insertArgPayEmployee.bonus.ToStringExt()}'," +                                                   
                                                    $"'{insertArgPayEmployee.refund.ToStringExt()}'," +
                                                    $"'{insertArgPayEmployee.oklad.ToStringExt()}'," +
                                                    $"'{insertArgPayEmployee.kpiOne.ToStringExt()}'," +
                                                    $"'{insertArgPayEmployee.kpiTwo.ToStringExt()}'," +                                    
                                                    $"'{insertArgPayEmployee.otpusk.ToStringExt()}'," +
                                                    $"'{insertArgPayEmployee.totalAccured.ToStringExt()}'," +
                                                    $"'{insertArgPayEmployee.avans.ToStringExt()}'," +
                                                    $"'{insertArgPayEmployee.dataAvans}'," +
                                                    $"'{insertArgPayEmployee.otpuskPay.ToStringExt()}'," +
                                                    $"'{insertArgPayEmployee.dataOtpuskPay}'," +
                                                    $"'{insertArgPayEmployee.remains.ToStringExt()}'," +
                                                    $"'{insertArgPayEmployee.discriptor}')";
        }

        public string UpdatePayEmployee(UpdateArgPayEmployee updateArgPayEmployee)
        {
            return $"UPDATE {updateArgPayEmployee.nameTable} SET {DATA_OPERATION} = '{updateArgPayEmployee.dataOperation}', " +
                                            $"{SURNAME_USER} = '{updateArgPayEmployee.surnameUser}', " +
                                            $"{NAME_ORGANIZATION} = '{updateArgPayEmployee.nameOrganization}', " +
                                            $"{NAME_OTDEL} = '{updateArgPayEmployee.nameOtdel}', " +
                                            $"{NAME_STAFF} = '{updateArgPayEmployee.nameStaff}', " +
                                            $"{SUMM_NALICHIE} = '{updateArgPayEmployee.summNalichie.ToStringExt()}', " +
                                            $"{SUMM_ZAKAZ} = '{updateArgPayEmployee.summZakaz.ToStringExt()}', " +
                                            $"{SUMM_SOPYTKA} = '{updateArgPayEmployee.summSopytka.ToStringExt()}', " +
                                            $"{BONUS} = '{updateArgPayEmployee.bonus.ToStringExt()}', " +
                                            $"{REFUND} = '{updateArgPayEmployee.refund.ToStringExt()}', " +
                                            $"{OKLAD} = '{updateArgPayEmployee.oklad.ToStringExt()}', " +
                                            $"{KPI_ONE} = '{updateArgPayEmployee.kpiOne.ToStringExt()}', " +
                                            $"{KPI_TWO} = '{updateArgPayEmployee.kpiTwo.ToStringExt()}', " +
                                            $"{OTPUSK} = '{updateArgPayEmployee.otpusk.ToStringExt()}', " +
                                            $"{AVANS} = '{updateArgPayEmployee.avans.ToStringExt()}', " +
                                            $"{DATE_AVANS} = '{updateArgPayEmployee.dataAvans}', " +
                                            $"{OTPUSK_PAY} = '{updateArgPayEmployee.otpuskPay.ToStringExt()}', " +
                                            $"{DATE_OTPUSK_PAY} = '{updateArgPayEmployee.dataOtpuskPay}' WHERE {ID} = '{updateArgPayEmployee.id}'";
        }
    }

    class InsertArgPayEmployee
    {
        public DateTime dataOperation { get; init; }
        public string nameOrganization { get; init; }
        public string nameOtdel { get; init; }
        public string nameStaff { get; init; }
        public string surnameUser { get; init; }
        public decimal summPayNal { get; init; }
        public decimal summPayNotNal { get; init; }
        public decimal summNalichie { get; init; }
        public decimal summZakaz { get; init; }
        public decimal summSopytka { get; init; }
        public decimal bonus { get; init; }
        public decimal refund { get; init; }
        public decimal oklad { get; init; }
        public decimal kpiOne { get; init; }
        public decimal kpiTwo { get; init; }
        //public string persentNalichie { get; init; }
        //public string persentZakaz { get; init; }
        //public string persentSopytka { get; init; }
        public decimal otpusk { get; init; }
        public decimal totalAccured { get; init; }
        public decimal avans { get; init; }
        public DateTime dataAvans { get; init; }
        public decimal otpuskPay { get; init; }
        public DateTime dataOtpuskPay { get; init; }
        public decimal remains { get; init; }
        public string discriptor { get; init; }
    }

   class ShowArgPayEmployee
   {
        public string nameTable { get; init; }
        public DateTime periodStart { get; init; }
        public DateTime periodStop { get; init; }
        //public DateTime dataOperation { get; init; }
        public string search { get; init; }
        public string nameOrganization { get; init; }
        public string nameOtdel { get; init; }
   }

   class UpdateArgPayEmployee
    {
        public string nameTable { get; init; }
        public DateTime dataOperation { get; init; }
        public string surnameUser { get; init; }
        public string nameOrganization { get; init; }
        public string nameOtdel { get; init; }
        public string nameStaff { get; init; }
        //public string summPayNal { get; init; }
        //public string summPayNotNal { get; init; }
        public decimal summNalichie { get; init; }
        public decimal summZakaz { get; init; }
        public decimal summSopytka { get; init; }
        public decimal bonus { get; init; }
        public decimal refund { get; init; }
        public decimal oklad { get; init; }
        public decimal kpiOne { get; init; }
        public decimal kpiTwo { get; init; }
        public decimal otpusk { get; init; }
        public decimal avans { get; init; }
        public DateTime dataAvans { get; init; }
        public decimal otpuskPay { get; init; }
        public DateTime dataOtpuskPay { get; init; }
        public string id { get; init; }
    }

    static class DecimalExtension
    {
        public static string ToStringExt(this decimal value)
        {
            return value.ToString(new NumberFormatInfo() { NumberDecimalSeparator = "." });
        }
    }
}

