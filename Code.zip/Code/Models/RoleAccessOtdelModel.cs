﻿namespace AIS.Models
{
    interface IEmplCreatorRoleOtdelAccess
    {
        string CreateTableRoleOtdelAccess();
    }

    interface IEmplInsertRoleOtdelAccess
    {
        string InsertDataRoleOtdelAccess(InsertArgRoleOtdelAccess insertArgRoleOtdelAccess);
    }

    interface IEmplUpdateRoleOtdelAccess
    {
        string UpdateDataRoleOtdelAccess(UpdateArgRoleOtdelAccess updateArgRoleOtdelAccess);
    }

    internal class RoleAccessOtdelModel : IEmplCreatorRoleOtdelAccess, IEmplInsertRoleOtdelAccess, IEmplUpdateRoleOtdelAccess
    {
        public static string USER_TABLE_ROLE_OTDEL_ACCESS = "roleOtdelAccess";
        public static string ID = "id";
        public static string ID_OTDEL = "idOtdel";
        public static string ID_ROLES = "idRoles";

        public string CreateTableRoleOtdelAccess()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_ROLE_OTDEL_ACCESS + @"')
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_ROLE_OTDEL_ACCESS + @" (                                  
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + ID_OTDEL + @" VARCHAR(30) NOT NULL,
                        " + ID_ROLES + @" VARCHAR(30) NOT NULL)                       
                    END";
        }

        public string InsertDataRoleOtdelAccess(InsertArgRoleOtdelAccess insertArgRoleOtdelAccess)
        {
            return @$"INSERT INTO {insertArgRoleOtdelAccess.nameTable} ({ID_OTDEL}, 
                                  {ID_ROLES}) VALUES ('{insertArgRoleOtdelAccess.id_otdel}',
                                  '{insertArgRoleOtdelAccess.id_role}')";
        }

        public string UpdateDataRoleOtdelAccess(UpdateArgRoleOtdelAccess updateArgRoleOtdelAccess)
        {
            return @$"UPDATE {updateArgRoleOtdelAccess.nameTable} SET 
                                                            {ID_OTDEL} = '{updateArgRoleOtdelAccess.id_otdel}',
                                                            {ID_ROLES} = '{updateArgRoleOtdelAccess.id_role}' 
                                                             WHERE 
                                                            {ID} = {updateArgRoleOtdelAccess.id}";
        }

    }
    class InsertArgRoleOtdelAccess
    {
        public string nameTable { get; init; }
        public string id_otdel { get; init; }
        public string id_role { get; init; }

    }

    class UpdateArgRoleOtdelAccess
    {
        public string id { get; init; }
        public string nameTable { get; init; }
        public string id_otdel { get; init; }
        public string id_role { get; init; }
    }
}
