﻿namespace AIS.Models
{
    internal class OtdelModel()
    {
        public static string USER_TABLE_OTDEL = "otdels"; // Название таблицы для добавления отдела
        public static string NAME_OTDEL = "nameOtdel"; // Отдел
        public static string CODE_OTDEL = "codeOtdel"; // код отдела
        public static string ID = OrganizationModel.ID;

        // Запрос на создание таблицы отдела
        public static String CreateTableOtdel()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_OTDEL + @"') 
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_OTDEL + @" (
                            " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                            " + CODE_OTDEL + @" VARCHAR(2) NOT NULL UNIQUE,
                            " + NAME_OTDEL + @" VARCHAR(25) NOT NULL UNIQUE)
                    END";
        }

        // Запрос на добавление отдела
        public static String InsertDataOtdel(string code, string nameOtdel)
        {
            return "INSERT INTO " +
                    USER_TABLE_OTDEL + "(" +
                    CODE_OTDEL + "," +
                    NAME_OTDEL + ") " + $"VALUES ('{code}','{nameOtdel}')";
        }

        public static String UpdateDateOtdel(string nameTable, string id, string code, string nameOtdel)
        {
            return $"UPDATE {nameTable} SET {CODE_OTDEL} = '{code}', {NAME_OTDEL} = '{nameOtdel}' WHERE {ID} = {id}";
        }

    }
}
