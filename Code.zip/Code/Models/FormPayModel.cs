﻿using AIS.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using System.Windows.Forms;

namespace AIS.Models
{
    internal class FormPayModel()
    {
        // Данные таблицы операции формы платежа
        public static string USER_TABLE_FORM_PAY = "formPay";
        public static string ID = "id";
        public static string CODE_PAY = "codePay";
        public static string NAME_FORM_PAY = "nameFormPay";


        // Запрос на создание таблицы форма платежа
        public static String CreateTableFormPay()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_FORM_PAY + @"')
                    BEGIN
                        CREATE TABLE " + USER_TABLE_FORM_PAY + @" ( 
                            " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                            " + CODE_PAY + @" VARCHAR(2) NOT NULL UNIQUE,
                            " + NAME_FORM_PAY + @" VARCHAR(25) NOT NULL UNIQUE)
                    END";
        }

        // Запрос на добавление организации
        public static String InsertDataFormPay(string code, string nameFormPay)
        {
            return "INSERT INTO " +
                    USER_TABLE_FORM_PAY + "(" +
                    CODE_PAY + "," +
                    NAME_FORM_PAY + ") " + $"VALUES ('{code}','{nameFormPay}')";
        }

        public static String UpdateDateFormPay(string nameTable, string id, string code, string nameFormPay)
        {
            return $"UPDATE {nameTable} SET {CODE_PAY} = '{code}', " +
                                          $"{NAME_FORM_PAY} = '{nameFormPay}' WHERE {ID} = {id}";
        }        
        
    }
}

