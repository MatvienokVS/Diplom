﻿using AIS.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIS.Models
{
    internal class StaffModel
    {
        public static string USER_TABLE_STAFF = "staff"; // Название таблицы для добавления должности
        public static string ID = "id";
        public static string NAME_STAFF = "nameStaff"; // Должность
        public static string CODE_STAFF = "codeStaff"; // код Должности

        // Запрос на создание таблицы должности
        public static String CreateTableStaff()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_STAFF + @"') 
                    BEGIN 
                        CREATE TABLE " + USER_TABLE_STAFF + @" (
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + CODE_STAFF + @" VARCHAR(2) NOT NULL UNIQUE,
                        " + NAME_STAFF + @" VARCHAR(40) NOT NULL UNIQUE)
                    END";
        }
        // Запрос на добавление должности
        public static String InsertDataStaff(string nameTable, string code, string nameStaff)
        {
            return $"INSERT INTO {nameTable} ({CODE_STAFF}, {NAME_STAFF}) VALUES ('{code}','{nameStaff}')";
        }

        public static String UpdateDateStaff(string nameTable, string id, string codeStaff, string nameStaff)
        {
            return $"UPDATE {nameTable} SET {CODE_STAFF} = '{codeStaff}', {NAME_STAFF} = '{nameStaff}' WHERE {ID} = {id}";
        }

    }
}
