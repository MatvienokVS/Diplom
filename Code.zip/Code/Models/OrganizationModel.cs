﻿namespace AIS.Models
{


    internal class OrganizationModel()
    {
        public static string USER_TABLE_Organization = "organization";
        public static string ID = "id";
        public static string CODE_ORGANIZATION = "codeOrganization";
        public static string NAME_ORGANIZATION = "nameOrganization";

        // Запрос на получение id в таблице
        public static string ShowID(string nameTable, string id)
        {
            return $"SELECT '{id}' FROM {nameTable}";
        }

        // Запрос на создание таблицы организаций если её не существует в базе данных
        public static string CheckTableQuery(string nameTable)
        {
            return $"SELECT 1 FROM " + nameTable;
        }

        // Запрос на создание таблицы организаций
        public static String CreateTableOrganization()
        {
            return @"IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '" + USER_TABLE_Organization + @"')
                BEGIN
                    CREATE TABLE " + USER_TABLE_Organization + @" ( 
                        " + ID + @" INT IDENTITY(1,1) PRIMARY KEY,
                        " + CODE_ORGANIZATION + @" VARCHAR(2) NOT NULL UNIQUE,
                        " + NAME_ORGANIZATION + @" VARCHAR(25) NOT NULL)
                END";
        }

        // Запрос на добавление организации
        public static String InsertDataOrganization(string code, string nameOrganization)
        {
            return "INSERT INTO " +
                    USER_TABLE_Organization + "(" +
                    CODE_ORGANIZATION + "," +
                    NAME_ORGANIZATION + ") " + $"VALUES ('{code}','{nameOrganization}')";
        }

        public static String UpdateDateOrganization(string nameTable, string id, string code, string nameOrganization)
        {
            return $"UPDATE {nameTable} SET {CODE_ORGANIZATION} = '{code}', {NAME_ORGANIZATION} = '{nameOrganization}' WHERE {ID} = {id}";
        }

    }
}

