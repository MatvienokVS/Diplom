﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIS.Forms
{
    public partial class ArticleBDDS : Form
    {
        private IQuerySelect _querySelect;
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;

        public ArticleBDDS()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;

            UpdateDataGridView();
            changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplCreator = GetEmplCreatorArticle();
                string queryCreateTable = emplCreator.CreateTableArticleBDDS();
                db.ExecuteNonQuery(queryCreateTable);

                if (!ValidateOperation())
                {
                    return;
                }

                var emplInsert = GetEmplInsertArticle();
                var arg = new InsertArgArticle()
                {
                    nameArticle = Txb_nameArticle.Text,
                    articleBDDS = Txb_articleBDDS.Text,
                    type = Txb_type.Text
                };

                // Записываем данные в базу данных
                string insertQuery = emplInsert.InsertDataArticleBDDS(arg);
                int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                if (numRowsInserted > 0) ;
                //MessageBox.Show("Данные успешно сохранены.");
                else
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);

                UpdateDataGridView();
                ClearForm();             
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = ArticleBDDSModel.USER_TABLE_ARTICLE;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                var emplCreator = GetEmplCreatorArticle();
                string queryCreateTable = emplCreator.CreateTableArticleBDDS();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_Operation.DataSource = dataTable;

                Tbl_Operation.Columns["id"].Width = 50;
                Tbl_Operation.Columns["id"].HeaderText = "id записи";
                Tbl_Operation.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Operation.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Operation.Columns["nameArticle"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_Operation.Columns["nameArticle"].HeaderText = "Наименование операции";
                Tbl_Operation.Columns["nameArticle"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Operation.Columns["articleBDDS"].Width = 55; 
                Tbl_Operation.Columns["articleBDDS"].HeaderText = "Статья БДДС";
                Tbl_Operation.Columns["articleBDDS"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Operation.Columns["articleBDDS"].DefaultCellStyle.Alignment= DataGridViewContentAlignment.MiddleCenter;

                Tbl_Operation.Columns["typeOperation"].Width = 60;
                Tbl_Operation.Columns["typeOperation"].HeaderText = "Тип операции";
                Tbl_Operation.Columns["typeOperation"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Operation.Columns["typeOperation"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            db.DisConnect();

        }

        private void Tbl_Company_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_nameArticle.Text = "";
                Txb_articleBDDS.Text = "";

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Tbl_Company_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_Operation.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string nameOperation = selectedRow.Cells["nameArticle"].Value.ToString();
                string articleBDDS = selectedRow.Cells["articleBDDS"].Value.ToString();
                string typeOperation = selectedRow.Cells["typeOperation"].Value.ToString();

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Txb_nameArticle.Text = nameOperation;
                Txb_articleBDDS.Text = articleBDDS;
                Txb_type.Text = typeOperation;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;
            }
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

            string nameTable = ArticleBDDSModel.USER_TABLE_ARTICLE;
            string condition = ArticleBDDSModel.NAME_ARTICLE + " = '" + Txb_nameArticle.Text + "'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            _ = db.ExecuteNonQuery(deleteQuery);

            UpdateDataGridView();

            Txb_nameArticle.Text = "";
            Txb_articleBDDS.Text = "";

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplUpdate = GetEmplUpdateArticle();
                var arg = new UpdateArgArticle()
                {
                    nameTable = ArticleBDDSModel.USER_TABLE_ARTICLE,
                    nameArticle = Txb_nameArticle.Text,
                    articleBDDS = Txb_articleBDDS.Text,
                    typeOperation = Txb_type.Text,
                    id = Txb_id.Text
                };
                string queryUpdateLine = emplUpdate.UpdateDateArticle(arg);
                int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);                       
                                            
                if (numRowsUpdated > 0) ;
                //MessageBox.Show("Данные успешно сохранены.");
                else
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);

                UpdateDataGridView();
                ClearForm();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);                                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        private void ClearForm()
        {
            Txb_id.Text = "";
            Txb_nameArticle.Text = "";
            Txb_articleBDDS.Text = "";
            Txb_type.Text = "";
        }
        private bool ValidateOperation()
        {
            if (string.IsNullOrEmpty(Txb_nameArticle.Text) ||
                string.IsNullOrEmpty(Txb_articleBDDS.Text) ||
                string.IsNullOrEmpty(Txb_type.Text))
            {
                MessageBox.Show("Заполните все поля");
                return false;
            }

            return true;
        }

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }

        private IEmplCreatorArticle GetEmplCreatorArticle()
        {
            return new ArticleBDDSModel();
        }

        private IEmplInsertArticle GetEmplInsertArticle()
        {
            return new ArticleBDDSModel();
        }

        private IEmplUpdateArticle GetEmplUpdateArticle()
        {
            return new ArticleBDDSModel();
        }
        
    }

}
