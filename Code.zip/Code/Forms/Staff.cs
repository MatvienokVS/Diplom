﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIS.Forms
{
    public partial class Staff : Form
    {
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;

        public Staff()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            UpdateDataGridView();
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Txb_code.Text) || string.IsNullOrEmpty(Txb_staff.Text))
                {
                    MessageBox.Show("Введите код и наименование должности");
                }
                else
                {
                    db.Connect();

                    string nameTable = StaffModel.USER_TABLE_STAFF;
                    string queryCreateTable = StaffModel.CreateTableStaff();
                    db.ExecuteNonQuery(queryCreateTable);

                    // Записываем данные в базу данных
                    string insertQuery = StaffModel.InsertDataStaff(nameTable, Txb_code.Text, Txb_staff.Text);
                    int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                    UpdateDataGridView();

                    if (numRowsInserted > 0) ;
                    //MessageBox.Show("Данные успешно сохранены.");
                    else
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);

                    Txb_code.Text = "";
                    Txb_staff.Text = "";

                    db.DisConnect();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }

        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = StaffModel.USER_TABLE_STAFF;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                string queryCreateTable = StaffModel.CreateTableStaff();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_Staff.DataSource = dataTable;
                //Tbl_Staff.Columns["codeStaff"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_Staff.Columns["id"].Width = 50;
                Tbl_Staff.Columns["id"].HeaderText = "id записи";
                Tbl_Staff.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Staff.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Staff.Columns["codeStaff"].Width = 70;
                Tbl_Staff.Columns["codeStaff"].HeaderText = "Код должности";
                Tbl_Staff.Columns["codeStaff"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Staff.Columns["codeStaff"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Staff.Columns["nameStaff"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_Staff.Columns["nameStaff"].HeaderText = "Наименование должности";
                Tbl_Staff.Columns["nameStaff"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            db.DisConnect();
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

            string nameTable = StaffModel.USER_TABLE_STAFF;
            string condition = StaffModel.CODE_STAFF + " = '" + Txb_code.Text + "'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            _ = db.ExecuteNonQuery(deleteQuery);

            UpdateDataGridView();

            Txb_id.Text = "";
            Txb_code.Text = "";
            Txb_staff.Text = "";
            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
        }

        private void Tbl_Staff_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_id.Text = "";
                Txb_code.Text = "";
                Txb_staff.Text = "";

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Tbl_Staff_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_Staff.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string code = selectedRow.Cells["codeStaff"].Value.ToString();
                string name = selectedRow.Cells["nameStaff"].Value.ToString();

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Txb_code.Text = code;
                Txb_staff.Text = name;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;
            }
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Txb_code.Text) || string.IsNullOrEmpty(Txb_staff.Text))
                {
                    MessageBox.Show("Введите код и наименование организации");
                }
                else
                {
                    db.Connect();

                    string nameTable = StaffModel.USER_TABLE_STAFF;
                    string id = Txb_id.Text;
                    string code = Txb_code.Text;
                    string nameStaff = Txb_staff.Text;

                    string queryUpdateLine = StaffModel.UpdateDateStaff(nameTable, id, code, nameStaff);
                    int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);

                    UpdateDataGridView();

                    if (numRowsUpdated > 0) ;
                    //MessageBox.Show("Данные успешно сохранены.");
                    else
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);

                    Txb_id.Text = "";
                    Txb_code.Text = "";
                    Txb_staff.Text = "";

                    Btn_update.Enabled = false;
                    Btn_update.BackColor = Color.LightGray;
                    Btn_delete.Enabled = false;
                    Btn_delete.BackColor = Color.LightGray;
                    Btn_save.Enabled = true;
                    Btn_save.BackColor = Color.FromArgb(98, 171, 180);

                    db.DisConnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }

        private IQuerySelect _querySelect;
        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }

    }
}
