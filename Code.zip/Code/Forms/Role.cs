﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIS.Forms
{
    public partial class Role : Form
    {
        private IQuerySelect _querySelect;

        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;

        public Role()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            UpdateDataGridView();
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {                      
                db.Connect();

                ValidateRole();

                var emplCreator = GetEmplCreatorRole();
                string queryCreateTable = emplCreator.CreateTableRole();
                db.ExecuteNonQuery(queryCreateTable);

                var emplInsert = GetEmplInsertRole();
                var arg = new InsertArgRole()
                {
                    nameTable = RoleModel.USER_TABLE_ROLE,
                    role = Txb_role.Text,
                };


                // Записываем данные в базу данных
                string insertQuery = emplInsert.InsertDataRole(arg);
                int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                UpdateDataGridView();

                if (numRowsInserted > 0) ;
                //MessageBox.Show("Данные успешно сохранены.");
                else
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);

                Txb_id.Text = "";
                Txb_role.Text = "";
                                
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = RoleModel.USER_TABLE_ROLE;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                var emplCreator = GetEmplCreatorRole();
                string queryCreateTable = emplCreator.CreateTableRole();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_role.DataSource = dataTable;
                //Tbl_Staff.Columns["codeStaff"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_role.Columns["id"].Width = 50;
                Tbl_role.Columns["id"].HeaderText = "id записи";
                Tbl_role.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_role.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                              
                Tbl_role.Columns["nameRole"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_role.Columns["nameRole"].HeaderText = "Наименование роли";
                Tbl_role.Columns["nameRole"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            db.DisConnect();
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

            string nameTable = RoleModel.USER_TABLE_ROLE;
            string condition = RoleModel.NAME_ROLE + " = '" + Txb_role.Text + "'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            db.ExecuteNonQuery(deleteQuery);

            UpdateDataGridView();

            Txb_id.Text = "";
            Txb_role.Text = "";
            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
        }

        private void Tbl_Staff_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_id.Text = "";
                Txb_role.Text = "";

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Tbl_Staff_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_role.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string name = selectedRow.Cells["nameRole"].Value.ToString();

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Txb_role.Text = name;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;
            }
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {               
                db.Connect();

                ValidateRole();

                var emplUpdate = GetEmplUpdateRole();
                var arg = new UpdateArgRole()
                {
                    nameTable = RoleModel.USER_TABLE_ROLE,
                    id = Txb_id.Text,
                    nameRole = Txb_role.Text,
                };

                string queryUpdateLine = emplUpdate.UpdateDateRole(arg);
                int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);

                UpdateDataGridView();

                if (numRowsUpdated > 0) ;
                //MessageBox.Show("Данные успешно сохранены.");
                else
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);

                ClearForm();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        private void ClearForm()
        {
            Txb_id.Text = "";
            Txb_role.Text = "";
        }

        private bool ValidateRole()
        {
            if (string.IsNullOrEmpty(Txb_role.Text))
            {
                MessageBox.Show("Введите наименование роли");
                return false;
            }
            return true;
        }

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }

        private IEmplCreatorRole GetEmplCreatorRole()
        {
            return new RoleModel();
        }

        private IEmplUpdateRole GetEmplUpdateRole()
        {
            return new RoleModel();
        }
        private IEmplInsertRole GetEmplInsertRole()
        {
            return new RoleModel();
        }
    }


}
