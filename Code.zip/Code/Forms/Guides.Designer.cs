﻿namespace AIS.Forms
{
    partial class Guides
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Btn_cancel = new Button();
            Btn_organization = new Button();
            Lbl_guides = new Label();
            Btn_company = new Button();
            Btn_otdel = new Button();
            Btn_personal = new Button();
            Btn_staff = new Button();
            Btn_operation = new Button();
            Btn_motivation = new Button();
            Btn_access = new Button();
            Btn_formPay = new Button();
            SuspendLayout();
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_cancel.Location = new Point(107, 362);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(243, 23);
            Btn_cancel.TabIndex = 4;
            Btn_cancel.Text = "Отмена";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // Btn_organization
            // 
            Btn_organization.BackColor = Color.FromArgb(98, 171, 180);
            Btn_organization.FlatAppearance.BorderSize = 0;
            Btn_organization.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_organization.FlatStyle = FlatStyle.Flat;
            Btn_organization.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_organization.Location = new Point(107, 54);
            Btn_organization.Name = "Btn_organization";
            Btn_organization.Size = new Size(243, 23);
            Btn_organization.TabIndex = 5;
            Btn_organization.Text = "Организации";
            Btn_organization.UseVisualStyleBackColor = false;
            Btn_organization.Click += Btn_organization_Click;
            // 
            // Lbl_guides
            // 
            Lbl_guides.AutoSize = true;
            Lbl_guides.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Lbl_guides.ForeColor = SystemColors.Info;
            Lbl_guides.Location = new Point(189, 20);
            Lbl_guides.Name = "Lbl_guides";
            Lbl_guides.Size = new Size(87, 17);
            Lbl_guides.TabIndex = 6;
            Lbl_guides.Text = "Справочники ";
            // 
            // Btn_company
            // 
            Btn_company.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_company.BackColor = Color.FromArgb(98, 171, 180);
            Btn_company.FlatAppearance.BorderSize = 0;
            Btn_company.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_company.FlatStyle = FlatStyle.Flat;
            Btn_company.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_company.Location = new Point(107, 83);
            Btn_company.Name = "Btn_company";
            Btn_company.Size = new Size(243, 23);
            Btn_company.TabIndex = 7;
            Btn_company.Text = "Контрагенты";
            Btn_company.UseVisualStyleBackColor = false;
            Btn_company.Click += Btn_company_Click;
            // 
            // Btn_otdel
            // 
            Btn_otdel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_otdel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_otdel.FlatAppearance.BorderSize = 0;
            Btn_otdel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_otdel.FlatStyle = FlatStyle.Flat;
            Btn_otdel.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_otdel.Location = new Point(107, 112);
            Btn_otdel.Name = "Btn_otdel";
            Btn_otdel.Size = new Size(243, 23);
            Btn_otdel.TabIndex = 8;
            Btn_otdel.Text = "Подразделения";
            Btn_otdel.UseVisualStyleBackColor = false;
            Btn_otdel.Click += Btn_otdel_Click;
            // 
            // Btn_personal
            // 
            Btn_personal.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_personal.BackColor = Color.FromArgb(98, 171, 180);
            Btn_personal.FlatAppearance.BorderSize = 0;
            Btn_personal.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_personal.FlatStyle = FlatStyle.Flat;
            Btn_personal.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_personal.Location = new Point(107, 141);
            Btn_personal.Name = "Btn_personal";
            Btn_personal.Size = new Size(243, 23);
            Btn_personal.TabIndex = 9;
            Btn_personal.Text = "Сотрудники";
            Btn_personal.UseVisualStyleBackColor = false;
            Btn_personal.Click += Btn_personal_Click;
            // 
            // Btn_staff
            // 
            Btn_staff.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_staff.BackColor = Color.FromArgb(98, 171, 180);
            Btn_staff.FlatAppearance.BorderSize = 0;
            Btn_staff.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_staff.FlatStyle = FlatStyle.Flat;
            Btn_staff.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_staff.Location = new Point(107, 170);
            Btn_staff.Name = "Btn_staff";
            Btn_staff.Size = new Size(243, 23);
            Btn_staff.TabIndex = 10;
            Btn_staff.Text = "Должности";
            Btn_staff.UseVisualStyleBackColor = false;
            Btn_staff.Click += Btn_staff_Click;
            // 
            // Btn_operation
            // 
            Btn_operation.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_operation.BackColor = Color.FromArgb(98, 171, 180);
            Btn_operation.FlatAppearance.BorderSize = 0;
            Btn_operation.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_operation.FlatStyle = FlatStyle.Flat;
            Btn_operation.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_operation.Location = new Point(107, 199);
            Btn_operation.Name = "Btn_operation";
            Btn_operation.Size = new Size(243, 23);
            Btn_operation.TabIndex = 10;
            Btn_operation.Text = "Операции БДДС";
            Btn_operation.UseVisualStyleBackColor = false;
            Btn_operation.Click += Btn_operation_Click;
            // 
            // Btn_motivation
            // 
            Btn_motivation.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_motivation.BackColor = Color.FromArgb(98, 171, 180);
            Btn_motivation.FlatAppearance.BorderSize = 0;
            Btn_motivation.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_motivation.FlatStyle = FlatStyle.Flat;
            Btn_motivation.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_motivation.Location = new Point(107, 228);
            Btn_motivation.Name = "Btn_motivation";
            Btn_motivation.Size = new Size(243, 23);
            Btn_motivation.TabIndex = 10;
            Btn_motivation.Text = "Мотивация";
            Btn_motivation.UseVisualStyleBackColor = false;
            Btn_motivation.Click += Btn_motivation_Click;
            // 
            // Btn_access
            // 
            Btn_access.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_access.BackColor = Color.FromArgb(98, 171, 180);
            Btn_access.FlatAppearance.BorderSize = 0;
            Btn_access.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_access.FlatStyle = FlatStyle.Flat;
            Btn_access.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_access.Location = new Point(107, 286);
            Btn_access.Name = "Btn_access";
            Btn_access.Size = new Size(243, 23);
            Btn_access.TabIndex = 10;
            Btn_access.Text = "Права доступа";
            Btn_access.UseVisualStyleBackColor = false;
            Btn_access.Visible = false;
            Btn_access.Click += Btn_access_Click;
            // 
            // Btn_formPay
            // 
            Btn_formPay.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_formPay.BackColor = Color.FromArgb(98, 171, 180);
            Btn_formPay.FlatAppearance.BorderSize = 0;
            Btn_formPay.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_formPay.FlatStyle = FlatStyle.Flat;
            Btn_formPay.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_formPay.Location = new Point(107, 257);
            Btn_formPay.Name = "Btn_formPay";
            Btn_formPay.Size = new Size(243, 23);
            Btn_formPay.TabIndex = 10;
            Btn_formPay.Text = "Форма платежа";
            Btn_formPay.UseVisualStyleBackColor = false;
            Btn_formPay.Click += Btn_formPay_Click;
            // 
            // Guides
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            CancelButton = Btn_cancel;
            ClientSize = new Size(448, 412);
            Controls.Add(Btn_formPay);
            Controls.Add(Btn_access);
            Controls.Add(Btn_motivation);
            Controls.Add(Btn_operation);
            Controls.Add(Btn_staff);
            Controls.Add(Btn_personal);
            Controls.Add(Btn_otdel);
            Controls.Add(Btn_company);
            Controls.Add(Lbl_guides);
            Controls.Add(Btn_organization);
            Controls.Add(Btn_cancel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Guides";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Guides";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Btn_cancel;
        private Button Btn_organization;
        private Label Lbl_guides;
        private Button Btn_company;
        private Button Btn_otdel;
        private Button Btn_personal;
        private Button Btn_staff;
        private Button Btn_operation;
        private Button Btn_motivation;
        private Button Btn_access;
        private Button Btn_formPay;

        public Button GetButton() { return Btn_company; }
    }



    
}