﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System.Data;

namespace AIS.Forms
{
    public partial class PayEmployee : Form
    {
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        private IQuerySelect _querySelect;

        public string selectedFilePath;
        public string nameTable = Const.USER_TABLE_KASSA;
        public string id = Const.ID;
        public string Login { get; set; }

        public PayEmployee()
        {
            InitializeComponent();

            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            DateTime today = DateTime.Today;
            DateTime firstDayOfMonth = new(today.Year, today.Month, 1);

            Dtp_start.Value = firstDayOfMonth;

            Dtp_start.ValueChanged += Dtp_start_ValueChanged;

            this.Load += (sender, e) =>
            {
                Cbx_organization.Text = NameOrganization();
                Cbx_otdel.Text = NameOtdel();
            };

            _ = changeOpacity();
        }

        // Асинхронная функция задержки открытия окна
        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }
        private void Btn_addOperation_Click(object sender, EventArgs e)
        {
            AddPayEmployee addPayEmployee = new();
            addPayEmployee.Btn_delete.Enabled = false;
            addPayEmployee.Btn_delete.BackColor = Color.LightGray;
            addPayEmployee.Btn_update.Enabled = false;
            addPayEmployee.Btn_update.BackColor = Color.LightGray;

            addPayEmployee.SaveSuccess += AddPayEmployee_SaveSuccess;

            addPayEmployee.ShowDialog();
        }
        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            TabControlManager.CloseCurrentTab(this);
            this.Dispose(); // Освобождаем ресурсы формы
        }
        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = PayEmployeeModel.USER_TABLE_PAY_EMPLOYEE;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            //string dataOperation = PayEmployeeModel.DATA_OPERATION;
            //string search = Txb_search.Text.Replace(",", ".");                       
            //string nameOtdel = NameOtdel();

            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                var emplCreator = GetEmplCreaterPayEmployee();
                string queryCreateTable = emplCreator.CreateTablePayEmployee();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                var emplShow = GetEmplShowPayEmployee();
                var arg = new ShowArgPayEmployee()
                {
                    nameTable = PayEmployeeModel.USER_TABLE_PAY_EMPLOYEE,
                    periodStart = Dtp_start.Value.Date,
                    periodStop = Dtp_stop.Value.Date,
                    //dataOperation = PayEmployeeModel.DATA_OPERATION,
                    search = Txb_search.Text,
                    nameOrganization = AcceessRoleNameOrganization(),
                    nameOtdel = AcceessRoleNameOtdel(),
                };

                string selectQuery = emplShow.ShowAllPayEmployee(arg);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);
                Tbl_PayEmployee.DataSource = dataTable;

                NameFieldsTableView();
            }
            db.DisConnect();
        }
        private void Tbl_PayEmployee_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            AddPayEmployee addPayEmployee = new AddPayEmployee();
            addPayEmployee.Btn_save.Enabled = false;
            addPayEmployee.Btn_save.BackColor = Color.LightGray;

            DataGridViewRow selectedRow = Tbl_PayEmployee.Rows[e.RowIndex];

            // Получаем данные из выбранной строки
            string id = selectedRow.Cells["id"].Value.ToString();
            string dataOperationString = selectedRow.Cells["dataOperation"].Value.ToString();
            DateTime dataOperation = DateTime.Parse(dataOperationString);
            string surnameUser = selectedRow.Cells["surnameUser"].Value.ToString();
            string nameOrganization = selectedRow.Cells["nameOrganization"].Value.ToString();
            string nameOtdel = selectedRow.Cells["nameOtdel"].Value.ToString();
            string nameStaff = selectedRow.Cells["nameStaff"].Value.ToString();
            decimal summNalichie = decimal.Parse(selectedRow.Cells["summNalichie"].Value.ToString());
            decimal summZakaz = decimal.Parse(selectedRow.Cells["summZakaz"].Value.ToString());
            decimal summSopytka = decimal.Parse(selectedRow.Cells["summSopytka"].Value.ToString());
            decimal bonus = decimal.Parse(selectedRow.Cells["bonus"].Value.ToString());
            decimal refund = decimal.Parse(selectedRow.Cells["refund"].Value.ToString());
            decimal oklad = decimal.Parse(selectedRow.Cells["oklad"].Value.ToString());
            decimal kpiOne = decimal.Parse(selectedRow.Cells["kpiOne"].Value.ToString());
            decimal kpiTwo = decimal.Parse(selectedRow.Cells["kpiTwo"].Value.ToString());
            decimal otpusk = decimal.Parse(selectedRow.Cells["otpusk"].Value.ToString());
            decimal totalAccured = decimal.Parse(selectedRow.Cells["totalAccured"].Value.ToString());
            decimal avans = decimal.Parse(selectedRow.Cells["avans"].Value.ToString());

            string dataAvansString = selectedRow.Cells["dataAvans"].Value.ToString();
            DateTime dataAvans = DateTime.Parse(dataAvansString);

            decimal otpuskPay = decimal.Parse(selectedRow.Cells["otpuskPay"].Value.ToString());

            string dataOtpuskPayString = selectedRow.Cells["dataAvans"].Value.ToString();
            DateTime dataotpuskPay = DateTime.Parse(dataOtpuskPayString);
            decimal remains = decimal.Parse(selectedRow.Cells["remains"].Value.ToString());

            //Заполняем поля для редактирования или удаления данных
            addPayEmployee.SetTxb_Id(id);
            addPayEmployee.SetDtp_dataOperation(dataOperation);
            addPayEmployee.SetCbx_nameEmployee(surnameUser);
            addPayEmployee.SetCbx_organization(nameOrganization);
            addPayEmployee.SetCbx_otdel(nameOtdel);
            addPayEmployee.SetCbx_Staff(nameStaff);

            string summStringNalichie = summNalichie.ToString("F2");
            summStringNalichie = summStringNalichie.Replace(".", ",");
            addPayEmployee.SetTxb_nalichie(summStringNalichie);

            string summStringZakaz = summZakaz.ToString("F2");
            summStringZakaz = summStringZakaz.Replace(".", ",");
            addPayEmployee.SetTxb_zakaz(summStringZakaz);

            string summStringSopytka = summSopytka.ToString("F2");
            summStringSopytka = summStringZakaz.Replace(".", ",");
            addPayEmployee.SetTxb_Soputka(summStringSopytka);

            string stringBonus = bonus.ToString("F2");
            stringBonus = stringBonus.Replace(".", ",");
            addPayEmployee.SetTxb_Bonus(stringBonus);

            string stringRefund = refund.ToString("F2");
            stringRefund = stringRefund.Replace(".", ",");
            addPayEmployee.SetTxb_Refund(stringRefund);

            string stringOklad = oklad.ToString("F2");
            stringOklad = stringOklad.Replace(".", ",");
            addPayEmployee.SetTxb_oklad(stringOklad);

            string stringkpiOne = oklad.ToString("F2");
            stringkpiOne = stringkpiOne.Replace(".", ",");
            addPayEmployee.SetTxb_kpiOne(stringkpiOne);

            string stringkpiTwo = oklad.ToString("F2");
            stringkpiTwo = stringkpiTwo.Replace(".", ",");
            addPayEmployee.SetTxb_kpiTwo(stringkpiTwo);

            string stringOtpusk = otpusk.ToString("F2");
            stringOtpusk = stringOtpusk.Replace(".", ",");
            addPayEmployee.SetTxb_Otpusk(stringOtpusk);

            string stringAvans = avans.ToString("F2");
            stringAvans = stringAvans.Replace(".", ",");
            addPayEmployee.SetTxb_Avans(stringAvans);

            addPayEmployee.SetDtp_Avans(dataAvans);

            string stringOtpuskPay = otpuskPay.ToString("F2");
            stringOtpuskPay = stringOtpuskPay.Replace(".", ",");
            addPayEmployee.SetTxb_PayOtpusk(stringOtpuskPay);

            addPayEmployee.SetDtp_Otpusk(dataotpuskPay);

            addPayEmployee.UpdateSuccess += AddOperatoin_UpdateSuccess;
            addPayEmployee.DeleteSuccess += AddOperatoin_DeleteSuccess;

            addPayEmployee.ShowDialog();
        }
        private void Dtp_start_ValueChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }
        private void Dtp_stop_ValueChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }
        private void Btn_download_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new()
            {
                Filter = "Excel Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*"
            };
            //openFileDialog.ShowDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                selectedFilePath = openFileDialog.FileName;
            }

            db.Connect();

        }
        private void Txb_search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_search.Text = "";
            }
        }
        private void Tbl_PayEmployee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_search.Text = "";
            }
        }
        private void AddPayEmployee_SaveSuccess(object? sender, EventArgs e)
        {
            UpdateDataGridView();

        }
        private void AddOperatoin_DeleteSuccess(object? sender, EventArgs e)
        {
            UpdateDataGridView();

        }
        private void AddOperatoin_UpdateSuccess(object? sender, EventArgs e)
        {
            UpdateDataGridView();

        }
        private string NameOrganization()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = RegistrationModel.USER_TABLE_User,
                searchField = RegistrationModel.NAME_ORGANIZATION,
                nameField = RegistrationModel.E_MAIL,
                valueField = Login,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();

            }
            return resultString;
        }
        private string NameOtdel()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = RegistrationModel.USER_TABLE_User,
                searchField = RegistrationModel.NAME_OTDEL,
                nameField = RegistrationModel.E_MAIL,
                valueField = Login,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }

            return resultString;
        }
        private void NameFieldsTableView()
        {
            Tbl_PayEmployee.Columns["dataOperation"].Width = 70;
            Tbl_PayEmployee.Columns["dataOperation"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["dataOperation"].HeaderText = "Дата операции";
            Tbl_PayEmployee.Columns["dataOperation"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["surnameUser"].Width = 90;
            Tbl_PayEmployee.Columns["surnameUser"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["surnameUser"].HeaderText = "ФИО сотрудника";
            Tbl_PayEmployee.Columns["surnameUser"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["nameOrganization"].Width = 80;
            Tbl_PayEmployee.Columns["nameOrganization"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["nameOrganization"].HeaderText = "Организация";
            Tbl_PayEmployee.Columns["nameOrganization"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["nameOtdel"].Width = 80;
            Tbl_PayEmployee.Columns["nameOtdel"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["nameOtdel"].HeaderText = "Отдел";
            Tbl_PayEmployee.Columns["nameOtdel"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["nameStaff"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["nameStaff"].HeaderText = "Должность";
            Tbl_PayEmployee.Columns["nameStaff"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["summNalichie"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["summNalichie"].HeaderText = "Процент из наличия";
            Tbl_PayEmployee.Columns["summNalichie"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["summZakaz"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["summZakaz"].HeaderText = "Процент под заказ";
            Tbl_PayEmployee.Columns["summZakaz"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["summSopytka"].Width = 100;
            Tbl_PayEmployee.Columns["summSopytka"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["summSopytka"].HeaderText = "Процент за сопутку";
            Tbl_PayEmployee.Columns["summSopytka"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["bonus"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["bonus"].HeaderText = "Бонусы";
            Tbl_PayEmployee.Columns["bonus"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["refund"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["refund"].HeaderText = "Возвраты";
            Tbl_PayEmployee.Columns["refund"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["oklad"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["oklad"].HeaderText = "Оклад";
            Tbl_PayEmployee.Columns["oklad"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["kpiOne"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["kpiOne"].HeaderText = "kpiOne";
            Tbl_PayEmployee.Columns["kpiOne"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["kpiTwo"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["kpiTwo"].HeaderText = "kpiTwo";
            Tbl_PayEmployee.Columns["kpiTwo"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["otpusk"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["otpusk"].HeaderText = "Отпусккные";
            Tbl_PayEmployee.Columns["otpusk"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["totalAccured"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["totalAccured"].HeaderText = "Итого начислено";
            Tbl_PayEmployee.Columns["totalAccured"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["avans"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["avans"].HeaderText = "Аванс";
            Tbl_PayEmployee.Columns["avans"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["dataAvans"].Width = 80;
            Tbl_PayEmployee.Columns["dataAvans"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["dataAvans"].HeaderText = "Дата аванса";
            Tbl_PayEmployee.Columns["dataAvans"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["otpuskPay"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["otpuskPay"].HeaderText = "Выплата отпускных";
            Tbl_PayEmployee.Columns["otpuskPay"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["dataOtpuskPay"].Width = 80;
            Tbl_PayEmployee.Columns["dataOtpuskPay"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["dataOtpuskPay"].HeaderText = "Дата отпускных";
            Tbl_PayEmployee.Columns["dataOtpuskPay"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["remains"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["remains"].HeaderText = "Задолженность перед сотрудником";
            Tbl_PayEmployee.Columns["remains"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_PayEmployee.Columns["discriptor"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_PayEmployee.Columns["discriptor"].HeaderText = "Дискриптор";
            Tbl_PayEmployee.Columns["discriptor"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
        private IEmplCreaterPayEmployee GetEmplCreaterPayEmployee()
        {
            return new PayEmployeeModel();
        }
        private IEmplShowPayEmployee GetEmplShowPayEmployee()
        {
            return new PayEmployeeModel();
        }
        private void Txb_search_TextChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();

        }
        private void Cbx_organization_TextChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }
        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
        private string NameRole()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = RegistrationModel.USER_TABLE_User,
                searchField = RegistrationModel.NAME_ROLE,
                nameField = RegistrationModel.E_MAIL,
                valueField = Login,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }
            return resultString;
        }
        private string AcceessRoleNameOrganization()
        {
            string role = NameRole();

            string nameOrganization;
            switch (role)
            {
                case "user":
                    nameOrganization = NameOrganization();
                    Cbx_organization.Enabled = false;
                    break;

                case "admin":
                    nameOrganization = Cbx_organization.Text;
                    break;

                case "директор":
                    nameOrganization = Cbx_organization.Text;
                    break;

                case "менеджер":
                    nameOrganization = NameOrganization();
                    Cbx_organization.Enabled = false;
                    break;

                case "бухгалтер":
                    nameOrganization = Cbx_organization.Text;
                    break;
                    
                case "руководитель":
                    nameOrganization = Cbx_organization.Text;                 
                    break;

                default:
                    nameOrganization = NameOrganization();
                    Cbx_organization.Enabled = false;
                    break;
            }
            return nameOrganization;
        }
        private string AcceessRoleNameOtdel()
        {
            string role = NameRole();
            string nameOtdel;
            switch (role)
            {
                case "user":
                    nameOtdel = NameOtdel();
                    Cbx_otdel.Enabled = false;
                    break;

                case "admin":
                    nameOtdel = Cbx_otdel.Text;
                    break;

                case "директор":
                    nameOtdel = Cbx_otdel.Text;
                    break;

                case "менеджер":
                    nameOtdel = NameOtdel();
                    Cbx_otdel.Enabled = false;
                    break;

                case "бухгалтер":
                    nameOtdel = NameOtdel();
                    Cbx_otdel.Enabled = false;
                    break;

                case "руководитель":
                    nameOtdel = Cbx_otdel.Text;
                    break;

                default:
                    nameOtdel = NameOtdel();
                    Cbx_otdel.Enabled = false;
                    break;
            }
            return nameOtdel;
        }

        private void Cbx_organization_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_organization.Items.Clear();
            string nameTable = Const.USER_TABLE_ORGANIZATION;
            string nameColumn = Const.NAME_ORGANIZATION;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_organization, nameColumn);
        }

        private void Cbx_otdel_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_otdel.Items.Clear();
            string nameTable = Const.USER_TABLE_OTDEL;
            string nameColumn = Const.NAME_OTDEL;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_otdel, nameColumn);
        }

        private void Cbx_otdel_TextChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }

        //private decimal PersentNalichie()
        //{
            //db.Connect();
            //AddPayEmployee addPayEmployee = new AddPayEmployee();
            

            //var arg = new SearchArgField()
            //{

            //    nameTable = MotivationModel.USER_TABLE_MOTIVATION,
            //    searchField = MotivationModel.PERSENT_NALICHIE,
            //    nameField = MotivationModel.NAME_STAFF,
            //    valueField = addPayEmployee.SetCbx_Staff(),
            //};
            //string searchField = QuerySelect.SearchField(arg);
            //DataTable result = db.ExecuteDataTable(searchField);

            //if (result.Rows.Count > 0)
            //{
            //    return Convert.ToDecimal(result.Rows[0][0]);
            //}
            //return 0;
        //}

        //private decimal PersentZakaz()
        //{
        //    db.Connect();
        //    var arg = new SearchArgField()
        //    {
        //        nameTable = MotivationModel.USER_TABLE_MOTIVATION,
        //        searchField = MotivationModel.PERSENT_ZAKAZ,
        //        nameField = MotivationModel.NAME_STAFF,
        //        valueField = Cbx_Staff.Text,
        //    };
        //    string searchField = QuerySelect.SearchField(arg);
        //    DataTable result = db.ExecuteDataTable(searchField);

        //    if (result.Rows.Count > 0)
        //    {
        //        return Convert.ToDecimal(result.Rows[0][0]);
        //    }
        //    return 0;
        //}

        //private decimal PersentSopytka()
        //{
        //    db.Connect();
        //    var arg = new SearchArgField()
        //    {
        //        nameTable = MotivationModel.USER_TABLE_MOTIVATION,
        //        searchField = MotivationModel.PERSENT_SOPYTKA,
        //        nameField = MotivationModel.NAME_STAFF,
        //        valueField = Cbx_Staff.Text,
        //    };
        //    string searchField = QuerySelect.SearchField(arg);
        //    DataTable result = db.ExecuteDataTable(searchField);

        //    if (result.Rows.Count > 0)
        //    {
        //        return Convert.ToDecimal(result.Rows[0][0]);
        //    }
        //    return 0;
        //}
    }
}

