﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System.Data;

namespace AIS.Forms
{
    public partial class Motivation : Form
    {
        private IQuerySelect _querySelect;

        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;

        public Motivation()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            ComboManage();

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;

            UpdateDataGridView();
            _ = ChangeOpacity();
        }

        public async Task ChangeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplCreator = GetEmplCreatorMotivation();
                string queryCreateTable = emplCreator.CreateTableMotivation();
                db.ExecuteNonQuery(queryCreateTable);

                if (!ValidateMotivation())
                {
                    return;
                }

                var emplInsert = GetEmplInsertMotivation();
                var arg = new InsertArgMotivation()
                {
                    nameOrganization = Cbx_organization.Text,
                    nameOtdel = Cbx_otdel.Text,
                    nameStaff = Cbx_staff.Text,
                    oklad = CorrectSummTextBox(Txb_Oklad),
                    kpiOne = CorrectSummTextBox(Txb_KpiOne),
                    kpiTwo = CorrectSummTextBox(Txb_KpiTwo),
                    persentNalichie = CorrectSummTextBox(Txb_Nalichie),
                    persentZakaz = CorrectSummTextBox(Txb_Zakaz),
                    persentSopytka = CorrectSummTextBox(Txb_Sopytka),
                };
                // Записываем данные в базу данных

                string insertQuery = emplInsert.InsertMotivation(arg);
                int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                if (numRowsInserted > 0)
                {
                    //MessageBox.Show("Данные успешно сохранены.");
                }
                else
                {
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);
                }

                UpdateDataGridView();
                ClearForm();
                ComboManage();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                // TODO првоерить весь код
                db.DisConnect();
            }
        }

        private string CorrectSummTextBox(TextBox textbox)
        {
            string inputsumm = textbox.Text;
            if (inputsumm.Contains(","))
            {
                // Заменяем запятую на точку
                inputsumm = inputsumm.Replace(",", ".");

                // Оставляем только два знака после точки
                int index = inputsumm.IndexOf(".");
                if (index != -1 && inputsumm.Length > index + 3)
                {
                    inputsumm = inputsumm.Substring(0, index + 3);
                }

                // Обновляем текст в поле ввода
                textbox.Text = inputsumm;
                textbox.SelectionStart = inputsumm.Length;
            }
            return inputsumm;
        }

        private void ComboManage()
        {
            Cbx_organization.FillDefaultValue("Название организации");

            Cbx_staff.FillDefaultValue("Название должности");

            Cbx_otdel.FillDefaultValue("Название подразделения");
        }

        private bool ValidateMotivation()
        {
            if (string.IsNullOrEmpty(Cbx_organization.SelectedItem as string) ||
                string.IsNullOrEmpty(Cbx_staff.SelectedItem as string) ||
                string.IsNullOrEmpty(Cbx_otdel.SelectedItem as string) ||
                string.IsNullOrEmpty(Txb_Oklad.Text as string) ||
                string.IsNullOrEmpty(Txb_KpiOne.Text as string) ||
                string.IsNullOrEmpty(Txb_KpiTwo.Text as string) ||
                string.IsNullOrEmpty(Txb_Nalichie.Text as string) ||
                string.IsNullOrEmpty(Txb_Zakaz.Text as string) ||
                string.IsNullOrEmpty(Txb_Sopytka.Text as string))
            {
                MessageBox.Show("Введите корректные данные");
                return false;
            }
            return true;
        }

        private void ClearForm()
        {
            Cbx_organization.Text = "";
            Cbx_staff.Text = "";
            Cbx_otdel.Text = "";
            Txb_id.Text = "";
            Txb_Oklad.Text = "";
            Txb_KpiOne.Text = "";
            Txb_KpiTwo.Text = "";
            Txb_Nalichie.Text = "";
            Txb_Zakaz.Text = "";
            Txb_Sopytka.Text = "";
        }

        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = MotivationModel.USER_TABLE_MOTIVATION;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                var emplCreator = GetEmplCreatorMotivation();
                string queryCreateTable = emplCreator.CreateTableMotivation();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_Motivation.DataSource = dataTable;

                Tbl_Motivation.Columns["id"].Width = 40;
                Tbl_Motivation.Columns["id"].HeaderText = "id";
                Tbl_Motivation.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                               
                Tbl_Motivation.Columns["nameOrganization"].Width = 120;
                Tbl_Motivation.Columns["nameOrganization"].HeaderText = "Организация";
                Tbl_Motivation.Columns["nameOrganization"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Motivation.Columns["nameOtdel"].Width = 100;
                Tbl_Motivation.Columns["nameOtdel"].HeaderText = "Подразделение";
                Tbl_Motivation.Columns["nameOtdel"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Motivation.Columns["nameStaff"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_Motivation.Columns["nameStaff"].HeaderText = "Должность";
                Tbl_Motivation.Columns["nameStaff"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Motivation.Columns["oklad"].Width = 85;
                Tbl_Motivation.Columns["oklad"].HeaderText = "Оклад";
                Tbl_Motivation.Columns["oklad"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["oklad"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["oklad"].DefaultCellStyle.Format = "N2";
                
                Tbl_Motivation.Columns["kpiOne"].Width = 85;
                Tbl_Motivation.Columns["kpiOne"].HeaderText = "kpiOne";
                Tbl_Motivation.Columns["kpiOne"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["kpiOne"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["kpiOne"].DefaultCellStyle.Format = "N2";
                
                Tbl_Motivation.Columns["kpiTwo"].Width = 85;
                Tbl_Motivation.Columns["kpiTwo"].HeaderText = "kpiTwo";
                Tbl_Motivation.Columns["kpiTwo"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["kpiTwo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["kpiTwo"].DefaultCellStyle.Format = "N2";
                
                Tbl_Motivation.Columns["persentNalichie"].Width = 85;
                Tbl_Motivation.Columns["persentNalichie"].HeaderText = "Процент из наличия";
                Tbl_Motivation.Columns["persentNalichie"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["persentNalichie"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                
                Tbl_Motivation.Columns["persentZakaz"].Width = 85;
                Tbl_Motivation.Columns["persentZakaz"].HeaderText = "Процент под заказ";
                Tbl_Motivation.Columns["persentZakaz"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["persentZakaz"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                
                Tbl_Motivation.Columns["persentSopytka"].Width = 85;
                Tbl_Motivation.Columns["persentSopytka"].HeaderText = "Процент за сопутку";
                Tbl_Motivation.Columns["persentSopytka"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Motivation.Columns["persentSopytka"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            db.DisConnect();
        }

        private void Tbl_Motivation_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                ClearForm();

                ComboManage();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Tbl_Motivation_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_Motivation.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string nameOrganization = selectedRow.Cells["nameOrganization"].Value.ToString();
                string nameOtdel = selectedRow.Cells["nameOtdel"].Value.ToString();
                string nameStaff = selectedRow.Cells["nameStaff"].Value.ToString();
                string oklad = selectedRow.Cells["oklad"].Value.ToString();
                string kpiOne = selectedRow.Cells["kpiOne"].Value.ToString();
                string kpiTwo = selectedRow.Cells["kpiTwo"].Value.ToString();
                string persentNalichie = selectedRow.Cells["persentNalichie"].Value.ToString();
                string persentZakaz = selectedRow.Cells["persentZakaz"].Value.ToString();
                string persentSopytka = selectedRow.Cells["persentSopytka"].Value.ToString();

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Cbx_organization.Text = nameOrganization;
                Cbx_otdel.Text = nameOtdel;
                Cbx_staff.Text = nameStaff;
                Txb_Oklad.Text = oklad; 
                Txb_KpiOne.Text = kpiOne;
                Txb_KpiTwo.Text = kpiTwo;
                Txb_Nalichie.Text = persentNalichie;
                Txb_Zakaz.Text = persentZakaz;
                Txb_Sopytka.Text = persentSopytka;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;
            }
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                string nameTable = MotivationModel.USER_TABLE_MOTIVATION;
                string condition = MotivationModel.ID + " = '" + Txb_id.Text + "'";
                string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
                db.ExecuteNonQuery(deleteQuery);

                UpdateDataGridView();
                ClearForm();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                // TODO првоерить весь код
                db.DisConnect();
            }
        }

        private void Cbx_organization_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_organization.Items.Clear();
            string nameTable = Const.USER_TABLE_ORGANIZATION;
            string nameColumn = Const.NAME_ORGANIZATION;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_organization, nameColumn);
        }

        private void Cbx_otdel_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_otdel.Items.Clear();
            string nameTable = Const.USER_TABLE_OTDEL;
            string nameColumn = Const.NAME_OTDEL;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_otdel, nameColumn);
        }

        private void Cbx_staff_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_staff.Items.Clear();
            string nameTable = Const.USER_TABLE_STAFF;
            string nameColumn = Const.NAME_STAFF;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_staff, nameColumn);
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplUpdate = GetEmplUpdateMotivation();
                var arg = new UpdateArgMotivation()
                {
                    nameTable = MotivationModel.USER_TABLE_MOTIVATION,
                    nameOrganization = Cbx_organization.Text,
                    nameOtdel = Cbx_otdel.Text,
                    nameStaff = Cbx_staff.Text,
                    oklad = CorrectSummTextBox(Txb_Oklad),
                    kpiOne = CorrectSummTextBox(Txb_KpiOne),
                    kpiTwo = CorrectSummTextBox(Txb_KpiTwo),
                    persentNalichie = CorrectSummTextBox(Txb_Nalichie),
                    persentZakaz = CorrectSummTextBox(Txb_Zakaz),
                    persentSopytka = CorrectSummTextBox(Txb_Sopytka),
                    id = Txb_id.Text
                };

                string queryUpdateLine = emplUpdate.UpdateMotivation(arg);
                int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);

                if (numRowsUpdated > 0) ;
                //MessageBox.Show("Данные успешно сохранены.");
                else
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);

                UpdateDataGridView();
                ClearForm();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        private void Cbx_organization_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_otdel_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_staff_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private IEmplCreatorMotivation GetEmplCreatorMotivation()
        {
            return new MotivationModel();
        }

        private IEmplInsertMotivation GetEmplInsertMotivation()
        {
            return new MotivationModel();
        }

        private IEmplUpdateMotivation GetEmplUpdateMotivation()
        {
            return new MotivationModel();
        }

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }
}
