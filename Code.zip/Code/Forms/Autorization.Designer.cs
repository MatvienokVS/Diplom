﻿namespace AIS
{
    partial class Autorization
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {

            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btn_exit = new Button();
            btn_registration = new Button();
            btn_enter = new Button();
            Txb_login = new TextBox();
            Txb_password = new TextBox();
            name_Form = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // btn_exit
            // 
            btn_exit.AutoEllipsis = true;
            btn_exit.BackColor = Color.FromArgb(98, 171, 180);
            btn_exit.FlatAppearance.BorderSize = 0;
            btn_exit.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            btn_exit.FlatStyle = FlatStyle.Flat;
            btn_exit.Font = new Font("Franklin Gothic Book", 9.75F);
            btn_exit.Location = new Point(297, 144);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(88, 27);
            btn_exit.TabIndex = 2;
            btn_exit.Text = "Выход";
            btn_exit.UseVisualStyleBackColor = false;
            btn_exit.Click += Btn_exit_Click;
            // 
            // btn_registration
            // 
            btn_registration.BackColor = Color.FromArgb(98, 171, 180);
            btn_registration.FlatAppearance.BorderSize = 0;
            btn_registration.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            btn_registration.FlatStyle = FlatStyle.Flat;
            btn_registration.Font = new Font("Franklin Gothic Book", 9.75F);
            btn_registration.Location = new Point(177, 144);
            btn_registration.Name = "btn_registration";
            btn_registration.Size = new Size(114, 27);
            btn_registration.TabIndex = 1;
            btn_registration.Text = "Регистрация";
            btn_registration.UseVisualStyleBackColor = false;
            btn_registration.Click += Btn_registration_Click;
            // 
            // btn_enter
            // 
            btn_enter.BackColor = Color.FromArgb(98, 171, 180);
            btn_enter.FlatAppearance.BorderSize = 0;
            btn_enter.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            btn_enter.FlatStyle = FlatStyle.Flat;
            btn_enter.Font = new Font("Franklin Gothic Book", 9.75F);
            btn_enter.Location = new Point(83, 144);
            btn_enter.Name = "btn_enter";
            btn_enter.Size = new Size(88, 27);
            btn_enter.TabIndex = 0;
            btn_enter.Text = "Войти";
            btn_enter.UseVisualStyleBackColor = false;
            btn_enter.Click += Btn_enter_Click;
            // 
            // Txb_login
            // 
            Txb_login.BackColor = Color.FromArgb(42, 54, 63);
            Txb_login.BorderStyle = BorderStyle.None;
            Txb_login.Font = new Font("Franklin Gothic Book", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_login.ForeColor = SystemColors.Info;
            Txb_login.Location = new Point(73, 50);
            Txb_login.Name = "Txb_login";
            Txb_login.PlaceholderText = "E-mail";
            Txb_login.Size = new Size(326, 22);
            Txb_login.TabIndex = 3;
            Txb_login.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_password
            // 
            Txb_password.BackColor = Color.FromArgb(42, 54, 63);
            Txb_password.BorderStyle = BorderStyle.None;
            Txb_password.Font = new Font("Franklin Gothic Book", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_password.ForeColor = SystemColors.Info;
            Txb_password.Location = new Point(73, 96);
            Txb_password.Name = "Txb_password";
            Txb_password.PasswordChar = '*';
            Txb_password.PlaceholderText = "Password";
            Txb_password.Size = new Size(326, 22);
            Txb_password.TabIndex = 4;
            Txb_password.TextAlign = HorizontalAlignment.Center;
            // 
            // name_Form
            // 
            name_Form.AutoSize = true;
            name_Form.BackColor = Color.FromArgb(42, 54, 63);
            name_Form.Font = new Font("Franklin Gothic Book", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            name_Form.ForeColor = SystemColors.Control;
            name_Form.Location = new Point(85, 9);
            name_Form.Name = "name_Form";
            name_Form.Size = new Size(300, 21);
            name_Form.TabIndex = 0;
            name_Form.Text = "Авторизация пользователя в АИС \"Бизнес\"";
            name_Form.TextAlign = ContentAlignment.TopCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.ActiveCaption;
            label1.Location = new Point(12, 191);
            label1.Name = "label1";
            label1.Size = new Size(125, 15);
            label1.TabIndex = 5;
            label1.Text = "© Матвиенок В.С., 2024";
            // 
            // Autorization
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            CancelButton = btn_exit;
            ClientSize = new Size(474, 215);
            Controls.Add(label1);
            Controls.Add(name_Form);
            Controls.Add(Txb_password);
            Controls.Add(Txb_login);
            Controls.Add(btn_enter);
            Controls.Add(btn_registration);
            Controls.Add(btn_exit);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Autorization";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Авторизация пользователя";
            ResumeLayout(false);
            PerformLayout();
        }

        private Button btn_exit;
        private Button btn_registration;
        private Button btn_enter;
        private TextBox Txb_login;
        private TextBox Txb_password;
        private Label name_Form;
        private Label label1;


        public string GetTxbLogin() { return Txb_login.Text; }
    }


}
