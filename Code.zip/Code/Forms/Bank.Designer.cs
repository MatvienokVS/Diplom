﻿namespace AIS.Forms
{
    partial class Bank
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DGW_kassa = new DataGridView();
            btn_report = new Button();
            button1 = new Button();
            button2 = new Button();
            Btn_cancel = new Button();
            Btn_bank = new Button();
            button4 = new Button();
            textBox1 = new TextBox();
            Dtp_start = new DateTimePicker();
            Dtp_stop = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)DGW_kassa).BeginInit();
            SuspendLayout();
            // 
            // DGW_kassa
            // 
            DGW_kassa.AllowUserToAddRows = false;
            DGW_kassa.AllowUserToDeleteRows = false;
            DGW_kassa.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGW_kassa.Location = new Point(190, 12);
            DGW_kassa.Name = "DGW_kassa";
            DGW_kassa.ReadOnly = true;
            DGW_kassa.Size = new Size(1398, 776);
            DGW_kassa.TabIndex = 0;
            // 
            // btn_report
            // 
            btn_report.BackColor = Color.FromArgb(98, 171, 180);
            btn_report.FlatAppearance.BorderSize = 0;
            btn_report.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            btn_report.FlatStyle = FlatStyle.Flat;
            btn_report.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btn_report.Location = new Point(12, 139);
            btn_report.Name = "btn_report";
            btn_report.Size = new Size(161, 23);
            btn_report.TabIndex = 2;
            btn_report.Text = "Загрузить выписку";
            btn_report.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(98, 171, 180);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button1.Location = new Point(12, 168);
            button1.Name = "button1";
            button1.Size = new Size(161, 23);
            button1.TabIndex = 3;
            button1.Text = "Удалить операцию";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(98, 171, 180);
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button2.Location = new Point(12, 197);
            button2.Name = "button2";
            button2.Size = new Size(161, 23);
            button2.TabIndex = 4;
            button2.Text = "Изменить операцию";
            button2.UseVisualStyleBackColor = false;
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Btn_cancel.Location = new Point(12, 765);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(161, 23);
            Btn_cancel.TabIndex = 10;
            Btn_cancel.Text = "Выход";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // Btn_bank
            // 
            Btn_bank.BackColor = Color.FromArgb(98, 171, 180);
            Btn_bank.FlatAppearance.BorderSize = 0;
            Btn_bank.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_bank.FlatStyle = FlatStyle.Flat;
            Btn_bank.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Btn_bank.Location = new Point(12, 15);
            Btn_bank.Name = "Btn_bank";
            Btn_bank.Size = new Size(161, 23);
            Btn_bank.TabIndex = 1;
            Btn_bank.Text = "БАНК  ----> { Касса }";
            Btn_bank.UseVisualStyleBackColor = false;
            Btn_bank.Click += Btn_bank_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(98, 171, 180);
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button4.Location = new Point(12, 226);
            button4.Name = "button4";
            button4.Size = new Size(161, 23);
            button4.TabIndex = 5;
            button4.Text = "Выгрузка данных";
            button4.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(98, 171, 180);
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBox1.Location = new Point(12, 255);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Поиск";
            textBox1.Size = new Size(161, 23);
            textBox1.TabIndex = 6;
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // Dtp_start
            // 
            Dtp_start.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Dtp_start.Location = new Point(12, 284);
            Dtp_start.Name = "Dtp_start";
            Dtp_start.Size = new Size(161, 21);
            Dtp_start.TabIndex = 7;
            Dtp_start.Value = new DateTime(2024, 1, 1, 0, 0, 0, 0);
            // 
            // Dtp_stop
            // 
            Dtp_stop.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Dtp_stop.Location = new Point(12, 311);
            Dtp_stop.Name = "Dtp_stop";
            Dtp_stop.Size = new Size(161, 21);
            Dtp_stop.TabIndex = 8;
            // 
            // Bank
            // 
            AutoScaleDimensions = new SizeF(8F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            ClientSize = new Size(1600, 800);
            Controls.Add(Dtp_stop);
            Controls.Add(Dtp_start);
            Controls.Add(textBox1);
            Controls.Add(button4);
            Controls.Add(Btn_bank);
            Controls.Add(Btn_cancel);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(btn_report);
            Controls.Add(DGW_kassa);
            Font = new Font("Franklin Gothic Book", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4);
            Name = "Bank";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bank_kassa";
            ((System.ComponentModel.ISupportInitialize)DGW_kassa).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView DGW_kassa;
        private Button btn_report;
        private Button button1;
        private Button button2;
        private Button Btn_cancel;
        private Button Btn_bank;
        private Button button4;
        private TextBox textBox1;
        private DateTimePicker Dtp_start;
        private DateTimePicker Dtp_stop;
    }
}