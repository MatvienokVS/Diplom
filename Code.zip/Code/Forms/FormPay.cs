﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System.Data;

namespace AIS.Forms
{
    public partial class FormPay : Form
    {
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;
        public string nameTable = FormPayModel.USER_TABLE_FORM_PAY;
        public string codePay = FormPayModel.CODE_PAY;
        public string nameFormPay = FormPayModel.NAME_FORM_PAY;

        public FormPay()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            UpdateDataGridView();
            //_ = changeOpacity();
        }

        //public async Task changeOpacity()
        //{
        //    ChangeOpacity _changeOpacity = new(this);
        //    await _changeOpacity._changeOpacity();
        //}

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Txb_code.Text) || string.IsNullOrEmpty(Txb_formPay.Text))
                {
                    MessageBox.Show("Введите код и форму оплаты");
                }
                else
                {
                    db.Connect();

                    string queryCreateTable = FormPayModel.CreateTableFormPay();
                    db.ExecuteNonQuery(queryCreateTable);

                    // Записываем данные в базу данных
                    string insertQuery = FormPayModel.InsertDataFormPay(Txb_code.Text, Txb_formPay.Text);
                    int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                    UpdateDataGridView();

                    if (numRowsInserted > 0) ;
                    //MessageBox.Show("Данные успешно сохранены.");
                    else
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);

                    Txb_code.Text = "";
                    Txb_formPay.Text = "";

                    db.DisConnect();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }
        public void UpdateDataGridView()
        {
            db.Connect();

            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                string queryCreateTable = FormPayModel.CreateTableFormPay();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_formPay.DataSource = dataTable;

                Tbl_formPay.Columns["id"].Width = 50;
                Tbl_formPay.Columns["id"].HeaderText = "id записи";
                Tbl_formPay.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_formPay.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_formPay.Columns["codePay"].Width = 60;
                Tbl_formPay.Columns["codePay"].HeaderText = "Код платежа";
                Tbl_formPay.Columns["codePay"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_formPay.Columns["codePay"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_formPay.Columns["nameFormPay"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_formPay.Columns["nameFormPay"].HeaderText = "Форма платежа";
                Tbl_formPay.Columns["nameFormPay"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            db.DisConnect();
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

            string condition = $"{codePay} = '{Txb_code.Text}'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            _ = db.ExecuteNonQuery(deleteQuery);

            UpdateDataGridView();

            Txb_code.Text = "";
            Txb_formPay.Text = "";
            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
        }

        private void Tbl_Staff_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_code.Text = "";
                Txb_formPay.Text = "";

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Tbl_Staff_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_formPay.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string code = selectedRow.Cells["codePay"].Value.ToString();
                string name = selectedRow.Cells["nameFormPay"].Value.ToString();

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Txb_code.Text = code;
                Txb_formPay.Text = name;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;
            }
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Txb_code.Text) || string.IsNullOrEmpty(Txb_formPay.Text))
                {
                    MessageBox.Show("Введите код и форму оплаты");
                }
                else
                {
                    db.Connect();

                    string nameTable = FormPayModel.USER_TABLE_FORM_PAY;
                    string id = Txb_id.Text;
                    string codePay = Txb_code.Text;
                    string nameFormPay = Txb_formPay.Text;

                    string queryUpdateLine = FormPayModel.UpdateDateFormPay(nameTable, id, codePay, nameFormPay);
                    int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);


                    UpdateDataGridView();

                    if (numRowsUpdated > 0) ;
                    //MessageBox.Show("Данные успешно сохранены.");
                    else
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);

                    Txb_id.Text = "";
                    Txb_code.Text = "";
                    Txb_formPay.Text = "";

                    Btn_update.Enabled = false;
                    Btn_update.BackColor = Color.LightGray;
                    Btn_delete.Enabled = false;
                    Btn_delete.BackColor = Color.LightGray;
                    Btn_save.Enabled = true;
                    Btn_save.BackColor = Color.FromArgb(98, 171, 180);

                    db.DisConnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }

        private IQuerySelect _querySelect;
        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }
}
