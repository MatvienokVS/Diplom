﻿namespace AIS.Forms
{
    partial class Motivation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Tbl_Motivation = new DataGridView();
            label1 = new Label();
            Btn_delete = new Button();
            Btn_update = new Button();
            Btn_save = new Button();
            Btn_cancel = new Button();
            Cbx_organization = new ComboBox();
            Cbx_otdel = new ComboBox();
            Cbx_staff = new ComboBox();
            Txb_id = new TextBox();
            Txb_Oklad = new TextBox();
            Txb_Nalichie = new TextBox();
            Txb_Zakaz = new TextBox();
            Txb_Sopytka = new TextBox();
            Txb_KpiOne = new TextBox();
            Txb_KpiTwo = new TextBox();
            ((System.ComponentModel.ISupportInitialize)Tbl_Motivation).BeginInit();
            SuspendLayout();
            // 
            // Tbl_Motivation
            // 
            Tbl_Motivation.AllowUserToAddRows = false;
            Tbl_Motivation.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(192, 255, 255);
            Tbl_Motivation.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Control;
            dataGridViewCellStyle2.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            Tbl_Motivation.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            Tbl_Motivation.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Window;
            dataGridViewCellStyle3.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle3.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            Tbl_Motivation.DefaultCellStyle = dataGridViewCellStyle3;
            Tbl_Motivation.Location = new Point(171, 32);
            Tbl_Motivation.Name = "Tbl_Motivation";
            Tbl_Motivation.ReadOnly = true;
            Tbl_Motivation.Size = new Size(977, 551);
            Tbl_Motivation.TabIndex = 1;
            Tbl_Motivation.CellDoubleClick += Tbl_Motivation_CellDoubleClick;
            Tbl_Motivation.KeyPress += Tbl_Motivation_KeyPress;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Franklin Gothic Book", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.Info;
            label1.Location = new Point(620, 9);
            label1.Name = "label1";
            label1.Size = new Size(82, 20);
            label1.TabIndex = 9;
            label1.Text = "Мотивация";
            // 
            // Btn_delete
            // 
            Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
            Btn_delete.FlatAppearance.BorderSize = 0;
            Btn_delete.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_delete.FlatStyle = FlatStyle.Flat;
            Btn_delete.Font = new Font("Franklin Gothic Book", 9F);
            Btn_delete.Location = new Point(857, 589);
            Btn_delete.Name = "Btn_delete";
            Btn_delete.Size = new Size(69, 25);
            Btn_delete.TabIndex = 12;
            Btn_delete.Text = "Удалить";
            Btn_delete.UseVisualStyleBackColor = false;
            Btn_delete.Click += Btn_delete_Click;
            // 
            // Btn_update
            // 
            Btn_update.BackColor = Color.FromArgb(98, 171, 180);
            Btn_update.FlatAppearance.BorderSize = 0;
            Btn_update.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_update.FlatStyle = FlatStyle.Flat;
            Btn_update.Font = new Font("Franklin Gothic Book", 9F);
            Btn_update.Location = new Point(931, 589);
            Btn_update.Name = "Btn_update";
            Btn_update.Size = new Size(69, 25);
            Btn_update.TabIndex = 13;
            Btn_update.Text = "Обновить";
            Btn_update.UseVisualStyleBackColor = false;
            Btn_update.Click += Btn_update_Click;
            // 
            // Btn_save
            // 
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            Btn_save.FlatAppearance.BorderSize = 0;
            Btn_save.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_save.FlatStyle = FlatStyle.Flat;
            Btn_save.Font = new Font("Franklin Gothic Book", 9F);
            Btn_save.Location = new Point(1005, 589);
            Btn_save.Name = "Btn_save";
            Btn_save.Size = new Size(69, 25);
            Btn_save.TabIndex = 14;
            Btn_save.Text = "Сохранить";
            Btn_save.UseVisualStyleBackColor = false;
            Btn_save.Click += Btn_save_Click;
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9F);
            Btn_cancel.Location = new Point(1079, 589);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(69, 25);
            Btn_cancel.TabIndex = 15;
            Btn_cancel.Text = "Отмена";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // Cbx_organization
            // 
            Cbx_organization.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_organization.FormattingEnabled = true;
            Cbx_organization.Location = new Point(12, 60);
            Cbx_organization.Name = "Cbx_organization";
            Cbx_organization.Size = new Size(151, 24);
            Cbx_organization.TabIndex = 2;
            Cbx_organization.Click += Cbx_organization_Click;
            Cbx_organization.KeyPress += Cbx_organization_KeyPress;
            // 
            // Cbx_otdel
            // 
            Cbx_otdel.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_otdel.FormattingEnabled = true;
            Cbx_otdel.Location = new Point(12, 90);
            Cbx_otdel.Name = "Cbx_otdel";
            Cbx_otdel.Size = new Size(151, 24);
            Cbx_otdel.TabIndex = 3;
            Cbx_otdel.Click += Cbx_otdel_Click;
            Cbx_otdel.KeyPress += Cbx_otdel_KeyPress;
            // 
            // Cbx_staff
            // 
            Cbx_staff.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_staff.FormattingEnabled = true;
            Cbx_staff.Location = new Point(12, 120);
            Cbx_staff.Name = "Cbx_staff";
            Cbx_staff.Size = new Size(151, 24);
            Cbx_staff.TabIndex = 4;
            Cbx_staff.Click += Cbx_staff_Click;
            Cbx_staff.KeyPress += Cbx_staff_KeyPress;
            // 
            // Txb_id
            // 
            Txb_id.BackColor = SystemColors.ControlLight;
            Txb_id.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_id.Location = new Point(12, 32);
            Txb_id.MaxLength = 35;
            Txb_id.Name = "Txb_id";
            Txb_id.PlaceholderText = "id записи";
            Txb_id.ReadOnly = true;
            Txb_id.Size = new Size(151, 22);
            Txb_id.TabIndex = 16;
            Txb_id.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_Oklad
            // 
            Txb_Oklad.Location = new Point(12, 204);
            Txb_Oklad.Name = "Txb_Oklad";
            Txb_Oklad.PlaceholderText = "Оклад";
            Txb_Oklad.Size = new Size(151, 21);
            Txb_Oklad.TabIndex = 7;
            // 
            // Txb_Nalichie
            // 
            Txb_Nalichie.Location = new Point(12, 231);
            Txb_Nalichie.Name = "Txb_Nalichie";
            Txb_Nalichie.PlaceholderText = "Процент из наличия";
            Txb_Nalichie.Size = new Size(151, 21);
            Txb_Nalichie.TabIndex = 8;
            // 
            // Txb_Zakaz
            // 
            Txb_Zakaz.Location = new Point(12, 258);
            Txb_Zakaz.Name = "Txb_Zakaz";
            Txb_Zakaz.PlaceholderText = "Процент под заказ";
            Txb_Zakaz.Size = new Size(151, 21);
            Txb_Zakaz.TabIndex = 9;
            // 
            // Txb_Sopytka
            // 
            Txb_Sopytka.Location = new Point(12, 285);
            Txb_Sopytka.Name = "Txb_Sopytka";
            Txb_Sopytka.PlaceholderText = "Процент за сопутку";
            Txb_Sopytka.Size = new Size(151, 21);
            Txb_Sopytka.TabIndex = 10;
            // 
            // Txb_KpiOne
            // 
            Txb_KpiOne.Location = new Point(12, 150);
            Txb_KpiOne.Name = "Txb_KpiOne";
            Txb_KpiOne.PlaceholderText = "Kpi One";
            Txb_KpiOne.Size = new Size(151, 21);
            Txb_KpiOne.TabIndex = 5;
            // 
            // Txb_KpiTwo
            // 
            Txb_KpiTwo.Location = new Point(12, 177);
            Txb_KpiTwo.Name = "Txb_KpiTwo";
            Txb_KpiTwo.PlaceholderText = "Kpi Two";
            Txb_KpiTwo.Size = new Size(151, 21);
            Txb_KpiTwo.TabIndex = 6;
            // 
            // Motivation
            // 
            AutoScaleDimensions = new SizeF(6F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            ClientSize = new Size(1160, 626);
            Controls.Add(Txb_KpiTwo);
            Controls.Add(Txb_KpiOne);
            Controls.Add(Txb_Sopytka);
            Controls.Add(Txb_Zakaz);
            Controls.Add(Txb_Nalichie);
            Controls.Add(Txb_Oklad);
            Controls.Add(Txb_id);
            Controls.Add(Cbx_staff);
            Controls.Add(Cbx_otdel);
            Controls.Add(Cbx_organization);
            Controls.Add(Tbl_Motivation);
            Controls.Add(label1);
            Controls.Add(Btn_delete);
            Controls.Add(Btn_update);
            Controls.Add(Btn_save);
            Controls.Add(Btn_cancel);
            Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Motivation";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Company";
            ((System.ComponentModel.ISupportInitialize)Tbl_Motivation).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView Tbl_Motivation;
        private Label label1;
        private Button Btn_delete;
        private Button Btn_update;
        private Button Btn_save;
        private Button Btn_cancel;
        private ComboBox Cbx_organization;
        private ComboBox Cbx_otdel;
        private ComboBox Cbx_staff;
        private TextBox Txb_id;
        private TextBox Txb_Oklad;
        private TextBox Txb_Nalichie;
        private TextBox Txb_Zakaz;
        private TextBox Txb_Sopytka;
        private TextBox Txb_KpiOne;
        private TextBox Txb_KpiTwo;
    }
}