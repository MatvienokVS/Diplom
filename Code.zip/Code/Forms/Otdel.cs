﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIS.Forms
{
    public partial class Otdel : Form
    {
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;
        public string nameTable = Const.USER_TABLE_OTDEL;
        public string codeOtdel = Const.CODE_OTDEL;


        public Otdel()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            UpdateDataGridView();
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Txb_code.Text) || string.IsNullOrEmpty(Txb_otdel.Text))
                {
                    MessageBox.Show("Введите код и наименование подразделения");
                }
                else
                {
                    db.Connect();

                    string queryCreateTable = OtdelModel.CreateTableOtdel();
                    db.ExecuteNonQuery(queryCreateTable);

                    // Записываем данные в базу данных
                    string insertQuery = OtdelModel.InsertDataOtdel(Txb_code.Text, Txb_otdel.Text);
                    int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                    UpdateDataGridView();

                    if (numRowsInserted > 0)
                    {
                        //MessageBox.Show("Данные успешно сохранены.");
                    }
                    else
                    {
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);
                    }
                    Txb_code.Text = "";
                    Txb_otdel.Text = "";

                    db.DisConnect();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }
        public void UpdateDataGridView()
        {
            db.Connect();

            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                string queryCreateTable = OtdelModel.CreateTableOtdel();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_otdel.DataSource = dataTable;

                Tbl_otdel.Columns["id"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_otdel.Columns["id"].HeaderText = "id записи";
                Tbl_otdel.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_otdel.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_otdel.Columns["codeOtdel"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_otdel.Columns["codeOtdel"].HeaderText = "Код отдела";
                Tbl_otdel.Columns["codeOtdel"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_otdel.Columns["codeOtdel"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_otdel.Columns["nameOtdel"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_otdel.Columns["nameOtdel"].HeaderText = "Наименование отдела";
                Tbl_otdel.Columns["nameOtdel"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_otdel.Columns["nameOtdel"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            db.DisConnect();
        }

        private void Tbl_otdel_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_otdel.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string code = selectedRow.Cells["codeOtdel"].Value.ToString();
                string name = selectedRow.Cells["nameOtdel"].Value.ToString();

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Txb_code.Text = code;
                Txb_otdel.Text = name;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;
            }
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

 
            string condition = $"{codeOtdel} = '{Txb_code.Text}'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            _ = db.ExecuteNonQuery(deleteQuery);

            UpdateDataGridView();

            Txb_code.Text = "";
            Txb_otdel.Text = "";
            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
        }

        private void Tbl_otdel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_code.Text = "";
                Txb_otdel.Text = "";

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Txb_code.Text) || string.IsNullOrEmpty(Txb_otdel.Text))
                {
                    MessageBox.Show("Введите код и форму оплаты");
                }
                else
                {
                    db.Connect();

                    string nameTable = OtdelModel.USER_TABLE_OTDEL;
                    string id = Txb_id.Text;
                    string codeOtdel = Txb_code.Text;
                    string nameOtdel = Txb_otdel.Text;

                    string queryUpdateLine = OtdelModel.UpdateDateOtdel(nameTable, id, codeOtdel, nameOtdel);
                    int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);


                    UpdateDataGridView();

                    if (numRowsUpdated > 0) ;
                    //MessageBox.Show("Данные успешно сохранены.");
                    else
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);

                    Txb_id.Text = "";
                    Txb_code.Text = "";
                    Txb_otdel.Text = "";

                    Btn_update.Enabled = false;
                    Btn_update.BackColor = Color.LightGray;
                    Btn_delete.Enabled = false;
                    Btn_delete.BackColor = Color.LightGray;
                    Btn_save.Enabled = true;
                    Btn_save.BackColor = Color.FromArgb(98, 171, 180);

                    db.DisConnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }

        private IQuerySelect _querySelect;
        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }
}
