﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using Microsoft.VisualBasic.Logging;
using System.Data;
using System.Globalization;

namespace AIS.Forms
{
    public partial class AddPayEmployee : Form
    {
        private IQuerySelect _querySelect;
        private readonly DB.DB db;
        public WindowMover _windowMover;
        public string nameTable = Const.USER_TABLE_KASSA;
        public string id = Const.ID;
        

        public AddPayEmployee()
        {
            InitializeComponent();
            //_windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            Dtp_dataOperation.Value = DateTime.Now;
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_addEmployee_Click(object sender, EventArgs e)
        {
            Forms.Employee employee = new();
            employee.ShowDialog();
        }

        private void Btn_addOrganization_Click(object sender, EventArgs e)
        {
            Forms.Organization organization = new();
            organization.ShowDialog();
        }

        private void Btn_addOtdel_Click(object sender, EventArgs e)
        {
            Forms.Otdel otdel = new();
            otdel.ShowDialog();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();
                var emplCreator = GetEmplCreaterPayEmployee();
                string queryCreateTable = emplCreator.CreateTablePayEmployee();
                db.ExecuteNonQuery(queryCreateTable);

                var emplInsert = GetEmplInsertAddPayEmployee();
                var arg = new InsertArgPayEmployee()
                {
                    dataOperation = Dtp_dataOperation.Value.Date,
                    surnameUser = Cbx_nameEmployee.Text,
                    nameOrganization = Cbx_organization.Text,
                    nameOtdel = Cbx_otdel.Text,
                    nameStaff = Cbx_Staff.Text,
                    summNalichie = Convert.ToDecimal(Txb_nalichie.Text) * PersentNalichie() / 100,
                    summZakaz = Convert.ToDecimal(Txb_zakaz.Text) * PersentZakaz() / 100,
                    summSopytka = Convert.ToDecimal(Txb_Soputka.Text) * PersentSopytka() / 100,
                    bonus = Convert.ToDecimal(Txb_Bonus.Text),
                    refund = Convert.ToDecimal(Txb_Refund.Text),
                    oklad = Convert.ToDecimal(Txb_oklad.Text),
                    //etalon
                    kpiOne = Convert.ToDecimal(Txb_kpiOne.Text) * PersentNalichie(),
                    kpiTwo = Convert.ToDecimal(Txb_kpiTwo.Text),
                    otpusk = Convert.ToDecimal(Txb_Otpusk.Text),
                    totalAccured = TotalAccured(), //расчёт
                    avans = Convert.ToDecimal(Txb_Avans.Text),
                    dataAvans = Dtp_Avans.Value.Date,
                    otpuskPay = Convert.ToDecimal(Txb_PayOtpusk.Text),
                    dataOtpuskPay = Dtp_Otpusk.Value.Date,
                    remains = Remains(), //расчёт
                    discriptor = Discriptor(),
                };

                if (!ValidateAddPayEmployee())
                {
                    return;
                }

                string insertQuery = emplInsert.InsertPayEmployee(arg);
                int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                SaveSuccess?.Invoke(this, null);

                if (numRowsInserted > 0)
                {
                    ClearForm();
                }
                else
                {
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        private decimal PersentNalichie() 
        { 
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = MotivationModel.USER_TABLE_MOTIVATION,
                searchField = MotivationModel.PERSENT_NALICHIE,
                nameField = MotivationModel.NAME_STAFF,
                valueField = Cbx_Staff.Text,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);

            if (result.Rows.Count > 0)
            {
                return Convert.ToDecimal(result.Rows[0][0]);             
            }
            return 0;
        }

        public void SetPersentNalichie()
        {
            decimal result = PersentNalichie();

        }

        private decimal PersentZakaz()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = MotivationModel.USER_TABLE_MOTIVATION,
                searchField = MotivationModel.PERSENT_ZAKAZ,
                nameField = MotivationModel.NAME_STAFF,
                valueField = Cbx_Staff.Text,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);

            if (result.Rows.Count > 0)
            {
                return Convert.ToDecimal(result.Rows[0][0]);
            }
            return 0;
        }

        private decimal PersentSopytka()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = MotivationModel.USER_TABLE_MOTIVATION,
                searchField = MotivationModel.PERSENT_SOPYTKA,
                nameField = MotivationModel.NAME_STAFF,
                valueField = Cbx_Staff.Text,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);

            if (result.Rows.Count > 0)
            {
                return Convert.ToDecimal(result.Rows[0][0]);
            }
            return 0;
        }

        private string CorrectSumm(TextBox textBox)
        {
            string inputsumm = textBox.Text;
            if (inputsumm.Contains(","))
            {
                // Заменяем запятую на точку
                inputsumm = inputsumm.Replace(",", ".");

                // Оставляем только два знака после точки
                int index = inputsumm.IndexOf(".");
                if (index != -1 && inputsumm.Length > index + 3)
                {
                    inputsumm = inputsumm.Substring(0, index + 3);
                }

                // Обновляем текст в поле ввода
                textBox.Text = inputsumm;
                textBox.SelectionStart = inputsumm.Length;
            }
            return inputsumm;
        }
        private string Discriptor()
        {
            string discriptor = Environment.UserName;
            return discriptor;
        }

        private decimal TotalAccured()
        {
            decimal summNalichie = decimal.Parse(Txb_nalichie.Text);
            decimal summZakaz = decimal.Parse(Txb_zakaz.Text);
            decimal summSopytka = decimal.Parse(Txb_Soputka.Text);
            decimal bonus = decimal.Parse(Txb_Bonus.Text);
            decimal refund = decimal.Parse(Txb_Refund.Text);
            decimal oklad = decimal.Parse(Txb_oklad.Text);
            decimal kpiOne = decimal.Parse(Txb_kpiOne.Text);
            decimal kpiTwo = decimal.Parse(Txb_kpiTwo.Text);
            decimal otpusk = decimal.Parse(Txb_Otpusk.Text);

            decimal totalAccured = summNalichie + summZakaz + summSopytka + bonus + refund + oklad + kpiOne + kpiTwo + otpusk;
            return totalAccured;
        }

        private decimal Remains()
        {
           
            decimal avans = decimal.Parse(Txb_Avans.Text);
            decimal otpuskPay = decimal.Parse(Txb_PayOtpusk.Text);
            decimal remains = - avans - otpuskPay;
            return remains;
        }

        private void Cbx_otdel_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_otdel.Items.Clear();
            string nameTable = Const.USER_TABLE_OTDEL;
            string nameColumn = Const.NAME_OTDEL;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_otdel, nameColumn);
        }

        private void Cbx_nameEmployee_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_nameEmployee.Items.Clear();
            string nameTable = EmployeesModel.USER_TABLE_EMPLOYEE;
            string nameColumn = EmployeesModel.SURNAME_USER;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_nameEmployee, nameColumn);
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

            string condition = $"{id} = '{Txb_id.Text}'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            db.ExecuteNonQuery(deleteQuery);

            DeleteSuccess?.Invoke(this, null);

            ClearForm();
            ViewButtonDoubleClick();
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplUpdate = GetEmplUpdateAddPayEmployee();
                var arg = new UpdateArgPayEmployee()
                {
                    nameTable = PayEmployeeModel.USER_TABLE_PAY_EMPLOYEE,
                    dataOperation = Dtp_dataOperation.Value.Date,
                    surnameUser = Cbx_nameEmployee.Text,
                    nameOrganization = Cbx_organization.Text,
                    nameOtdel = Cbx_otdel.Text,
                    nameStaff = Cbx_Staff.Text,
                    summNalichie = Convert.ToDecimal(Txb_nalichie.Text)*PersentNalichie()/100,
                    summZakaz = Convert.ToDecimal(Txb_zakaz.Text)*PersentZakaz()/100,
                    summSopytka = Convert.ToDecimal(Txb_Soputka.Text)*PersentSopytka()/100,
                    bonus = Convert.ToDecimal(Txb_Bonus.Text),
                    refund = Convert.ToDecimal(Txb_Refund.Text),
                    oklad = Convert.ToDecimal(Txb_oklad.Text),
                    kpiOne = Convert.ToDecimal(Txb_kpiOne.Text),
                    kpiTwo = Convert.ToDecimal(Txb_kpiTwo.Text),
                    otpusk = Convert.ToDecimal(Txb_Otpusk.Text),
                    avans = Convert.ToDecimal(Txb_Avans.Text),
                    dataAvans = Dtp_Avans.Value.Date,
                    otpuskPay = Convert.ToDecimal(Txb_PayOtpusk.Text),
                    dataOtpuskPay = Dtp_Otpusk.Value.Date,
                    id = Txb_id.Text,
                };
                string queryUpdateLine = emplUpdate.UpdatePayEmployee(arg);
                int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);

                UpdateSuccess?.Invoke(this, null);

                if (numRowsUpdated > 0)
                {
                    //MessageBox.Show("Данные успешно сохранены.");
                }
                else
                {
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);
                }
                ClearForm();
                ViewButtonDoubleClick();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
                this.Close();
            }
        }

        private void Cbx_nameEmployee_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_organization_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_otdel_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private IEmplCreaterPayEmployee GetEmplCreaterPayEmployee()
        {
            return new PayEmployeeModel();
        }

        private IEmplInsertPayEmployee GetEmplInsertAddPayEmployee()
        {
            return new PayEmployeeModel();
        }

        private IEmplUpdatePayEmployee GetEmplUpdateAddPayEmployee()
        {
            return new PayEmployeeModel();
        }

        private void ClearForm()
        {
            Txb_id.Text = "";
            Dtp_dataOperation.Value = DateTime.Now;
            Cbx_Staff.Text = "";
            Cbx_nameEmployee.Text = "";
            Txb_oklad.Text = "";
            Cbx_organization.Text = "";
            Cbx_otdel.Text = "";
        }
        private void ViewButtonDoubleClick()
        {
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
        }

        // TODO дописать валидацию
        private bool ValidateAddPayEmployee()
        {
            if (string.IsNullOrEmpty(Cbx_Staff.Text) ||
                string.IsNullOrEmpty(Txb_oklad.Text) ||
                string.IsNullOrEmpty(Cbx_organization.Text) ||
                string.IsNullOrEmpty(Cbx_otdel.Text))
            {
                MessageBox.Show("Введите данные финансовой операции");
                return false;
            }
            return true;
        }

        private void Cbx_organization_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_organization.Items.Clear();
            string nameTable = OrganizationModel.USER_TABLE_Organization;
            string nameColumn = OrganizationModel.NAME_ORGANIZATION;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_organization, nameColumn);
        }

        private void Btn_addStaff_Click(object sender, EventArgs e)
        {
            Staff staff = new Staff();
            staff.ShowDialog();
        }

        private void Cbx_Staff_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_nameEmployee.Items.Clear();
            string nameTable = StaffModel.USER_TABLE_STAFF;
            string nameColumn = StaffModel.NAME_STAFF;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_Staff, nameColumn);
        }
    

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }

        // TODO 1. почитать как создавать события
        // TODO 2 почитать про нотификациЮ (события от БД), чтобы получить обновы от других юзеров (в целом это звоется MS SQL insert notification)
        // https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/sql/enabling-query-notifications
        public event EventHandler SaveSuccess;
        public event EventHandler UpdateSuccess;
        public event EventHandler DeleteSuccess;

    }
}

