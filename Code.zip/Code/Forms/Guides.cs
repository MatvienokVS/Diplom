﻿using AIS.Func;

namespace AIS.Forms
{
    public partial class Guides : Form
    {
        public WindowMover _windowMover;


        public Guides()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            _ = ChangeOpacity();
        }

        public async Task ChangeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
            //MainForm mainForm = new();
            //mainForm.Show();
        }

        private void Btn_organization_Click(object sender, EventArgs e)
        {
            Organization organization = new();
            organization.ShowDialog();

        }

        private void Btn_otdel_Click(object sender, EventArgs e)
        {
            Otdel otdel = new();
            otdel.ShowDialog();
        }

        private void Btn_staff_Click(object sender, EventArgs e)
        {
            Staff staff = new();
            staff.ShowDialog();
        }

        private void Btn_company_Click(object sender, EventArgs e)
        {
            Company company = new();
            company.ShowDialog();
        }

        private void Btn_operation_Click(object sender, EventArgs e)
        {
            ArticleBDDS articleBDDS = new ArticleBDDS();
            articleBDDS.ShowDialog();
        }

        private void Btn_personal_Click(object sender, EventArgs e)
        {
            Employee employee = new();
            employee.ShowDialog();
        }

        private void Btn_formPay_Click(object sender, EventArgs e)
        {
            FormPay formPay = new();
            formPay.ShowDialog();
        }

        private void Btn_access_Click(object sender, EventArgs e)
        {
            Role role = new();
            role.ShowDialog();
        }

        private void Btn_motivation_Click(object sender, EventArgs e)
        {
            Motivation motivation = new Motivation();
            motivation.ShowDialog();
        }
    }
}
