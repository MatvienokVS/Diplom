﻿using AIS.DB;
using AIS.Func;
using AIS.Query;
using System.Data;


namespace AIS
{
    public partial class Autorization : Form
    {
        private IQuerySelect _querySelect;
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;

        public Autorization()
        {
            InitializeComponent();
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();
            _windowMover = new WindowMover(this);
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_exit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void Btn_registration_Click(object sender, EventArgs e)
        {

            Forms.Registration registration = new();
            registration.ShowDialog();
        }

        private void Btn_enter_Click(object sender, EventArgs e)
        {
            db.Connect();

            string nameTable = Const.USER_TABLE_User;
            string login = Txb_login.Text;
            string password = Txb_password.Text;

            //if (!Regex.IsMatch(login, @"^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$"))
            //{
            //    MessageBox.Show("Логин должен быть в формате email.");
            //    return;
            //}

            string SearchDataFotAuth = QuerySelect.SearchDataForAuth(nameTable, login, password);

            DataTable dataTable = db.ExecuteDataTable(SearchDataFotAuth);

            if (dataTable.Rows.Count > 0)
            {
                this.Hide();
                Forms.MainForm mainForm = new();
                mainForm.Login = login;
                mainForm.Show();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль!");
            }
            db.DisConnect();
        }

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }
}
