﻿namespace AIS.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_exit = new Button();
            btn_guides = new Button();
            Btn_bank_kassa = new Button();
            btn_credits = new Button();
            Btn_product = new Button();
            Btn_payment = new Button();
            Btn_report = new Button();
            lbl_CurrentDate = new Label();
            tabControl1 = new TabControl();
            Tp_maimPage = new TabPage();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            Lbl_link = new LinkLabel();
            Btn_Minimized = new Button();
            Btn_admin = new Button();
            tabControl1.SuspendLayout();
            Tp_maimPage.SuspendLayout();
            SuspendLayout();
            // 
            // btn_exit
            // 
            btn_exit.BackColor = Color.FromArgb(98, 171, 180);
            btn_exit.FlatAppearance.BorderSize = 0;
            btn_exit.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            btn_exit.FlatStyle = FlatStyle.Flat;
            btn_exit.Location = new Point(12, 840);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(161, 23);
            btn_exit.TabIndex = 0;
            btn_exit.Text = "Выход";
            btn_exit.UseVisualStyleBackColor = false;
            btn_exit.Click += btn_exit_Click;
            // 
            // btn_guides
            // 
            btn_guides.BackColor = Color.FromArgb(98, 171, 180);
            btn_guides.FlatAppearance.BorderSize = 0;
            btn_guides.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            btn_guides.FlatStyle = FlatStyle.Flat;
            btn_guides.Location = new Point(12, 182);
            btn_guides.Name = "btn_guides";
            btn_guides.Size = new Size(161, 23);
            btn_guides.TabIndex = 1;
            btn_guides.Text = "Справочники";
            btn_guides.UseVisualStyleBackColor = false;
            btn_guides.Click += btn_guides_Click;
            // 
            // Btn_bank_kassa
            // 
            Btn_bank_kassa.BackColor = Color.FromArgb(98, 171, 180);
            Btn_bank_kassa.FlatAppearance.BorderSize = 0;
            Btn_bank_kassa.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_bank_kassa.FlatStyle = FlatStyle.Flat;
            Btn_bank_kassa.Location = new Point(12, 211);
            Btn_bank_kassa.Name = "Btn_bank_kassa";
            Btn_bank_kassa.Size = new Size(161, 23);
            Btn_bank_kassa.TabIndex = 2;
            Btn_bank_kassa.Text = "Банк и касса";
            Btn_bank_kassa.UseVisualStyleBackColor = false;
            Btn_bank_kassa.Click += Btn_bank_kassa_Click;
            // 
            // btn_credits
            // 
            btn_credits.BackColor = Color.FromArgb(98, 171, 180);
            btn_credits.FlatAppearance.BorderSize = 0;
            btn_credits.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            btn_credits.FlatStyle = FlatStyle.Flat;
            btn_credits.Location = new Point(12, 240);
            btn_credits.Name = "btn_credits";
            btn_credits.Size = new Size(161, 23);
            btn_credits.TabIndex = 3;
            btn_credits.Text = "Кредиты и займы";
            btn_credits.UseVisualStyleBackColor = false;
            // 
            // Btn_product
            // 
            Btn_product.BackColor = Color.FromArgb(98, 171, 180);
            Btn_product.FlatAppearance.BorderSize = 0;
            Btn_product.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_product.FlatStyle = FlatStyle.Flat;
            Btn_product.Location = new Point(12, 269);
            Btn_product.Name = "Btn_product";
            Btn_product.Size = new Size(161, 23);
            Btn_product.TabIndex = 4;
            Btn_product.Text = "Товар и доставка";
            Btn_product.UseVisualStyleBackColor = false;
            // 
            // Btn_payment
            // 
            Btn_payment.BackColor = Color.FromArgb(98, 171, 180);
            Btn_payment.FlatAppearance.BorderSize = 0;
            Btn_payment.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_payment.FlatStyle = FlatStyle.Flat;
            Btn_payment.Location = new Point(12, 298);
            Btn_payment.Name = "Btn_payment";
            Btn_payment.Size = new Size(161, 23);
            Btn_payment.TabIndex = 5;
            Btn_payment.Text = "Зарплата";
            Btn_payment.UseVisualStyleBackColor = false;
            Btn_payment.Click += Btn_payment_Click;
            // 
            // Btn_report
            // 
            Btn_report.BackColor = Color.FromArgb(98, 171, 180);
            Btn_report.FlatAppearance.BorderSize = 0;
            Btn_report.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_report.FlatStyle = FlatStyle.Flat;
            Btn_report.Location = new Point(12, 327);
            Btn_report.Name = "Btn_report";
            Btn_report.Size = new Size(161, 23);
            Btn_report.TabIndex = 6;
            Btn_report.Text = "Отчёты";
            Btn_report.UseVisualStyleBackColor = false;
            // 
            // lbl_CurrentDate
            // 
            lbl_CurrentDate.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lbl_CurrentDate.AutoSize = true;
            lbl_CurrentDate.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            lbl_CurrentDate.ForeColor = SystemColors.Info;
            lbl_CurrentDate.Location = new Point(12, 866);
            lbl_CurrentDate.Name = "lbl_CurrentDate";
            lbl_CurrentDate.Size = new Size(41, 15);
            lbl_CurrentDate.TabIndex = 7;
            lbl_CurrentDate.Text = "сборка";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Tp_maimPage);
            tabControl1.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            tabControl1.Location = new Point(181, 41);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1572, 846);
            tabControl1.TabIndex = 8;
            // 
            // Tp_maimPage
            // 
            Tp_maimPage.BackColor = Color.FromArgb(42, 54, 63);
            Tp_maimPage.Controls.Add(label4);
            Tp_maimPage.Controls.Add(label3);
            Tp_maimPage.Controls.Add(label2);
            Tp_maimPage.Controls.Add(label1);
            Tp_maimPage.Location = new Point(4, 24);
            Tp_maimPage.Name = "Tp_maimPage";
            Tp_maimPage.Padding = new Padding(3);
            Tp_maimPage.Size = new Size(1564, 818);
            Tp_maimPage.TabIndex = 0;
            Tp_maimPage.Text = "Главное окно";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.ForeColor = SystemColors.Info;
            label4.Location = new Point(18, 46);
            label4.Name = "label4";
            label4.Size = new Size(73, 17);
            label4.TabIndex = 3;
            label4.Text = "LabelView";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.ForeColor = SystemColors.Info;
            label3.Location = new Point(18, 16);
            label3.Name = "label3";
            label3.Size = new Size(347, 17);
            label3.TabIndex = 2;
            label3.Text = "Остаток денежных средств в кассах подразделений";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.ForeColor = SystemColors.Info;
            label2.Location = new Point(1185, 46);
            label2.Name = "label2";
            label2.Size = new Size(73, 17);
            label2.TabIndex = 1;
            label2.Text = "LabelView";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.Info;
            label1.Location = new Point(1185, 16);
            label1.Name = "label1";
            label1.Size = new Size(360, 17);
            label1.TabIndex = 0;
            label1.Text = "Оперативность внесения данных по подразделениям";
            // 
            // Lbl_link
            // 
            Lbl_link.AutoSize = true;
            Lbl_link.Font = new Font("Franklin Gothic Book", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Lbl_link.LinkColor = SystemColors.Info;
            Lbl_link.Location = new Point(12, 12);
            Lbl_link.Name = "Lbl_link";
            Lbl_link.Size = new Size(91, 21);
            Lbl_link.TabIndex = 10;
            Lbl_link.TabStop = true;
            Lbl_link.Text = "linkLabel1";
            // 
            // Btn_Minimized
            // 
            Btn_Minimized.BackColor = Color.FromArgb(98, 171, 180);
            Btn_Minimized.FlatAppearance.BorderColor = Color.FromArgb(98, 171, 180);
            Btn_Minimized.FlatAppearance.BorderSize = 0;
            Btn_Minimized.FlatStyle = FlatStyle.Flat;
            Btn_Minimized.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Btn_Minimized.Location = new Point(1726, 8);
            Btn_Minimized.Name = "Btn_Minimized";
            Btn_Minimized.Size = new Size(23, 25);
            Btn_Minimized.TabIndex = 4;
            Btn_Minimized.Text = "_";
            Btn_Minimized.UseVisualStyleBackColor = false;
            Btn_Minimized.Click += Btn_Minimized_Click;
            // 
            // Btn_admin
            // 
            Btn_admin.BackColor = Color.FromArgb(98, 171, 180);
            Btn_admin.FlatAppearance.BorderSize = 0;
            Btn_admin.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_admin.FlatStyle = FlatStyle.Flat;
            Btn_admin.Location = new Point(12, 811);
            Btn_admin.Name = "Btn_admin";
            Btn_admin.Size = new Size(161, 23);
            Btn_admin.TabIndex = 11;
            Btn_admin.Text = "Администрирование";
            Btn_admin.UseVisualStyleBackColor = false;
            Btn_admin.Click += Btn_admin_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            ClientSize = new Size(1765, 899);
            Controls.Add(Btn_admin);
            Controls.Add(Btn_Minimized);
            Controls.Add(Lbl_link);
            Controls.Add(lbl_CurrentDate);
            Controls.Add(tabControl1);
            Controls.Add(Btn_report);
            Controls.Add(Btn_payment);
            Controls.Add(Btn_product);
            Controls.Add(btn_credits);
            Controls.Add(Btn_bank_kassa);
            Controls.Add(btn_guides);
            Controls.Add(btn_exit);
            Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.None;
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainForm";
            Load += MainForm_Load;
            tabControl1.ResumeLayout(false);
            Tp_maimPage.ResumeLayout(false);
            Tp_maimPage.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_exit;
        private Button btn_guides;
        private Button Btn_bank_kassa;
        private Button btn_credits;
        private Button Btn_product;
        private Button Btn_payment;
        private Button Btn_report;
        private Label lbl_CurrentDate;
        private TabControl tabControl1;

        public TabControl GetTabControl() { return tabControl1; }

        private TabPage Tp_maimPage;
        private LinkLabel Lbl_link;
        private Label label2;
        private Label label1;
        private Label label4;
        private Label label3;
        private Button Btn_Minimized;
        private Button Btn_admin;
    }
}