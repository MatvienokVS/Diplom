﻿namespace AIS.Forms
{
    partial class GuidesAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Btn_cancel = new Button();
            Lbl_guides = new Label();
            Btn_access = new Button();
            Btn_personal = new Button();
            Btn_otdelAccess = new Button();
            Btn_organizationAccess = new Button();
            SuspendLayout();
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_cancel.Location = new Point(107, 362);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(243, 23);
            Btn_cancel.TabIndex = 4;
            Btn_cancel.Text = "Отмена";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // Lbl_guides
            // 
            Lbl_guides.AutoSize = true;
            Lbl_guides.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Lbl_guides.ForeColor = SystemColors.Info;
            Lbl_guides.Location = new Point(154, 18);
            Lbl_guides.Name = "Lbl_guides";
            Lbl_guides.Size = new Size(146, 17);
            Lbl_guides.TabIndex = 6;
            Lbl_guides.Text = "Панель администратора";
            // 
            // Btn_access
            // 
            Btn_access.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_access.BackColor = Color.FromArgb(98, 171, 180);
            Btn_access.FlatAppearance.BorderSize = 0;
            Btn_access.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_access.FlatStyle = FlatStyle.Flat;
            Btn_access.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_access.Location = new Point(107, 78);
            Btn_access.Name = "Btn_access";
            Btn_access.Size = new Size(243, 23);
            Btn_access.TabIndex = 10;
            Btn_access.Text = "Права доступа";
            Btn_access.UseVisualStyleBackColor = false;
            Btn_access.Click += Btn_access_Click;
            // 
            // Btn_personal
            // 
            Btn_personal.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_personal.BackColor = Color.FromArgb(98, 171, 180);
            Btn_personal.FlatAppearance.BorderSize = 0;
            Btn_personal.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_personal.FlatStyle = FlatStyle.Flat;
            Btn_personal.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_personal.Location = new Point(107, 49);
            Btn_personal.Name = "Btn_personal";
            Btn_personal.Size = new Size(243, 23);
            Btn_personal.TabIndex = 9;
            Btn_personal.Text = "Зарегистрированные пользователи";
            Btn_personal.UseVisualStyleBackColor = false;
            Btn_personal.Click += Btn_personal_Click;
            // 
            // Btn_otdelAccess
            // 
            Btn_otdelAccess.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_otdelAccess.BackColor = Color.FromArgb(98, 171, 180);
            Btn_otdelAccess.FlatAppearance.BorderSize = 0;
            Btn_otdelAccess.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_otdelAccess.FlatStyle = FlatStyle.Flat;
            Btn_otdelAccess.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_otdelAccess.Location = new Point(107, 107);
            Btn_otdelAccess.Name = "Btn_otdelAccess";
            Btn_otdelAccess.Size = new Size(243, 23);
            Btn_otdelAccess.TabIndex = 11;
            Btn_otdelAccess.Text = "Доступ к подразделениям";
            Btn_otdelAccess.UseVisualStyleBackColor = false;
            Btn_otdelAccess.Click += button1_Click;
            // 
            // Btn_organizationAccess
            // 
            Btn_organizationAccess.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Btn_organizationAccess.BackColor = Color.FromArgb(98, 171, 180);
            Btn_organizationAccess.FlatAppearance.BorderSize = 0;
            Btn_organizationAccess.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_organizationAccess.FlatStyle = FlatStyle.Flat;
            Btn_organizationAccess.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_organizationAccess.Location = new Point(107, 136);
            Btn_organizationAccess.Name = "Btn_organizationAccess";
            Btn_organizationAccess.Size = new Size(243, 23);
            Btn_organizationAccess.TabIndex = 12;
            Btn_organizationAccess.Text = "Доступ к организациям ВГО";
            Btn_organizationAccess.UseVisualStyleBackColor = false;
            Btn_organizationAccess.Click += Btn_organizationAccess_Click;
            // 
            // GuidesAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            CancelButton = Btn_cancel;
            ClientSize = new Size(448, 412);
            Controls.Add(Btn_organizationAccess);
            Controls.Add(Btn_otdelAccess);
            Controls.Add(Btn_access);
            Controls.Add(Btn_personal);
            Controls.Add(Lbl_guides);
            Controls.Add(Btn_cancel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "GuidesAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Guides";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Btn_cancel;
        private Label Lbl_guides;
        private Button Btn_access;
        private Button Btn_personal;
        private Button Btn_otdelAccess;
        private Button Btn_organizationAccess;
    }
}