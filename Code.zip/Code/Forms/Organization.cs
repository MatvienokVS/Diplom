﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace AIS.Forms
{
    public partial class Organization : Form
    {
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;

        public Organization()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            UpdateDataGridView();
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                if (string.IsNullOrEmpty(Txb_code.Text) || string.IsNullOrEmpty(Txb_nameOrganization.Text))
                {
                    MessageBox.Show("Введите код и наименование организации");
                }
                else
                {
                    string queryCreateTable = OrganizationModel.CreateTableOrganization();
                    db.ExecuteNonQuery(queryCreateTable);

                    if (string.IsNullOrEmpty(Txb_code.Text) || string.IsNullOrEmpty(Txb_nameOrganization.Text))
                    {
                        MessageBox.Show("Введите код и наименование организации");
                    }

                    // Записываем данные в базу данных
                    string insertQuery = OrganizationModel.InsertDataOrganization(Txb_code.Text, Txb_nameOrganization.Text);
                    int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                    UpdateDataGridView();

                    if (numRowsInserted > 0) ;
                    //MessageBox.Show("Данные успешно сохранены.");
                    else
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);

                    Txb_id.Text = "";
                    Txb_code.Text = "";
                    Txb_nameOrganization.Text = "";

                    db.DisConnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }

        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = OrganizationModel.USER_TABLE_Organization;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                string queryCreateTable = OrganizationModel.CreateTableOrganization();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_orgznization.DataSource = dataTable;
                Tbl_orgznization.Columns["id"].Width = 50;
                Tbl_orgznization.Columns["id"].HeaderText = "id записи";
                Tbl_orgznization.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_orgznization.Columns["codeOrganization"].Width = 80;
                Tbl_orgznization.Columns["codeOrganization"].HeaderText = "Код организации";
                Tbl_orgznization.Columns["codeOrganization"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_orgznization.Columns["codeOrganization"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_orgznization.Columns["nameOrganization"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_orgznization.Columns["nameOrganization"].HeaderText = "Наименование организации";
                Tbl_orgznization.Columns["nameOrganization"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            db.DisConnect();
        }

        private void Tbl_orgznization_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_orgznization.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string code = selectedRow.Cells["codeOrganization"].Value.ToString();
                string name = selectedRow.Cells["nameOrganization"].Value.ToString();

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = code;
                Txb_code.Text = code;
                Txb_nameOrganization.Text = name;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;
            }
        }
        private void Tbl_orgznization_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_id.Text = "";
                Txb_code.Text = "";
                Txb_nameOrganization.Text = "";

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

            string nameTable = OrganizationModel.USER_TABLE_Organization;
            string condition = OrganizationModel.CODE_ORGANIZATION + " = '" + Txb_code.Text + "'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            _ = db.ExecuteNonQuery(deleteQuery);

            UpdateDataGridView();

            Txb_id.Text = "";
            Txb_code.Text = "";
            Txb_nameOrganization.Text = "";

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Txb_code.Text) || string.IsNullOrEmpty(Txb_nameOrganization.Text))
                {
                    MessageBox.Show("Введите код и наименование организации");
                }
                else
                {
                    db.Connect();

                    string nameTable = OrganizationModel.USER_TABLE_Organization;
                    string id = Txb_id.Text;
                    string code = Txb_code.Text;
                    string nameOrganization = Txb_nameOrganization.Text;

                    string queryUpdateLine = OrganizationModel.UpdateDateOrganization(nameTable, id, code, nameOrganization);
                    int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);

                    UpdateDataGridView();

                    if (numRowsUpdated > 0) ;
                    //MessageBox.Show("Данные успешно сохранены.");
                    else
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);

                    Txb_id.Text = "";
                    Txb_code.Text = "";
                    Txb_nameOrganization.Text = "";                

                    Btn_update.Enabled = false;
                    Btn_update.BackColor = Color.LightGray;
                    Btn_delete.Enabled = false;
                    Btn_delete.BackColor = Color.LightGray;
                    Btn_save.Enabled = true;
                    Btn_save.BackColor = Color.FromArgb(98, 171, 180);

                    db.DisConnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }

        private IQuerySelect _querySelect;
        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }
}
