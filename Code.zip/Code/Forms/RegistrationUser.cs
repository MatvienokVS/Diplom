﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System.Data;

namespace AIS.Forms
{
    public partial class RegistrationUser : Form
    {
        private IQuerySelect _querySelect;

        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;
        
        public RegistrationUser()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            ComboManage();

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;

            UpdateDataGridView();
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplCreator = GetEmplCreateTableRegistration();
                string queryCreateTable = emplCreator.CreateTableRegistration();
                db.ExecuteNonQuery(queryCreateTable);

                if (!ValidateRegistration())
                {
                    return;
                }

                var emplInsert = GetEmplInsertRegistration();
                var arg = new InsertArgRegistration()
                {
                    surname = Txb_surnameEmployee.Text,
                    name = Txb_nameEmployee.Text,
                    middleName = Txb_middlenameEmployee.Text,
                    nameOrganization = Cbx_organization.Text,
                    otdel = Cbx_otdel.Text,
                    nameStaff = Cbx_staff.Text,
                    email = Txb_email.Text,
                    password = Txb_password.Text,
                    nameRole = Cbx_Role.Text,
                };
                // Записываем данные в базу данных

                string insertQuery = emplInsert.InsertDataRegistration(arg);
                int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                if (numRowsInserted > 0)
                {
                    //MessageBox.Show("Данные успешно сохранены.");
                }
                else
                {
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);
                }

                UpdateDataGridView();
                ClearForm();
                ComboManage();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                // TODO првоерить весь код
                db.DisConnect();
            }
        }

        private void ComboManage()
        {
            Cbx_organization.FillDefaultValue("Название организации");

            Cbx_staff.FillDefaultValue("Название должности");

            Cbx_otdel.FillDefaultValue("Название подразделения");

            Cbx_Role.FillDefaultValue("Права доступа");
        }

        private bool ValidateRegistration()
        {
            if (string.IsNullOrEmpty(Txb_surnameEmployee.Text) ||
                string.IsNullOrEmpty(Txb_nameEmployee.Text) ||
                string.IsNullOrEmpty(Txb_middlenameEmployee.Text) ||
                string.IsNullOrEmpty(Txb_email.Text) ||
                string.IsNullOrEmpty(Txb_password.Text) ||
                string.IsNullOrEmpty(Cbx_organization.SelectedItem as string) ||
                string.IsNullOrEmpty(Cbx_staff.SelectedItem as string) ||
                string.IsNullOrEmpty(Cbx_otdel.SelectedItem as string))
            {
                MessageBox.Show("Введите данные пользователя");
                return false;
            }
            return true;
        }

        private void ClearForm()
        {
            Txb_email.Text = "";
            Txb_password.Text = "";
            Txb_surnameEmployee.Text = "";
            Txb_nameEmployee.Text = "";
            Txb_middlenameEmployee.Text = "";
            Cbx_organization.Text = "";
            Cbx_staff.Text = "";
            Cbx_otdel.Text = "";
            Txb_id.Text = "";
            Cbx_Role.Text = "";
        }

        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = RegistrationModel.USER_TABLE_User;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                var emplCreator = GetEmplCreateTableRegistration();
                string queryCreateTable = emplCreator.CreateTableRegistration();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_RegistrationUser.DataSource = dataTable;

                Tbl_RegistrationUser.Columns["id"].Width = 40;
                Tbl_RegistrationUser.Columns["id"].HeaderText = "id";
                Tbl_RegistrationUser.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_RegistrationUser.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_RegistrationUser.Columns["surnameUser"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_RegistrationUser.Columns["surnameUser"].HeaderText = "Фамилия";
                Tbl_RegistrationUser.Columns["surnameUser"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_RegistrationUser.Columns["nameUser"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_RegistrationUser.Columns["nameUser"].HeaderText = "Имя";
                Tbl_RegistrationUser.Columns["nameUser"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_RegistrationUser.Columns["middleName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_RegistrationUser.Columns["middleName"].HeaderText = "Отчество";
                Tbl_RegistrationUser.Columns["middleName"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_RegistrationUser.Columns["nameOrganization"].Width = 140;
                Tbl_RegistrationUser.Columns["nameOrganization"].HeaderText = "Организация";
                Tbl_RegistrationUser.Columns["nameOrganization"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_RegistrationUser.Columns["nameOtdel"].Width = 100;
                Tbl_RegistrationUser.Columns["nameOtdel"].HeaderText = "Подразделение";
                Tbl_RegistrationUser.Columns["nameOtdel"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_RegistrationUser.Columns["nameStaff"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_RegistrationUser.Columns["nameStaff"].HeaderText = "Должность";
                Tbl_RegistrationUser.Columns["nameStaff"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_RegistrationUser.Columns["email"].Width = 80;
                Tbl_RegistrationUser.Columns["email"].HeaderText = "email";
                Tbl_RegistrationUser.Columns["email"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_RegistrationUser.Columns["email"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_RegistrationUser.Columns["password"].Width = 80;
                Tbl_RegistrationUser.Columns["password"].HeaderText = "Password";
                Tbl_RegistrationUser.Columns["password"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_RegistrationUser.Columns["password"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_RegistrationUser.Columns["nameRole"].Width = 120;
                Tbl_RegistrationUser.Columns["nameRole"].HeaderText = "Роль в системе";
                Tbl_RegistrationUser.Columns["nameRole"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_RegistrationUser.Columns["nameRole"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            }
            db.DisConnect();
        }

        private void Tbl_RegistrationUser_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                ClearForm();

                ComboManage();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Tbl_RegistrationUser_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_RegistrationUser.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string surname = selectedRow.Cells["surnameUser"].Value.ToString();
                string name = selectedRow.Cells["nameUser"].Value.ToString();
                string middleName = selectedRow.Cells["middleName"].Value.ToString();
                string nameOrganization = selectedRow.Cells["nameOrganization"].Value.ToString();
                string otdel = selectedRow.Cells["nameOtdel"].Value.ToString();
                string nameStaff = selectedRow.Cells["nameStaff"].Value.ToString();
                string email = selectedRow.Cells["email"].Value.ToString();
                string password = selectedRow.Cells["password"].Value.ToString();
                string role = selectedRow.Cells["nameRole"].Value.ToString();

               

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Txb_surnameEmployee.Text = surname;
                Txb_nameEmployee.Text = name;
                Txb_middlenameEmployee.Text = middleName;
                Cbx_organization.Text = nameOrganization;
                Cbx_otdel.Text = otdel;
                Cbx_staff.Text = nameStaff;
                Txb_email.Text = email;
                Txb_password.Text = password;
                Cbx_Role.Text = role;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;

            }
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                string nameTable = RegistrationModel.USER_TABLE_User;
                string condition = RegistrationModel.E_MAIL + " = '" + Txb_email.Text + "'";
                string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
                db.ExecuteNonQuery(deleteQuery);

                UpdateDataGridView();
                ClearForm();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                // TODO првоерить весь код
                db.DisConnect();
            }
        }

        private void Cbx_organization_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_organization.Items.Clear();
            string nameTable = Const.USER_TABLE_ORGANIZATION;
            string nameColumn = Const.NAME_ORGANIZATION;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_organization, nameColumn);
        }

        private void Cbx_otdel_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_otdel.Items.Clear();
            string nameTable = Const.USER_TABLE_OTDEL;
            string nameColumn = Const.NAME_OTDEL;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_otdel, nameColumn);
        }

        private void Cbx_staff_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_staff.Items.Clear();
            string nameTable = Const.USER_TABLE_STAFF;
            string nameColumn = Const.NAME_STAFF;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_staff, nameColumn);
        }

        private void Cbx_Role_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_Role.Items.Clear();
            string nameTable = RoleModel.USER_TABLE_ROLE;
            string nameColumn = RoleModel.NAME_ROLE;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_Role, nameColumn);
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplUpdate = GetEmplUpdateRegistration();
                var arg = new UpdateArgRegistration()
                {
                    nameTable = RegistrationModel.USER_TABLE_User,
                    surname = Txb_surnameEmployee.Text,
                    name = Txb_nameEmployee.Text,
                    middleName = Txb_middlenameEmployee.Text,
                    nameOrganization = Cbx_organization.Text,
                    otdel = Cbx_otdel.Text,
                    nameStaff = Cbx_staff.Text,
                    email = Txb_email.Text,
                    password =Txb_password.Text,
                    nameRole =Cbx_Role.Text,
                    id = Txb_id.Text,
                };

                string queryUpdateLine = emplUpdate.UpdateDataRegistration(arg);
                int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);

                if (numRowsUpdated > 0) ;
                //MessageBox.Show("Данные успешно сохранены.");
                else
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);

                UpdateDataGridView();
                ClearForm();
                ComboManage();



                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        private void Cbx_organization_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_otdel_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_staff_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private IEmplCreatorRegistration GetEmplCreateTableRegistration()
        {
            return new RegistrationModel();
        }
        private IEmplInsertRegistration GetEmplInsertRegistration()
        {
            return new RegistrationModel();
        }
        private IEpmlUpdateRegistration GetEmplUpdateRegistration()
        {
            return new RegistrationModel();
        }
        

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }
}
