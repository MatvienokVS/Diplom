﻿using System.Windows.Forms;
using System.Xml.Linq;

namespace AIS.Forms
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Btn_addStaff = new Button();
            Btn_addOtdel = new Button();
            Btn_addOrganization = new Button();
            Cbx_staff = new ComboBox();
            Cbx_otdel = new ComboBox();
            Cbx_organization = new ComboBox();
            Txb_password = new TextBox();
            Txb_email = new TextBox();
            Txb_middleName = new TextBox();
            Txb_name = new TextBox();
            Txb_Surname = new TextBox();
            Btn_registration = new Button();
            Btn_exit = new Button();
            label1 = new Label();
            dataGridViewHelperBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)dataGridViewHelperBindingSource).BeginInit();
            SuspendLayout();
            // 
            // Btn_addStaff
            // 
            Btn_addStaff.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addStaff.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addStaff.FlatStyle = FlatStyle.Flat;
            Btn_addStaff.Location = new Point(350, 230);
            Btn_addStaff.Name = "Btn_addStaff";
            Btn_addStaff.Size = new Size(28, 23);
            Btn_addStaff.TabIndex = 0;
            Btn_addStaff.Text = "+";
            Btn_addStaff.UseVisualStyleBackColor = false;
            Btn_addStaff.Click += Btn_addStaff_Click;
            // 
            // Btn_addOtdel
            // 
            Btn_addOtdel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addOtdel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addOtdel.FlatStyle = FlatStyle.Flat;
            Btn_addOtdel.Location = new Point(350, 200);
            Btn_addOtdel.Name = "Btn_addOtdel";
            Btn_addOtdel.Size = new Size(28, 23);
            Btn_addOtdel.TabIndex = 0;
            Btn_addOtdel.Text = "+";
            Btn_addOtdel.UseVisualStyleBackColor = false;
            Btn_addOtdel.Click += Btn_addOtdel_Click;
            // 
            // Btn_addOrganization
            // 
            Btn_addOrganization.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addOrganization.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addOrganization.FlatStyle = FlatStyle.Flat;
            Btn_addOrganization.Location = new Point(350, 171);
            Btn_addOrganization.Name = "Btn_addOrganization";
            Btn_addOrganization.Size = new Size(28, 23);
            Btn_addOrganization.TabIndex = 0;
            Btn_addOrganization.Text = "+";
            Btn_addOrganization.UseVisualStyleBackColor = false;
            Btn_addOrganization.Click += Btn_addOrganization_Click;
            // 
            // Cbx_staff
            // 
            Cbx_staff.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_staff.FormattingEnabled = true;
            Cbx_staff.Location = new Point(37, 228);
            Cbx_staff.Name = "Cbx_staff";
            Cbx_staff.Size = new Size(298, 24);
            Cbx_staff.TabIndex = 6;
            Cbx_staff.Click += Cbx_staff_Click;
            Cbx_staff.KeyPress += Cbx_staff_KeyPress;
            // 
            // Cbx_otdel
            // 
            Cbx_otdel.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_otdel.FormattingEnabled = true;
            Cbx_otdel.Location = new Point(37, 199);
            Cbx_otdel.Name = "Cbx_otdel";
            Cbx_otdel.Size = new Size(298, 24);
            Cbx_otdel.TabIndex = 5;
            Cbx_otdel.Click += Cbx_otdel_Click;
            Cbx_otdel.KeyPress += Cbx_otdel_KeyPress;
            // 
            // Cbx_organization
            // 
            Cbx_organization.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_organization.FormattingEnabled = true;
            Cbx_organization.Location = new Point(37, 169);
            Cbx_organization.Name = "Cbx_organization";
            Cbx_organization.Size = new Size(298, 24);
            Cbx_organization.TabIndex = 4;
            Cbx_organization.Click += Cbx_organization_Click;
            Cbx_organization.KeyPress += Cbx_organization_KeyPress;
            // 
            // Txb_password
            // 
            Txb_password.Font = new Font("Franklin Gothic Book", 9F);
            Txb_password.Location = new Point(37, 286);
            Txb_password.Name = "Txb_password";
            Txb_password.PlaceholderText = "password";
            Txb_password.Size = new Size(298, 21);
            Txb_password.TabIndex = 8;
            // 
            // Txb_email
            // 
            Txb_email.Font = new Font("Franklin Gothic Book", 9F);
            Txb_email.Location = new Point(37, 257);
            Txb_email.Name = "Txb_email";
            Txb_email.PlaceholderText = "Email";
            Txb_email.Size = new Size(298, 21);
            Txb_email.TabIndex = 7;
            // 
            // Txb_middleName
            // 
            Txb_middleName.Font = new Font("Franklin Gothic Book", 9F);
            Txb_middleName.Location = new Point(37, 141);
            Txb_middleName.Name = "Txb_middleName";
            Txb_middleName.PlaceholderText = "Отчество";
            Txb_middleName.Size = new Size(298, 21);
            Txb_middleName.TabIndex = 3;
            // 
            // Txb_name
            // 
            Txb_name.Font = new Font("Franklin Gothic Book", 9F);
            Txb_name.Location = new Point(37, 112);
            Txb_name.Name = "Txb_name";
            Txb_name.PlaceholderText = "Имя";
            Txb_name.Size = new Size(298, 21);
            Txb_name.TabIndex = 2;
            // 
            // Txb_Surname
            // 
            Txb_Surname.Font = new Font("Franklin Gothic Book", 9F);
            Txb_Surname.ForeColor = SystemColors.InfoText;
            Txb_Surname.Location = new Point(37, 83);
            Txb_Surname.Name = "Txb_Surname";
            Txb_Surname.PlaceholderText = "Фамилия";
            Txb_Surname.Size = new Size(298, 21);
            Txb_Surname.TabIndex = 1;
            // 
            // Btn_registration
            // 
            Btn_registration.BackColor = Color.FromArgb(98, 171, 180);
            Btn_registration.FlatAppearance.BorderSize = 0;
            Btn_registration.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_registration.FlatStyle = FlatStyle.Flat;
            Btn_registration.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_registration.Location = new Point(76, 340);
            Btn_registration.Name = "Btn_registration";
            Btn_registration.Size = new Size(150, 27);
            Btn_registration.TabIndex = 9;
            Btn_registration.Text = "Зарегистрироваться";
            Btn_registration.UseVisualStyleBackColor = false;
            Btn_registration.Click += Btn_registration_Click;
            // 
            // Btn_exit
            // 
            Btn_exit.BackColor = Color.FromArgb(98, 171, 180);
            Btn_exit.FlatAppearance.BorderSize = 0;
            Btn_exit.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_exit.FlatStyle = FlatStyle.Flat;
            Btn_exit.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_exit.Location = new Point(232, 340);
            Btn_exit.Name = "Btn_exit";
            Btn_exit.Size = new Size(88, 27);
            Btn_exit.TabIndex = 10;
            Btn_exit.Text = "Отмена";
            Btn_exit.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Franklin Gothic Book", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.Menu;
            label1.Location = new Point(54, 32);
            label1.Name = "label1";
            label1.Size = new Size(298, 21);
            label1.TabIndex = 26;
            label1.Text = "Регистрация пользователя в АИС \"Бизнес\"";
            // 
            // Registration
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            CancelButton = Btn_exit;
            ClientSize = new Size(397, 404);
            Controls.Add(Btn_addStaff);
            Controls.Add(Btn_addOtdel);
            Controls.Add(Btn_addOrganization);
            Controls.Add(Cbx_staff);
            Controls.Add(Cbx_otdel);
            Controls.Add(Cbx_organization);
            Controls.Add(Txb_password);
            Controls.Add(Txb_email);
            Controls.Add(Txb_middleName);
            Controls.Add(Txb_name);
            Controls.Add(Txb_Surname);
            Controls.Add(Btn_registration);
            Controls.Add(Btn_exit);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Registration";
            StartPosition = FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)dataGridViewHelperBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Btn_addStaff;
        private Button Btn_addOtdel;
        private Button Btn_addOrganization;
        private ComboBox Cbx_staff;
        private ComboBox Cbx_otdel;
        private ComboBox Cbx_organization;
        private TextBox Txb_password;
        private TextBox Txb_email;
        private TextBox Txb_middleName;
        private TextBox Txb_name;
        private TextBox Txb_Surname;
        private Button Btn_registration;
        private Button Btn_exit;
        private Label label1;
        private BindingSource dataGridViewHelperBindingSource;
    }
}