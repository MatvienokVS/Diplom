﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System.Text.RegularExpressions;

namespace AIS.Forms
{

    public partial class Registration : Form
    {
        private IQuerySelect _querySelect;
        private readonly DB.DB db;
        public WindowMover _windowMover;

        public Registration()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);

            ComboManage();

            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }
        private void Btn_addOrganization_Click(object sender, EventArgs e)
        {
            Organization organization = new();
            organization.ShowDialog();
        }

        private void Btn_registration_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();
                var emplCreator = GetEmplCreatorRegistration();
                string queryCreateTable = emplCreator.CreateTableRegistration();

                db.ExecuteNonQuery(queryCreateTable);

                if (!ValidateRegistration())
                {
                    return;
                }
                // проверка правильности внесения email
                string login = Txb_email.Text;
                if (!Regex.IsMatch(login, @"^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$"))
                {
                    MessageBox.Show("Логин должен быть в формате email.");
                    return;
                }

                var emplInsert = GetEmplInsertRegistration();
                var arg = new InsertArgRegistration()
                {
                    surname = Txb_Surname.Text,
                    name = Txb_name.Text,
                    middleName = Txb_middleName.Text,
                    nameOrganization = Cbx_organization.Text,
                    otdel = Cbx_otdel.Text,
                    nameStaff = Cbx_staff.Text,
                    email = login,
                    password = Txb_password.Text,
                    nameRole = "user",
                };

                string insertQuery = emplInsert.InsertDataRegistration(arg);
                int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                if (numRowsInserted > 0)
                {
                    MessageBox.Show("Пользователь зарегистрирован");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Электронная почта уже используется "); //+ db.LastError);
                }

                ComboManage();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        private void Btn_addOtdel_Click(object sender, EventArgs e)
        {
            Forms.Otdel otdel = new();
            otdel.ShowDialog();
        }

        private void Btn_addStaff_Click(object sender, EventArgs e)
        {
            Forms.Staff staff = new();
            staff.ShowDialog();
        }

        private void Cbx_organization_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_organization.Items.Clear();
            string nameTable = RegistrationModel.USER_TABLE_Organization;
            string nameColumn = RegistrationModel.NAME_ORGANIZATION;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_organization, nameColumn);
            db.DisConnect();

            // TODO поиск для combobox
            //Cbx_organization.AutoCompleteMode = AutoCompleteMode.Suggest;
            //Cbx_organization.AutoCompleteSource = AutoCompleteSource.CustomSource;

            //AutoCompleteStringCollection autoCompleteCollection = new AutoCompleteStringCollection();

            //string searchQuery = Query.Const_Query.searchForCombobox(Const.NAME_ORGANIZATION,
            //                                                         Const.USER_TABLE_Organization,
            //                                                         Cbx_organization.Text);
            //DataTable searchResults = db.ExecuteDataTable(searchQuery);
            //// Здесь вы добавляете все возможные значения, по которым должен осуществляться поиск
            //foreach (DataRow row in searchResults.Rows)
            //{
            //    string value = row[nameColumn].ToString();
            //    autoCompleteCollection.Add(value);
            //}

            //Cbx_organization.AutoCompleteCustomSource = autoCompleteCollection;

        }

        private void Cbx_otdel_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_otdel.Items.Clear();
            string nameTable = RegistrationModel.USER_TABLE_OTDEL;
            string nameColumn = RegistrationModel.NAME_OTDEL;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_otdel, nameColumn);
            db.DisConnect();
        }

        private void Cbx_staff_Click(object sender, EventArgs e)
        {
            db.Connect();
            string nameTable = RegistrationModel.USER_TABLE_STAFF;
            string nameColumn = RegistrationModel.NAME_STAFF;
            Cbx_staff.Items.Clear();
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_staff, nameColumn);
            db.DisConnect();
        }

        private void ComboManage()
        {
            Cbx_organization.FillDefaultValue("Организация");

            Cbx_staff.FillDefaultValue("Должность");

            Cbx_otdel.FillDefaultValue("Отдел");
        }

        private bool ValidateRegistration()
        {
            if (string.IsNullOrEmpty(Txb_Surname.Text) ||
                string.IsNullOrEmpty(Txb_name.Text) ||
                string.IsNullOrEmpty(Txb_middleName.Text) ||
                string.IsNullOrEmpty(Txb_email.Text) ||
                string.IsNullOrEmpty(Txb_password.Text) ||
                string.IsNullOrEmpty(Cbx_organization.SelectedItem as string) ||
                string.IsNullOrEmpty(Cbx_staff.SelectedItem as string) ||
                string.IsNullOrEmpty(Cbx_otdel.SelectedItem as string))
            {
                MessageBox.Show("Введите данные сотрудника");
                return false;
            }

            return true;
        }

        private IEmplCreatorRegistration GetEmplCreatorRegistration()
        {
            return new RegistrationModel();
        }

        private IEmplInsertRegistration GetEmplInsertRegistration()
        {
            return new RegistrationModel();
        }

        private void Cbx_organization_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_otdel_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_staff_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }
}
