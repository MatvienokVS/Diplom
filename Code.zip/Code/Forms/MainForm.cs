﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System.Data;
using System.Reflection;
using System.Security.Cryptography;

namespace AIS.Forms
{
    public partial class MainForm : Form
    {
        readonly string curver = Assembly.GetExecutingAssembly().GetName().Version.ToString(2);
        public WindowMover _windowMover;
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        private IQuerySelect _querySelect;

        public string Login { get; set; }

        public MainForm()
        {
            InitializeComponent();

            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            lbl_CurrentDate.Text = $"Верcия программы {curver}";

            _windowMover = new WindowMover(this);
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_guides_Click(object sender, EventArgs e)
        {
            AcceessRole();
            Guides guides = new();
            guides.ShowDialog();
        }

        private void Btn_bank_kassa_Click(object sender, EventArgs e)
        {
            string namePage = KassaModel.USER_TABLE_KASSA;
            TabPage newTabPage = new(namePage);
            Kassa kassa = new();
            kassa.TopLevel = false;
            kassa.Dock = DockStyle.Fill;
            kassa.Login = Login;
            newTabPage.Controls.Add(kassa);
            tabControl1.TabPages.Add(newTabPage);
            tabControl1.SelectedTab = newTabPage;
            kassa.UpdateDataGridView();
            kassa.UpdateSumLabel();
            kassa.FillCbxOrganization();
            kassa.FillCbxOtdel();
            kassa.Show();            
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            Lbl_link.Text = Login;
            AcceessRole();
        }

        private void Btn_Minimized_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private string NameRole()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = RegistrationModel.USER_TABLE_User,
                searchField = RegistrationModel.NAME_ROLE,
                nameField = RegistrationModel.E_MAIL,
                valueField = Login,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }
            return resultString;
        }

        private void AcceessRole()
        {
            string role = NameRole();
            Guides guides = new();
            Kassa kassa =new Kassa();
            switch (role)
            {
                case "user":
                    btn_guides.Enabled = false;
                    btn_guides.BackColor = Color.LightGray;
                    Btn_bank_kassa.Enabled = true;
                    btn_credits.Enabled = false;
                    btn_credits.BackColor = Color.LightGray;
                    Btn_product.Enabled = false;
                    Btn_product.BackColor = Color.LightGray;
                    Btn_payment.Enabled = false;
                    Btn_payment.BackColor = Color.LightGray;
                    Btn_report.Enabled = false;
                    Btn_report.BackColor = Color.LightGray;
                    Btn_admin.Visible = false;
                    kassa.GetComboboxOrganization().Enabled = false;
                    kassa.GetComboboxOrganization().BackColor = Color.LightGray;
                    break;

                case "admin":
                    btn_guides.Enabled = true;
                    Btn_bank_kassa.Enabled = true;
                    btn_credits.Enabled = true;
                    Btn_product.Enabled = true;
                    Btn_payment.Enabled = true;
                    Btn_report.Enabled = true;
                    Btn_admin.Enabled = true;
                    kassa.GetComboboxOrganization().Enabled = true;
                    break;

                case "директор":

                    btn_guides.Enabled = true;
                    guides.GetButton().Enabled = false;
                    guides.GetButton().BackColor = Color.LightGray;
                    Btn_bank_kassa.Enabled = true;
                    btn_credits.Enabled = true;
                    Btn_product.Enabled = true;
                    Btn_payment.Enabled = true;
                    Btn_report.Enabled = true;
                    Btn_admin.Visible = false;
                    kassa.GetComboboxOrganization().Enabled = true;
                    break;

                case "менеджер":
                    btn_guides.Enabled = false;
                    btn_guides.BackColor = Color.LightGray;
                    Btn_bank_kassa.Enabled = true;
                    btn_credits.Enabled = false;
                    btn_credits.BackColor = Color.LightGray;
                    Btn_product.Enabled = false;
                    Btn_product.BackColor = Color.LightGray;
                    Btn_payment.Enabled = false;
                    Btn_payment.BackColor = Color.LightGray;
                    Btn_report.Enabled = false;
                    Btn_report.BackColor = Color.LightGray;
                    Btn_admin.Visible = false;
                    kassa.GetComboboxOrganization().Enabled = false;
                    kassa.GetComboboxOrganization().BackColor = Color.LightGray;
                    break;

                case "бухгалтер":

                    btn_guides.Enabled = false;
                    btn_guides.BackColor = Color.LightGray;
                    Btn_bank_kassa.Enabled = true;
                    btn_credits.Enabled = false;
                    btn_credits.BackColor = Color.LightGray;
                    Btn_product.Enabled = true;
                    Btn_payment.Enabled = false;
                    Btn_payment.BackColor = Color.LightGray;
                    Btn_report.Enabled = false;
                    Btn_report.BackColor = Color.LightGray;
                    Btn_admin.Visible = false;
                    kassa.GetComboboxOrganization().Enabled = false;
                    kassa.GetComboboxOrganization().BackColor = Color.LightGray;
                    break;

                    case "руководитель":

                    btn_guides.Enabled = false;
                    btn_guides.BackColor = Color.LightGray;
                    Btn_bank_kassa.Enabled = true;
                    btn_credits.Enabled = false;
                    btn_credits.BackColor = Color.LightGray;
                    Btn_product.Enabled = true;
                    Btn_payment.Enabled = true;                    
                    Btn_report.Enabled = false;
                    Btn_report.BackColor = Color.LightGray;
                    Btn_admin.Visible = false;
                    kassa.GetComboboxOrganization().Enabled = false;
                    kassa.GetComboboxOrganization().BackColor = Color.LightGray;
                    break;

                default:
                    btn_guides.Enabled = false;
                    btn_guides.BackColor = Color.LightGray;
                    Btn_bank_kassa.Enabled = false;
                    Btn_bank_kassa.BackColor = Color.LightGray;
                    btn_credits.Enabled = false;
                    btn_credits.BackColor = Color.LightGray;
                    Btn_product.Enabled = false;
                    Btn_product.BackColor = Color.LightGray;
                    Btn_payment.Enabled = false;
                    Btn_payment.BackColor = Color.LightGray;
                    Btn_report.Enabled = false;
                    Btn_report.BackColor = Color.LightGray;
                    Btn_admin.Visible = false;
                    kassa.GetComboboxOrganization().Enabled = false;
                    kassa.GetComboboxOrganization().BackColor = Color.LightGray;
                    break;
            }
        }

        private void Btn_admin_Click(object sender, EventArgs e)
        {
            GuidesAdmin guidesAdmin = new GuidesAdmin();
            guidesAdmin.ShowDialog();
        }

        private void Btn_payment_Click(object sender, EventArgs e)
        {
            string namePage = "Зарплата";
            TabPage newTabPage = new(namePage);
            PayEmployee payEmployee = new ();
            payEmployee.TopLevel = false;
            payEmployee.Dock = DockStyle.Fill;
            payEmployee.Login = Login;
            newTabPage.Controls.Add(payEmployee);
            tabControl1.TabPages.Add(newTabPage);
            tabControl1.SelectedTab = newTabPage;
            payEmployee.UpdateDataGridView();
            payEmployee.Show();
        }

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }
}

