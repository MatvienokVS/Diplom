﻿namespace AIS.Forms
{
    partial class Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Tbl_Employee = new DataGridView();
            label1 = new Label();
            Btn_delete = new Button();
            Btn_update = new Button();
            Btn_save = new Button();
            Btn_cancel = new Button();
            Txb_surnameEmployee = new TextBox();
            Txb_nameEmployee = new TextBox();
            Txb_middlenameEmployee = new TextBox();
            Txb_namberEmployee = new TextBox();
            Dtp_birthday = new DateTimePicker();
            Cbx_organization = new ComboBox();
            Cbx_otdel = new ComboBox();
            Cbx_staff = new ComboBox();
            Txb_id = new TextBox();
            ((System.ComponentModel.ISupportInitialize)Tbl_Employee).BeginInit();
            SuspendLayout();
            // 
            // Tbl_Employee
            // 
            Tbl_Employee.AllowUserToAddRows = false;
            Tbl_Employee.AllowUserToDeleteRows = false;
            Tbl_Employee.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Tbl_Employee.Location = new Point(171, 32);
            Tbl_Employee.Name = "Tbl_Employee";
            Tbl_Employee.ReadOnly = true;
            Tbl_Employee.Size = new Size(977, 551);
            Tbl_Employee.TabIndex = 1;
            Tbl_Employee.CellDoubleClick += Tbl_Employee_CellDoubleClick;
            Tbl_Employee.KeyPress += Tbl_Employee_KeyPress;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Franklin Gothic Book", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.Info;
            label1.Location = new Point(581, 9);
            label1.Name = "label1";
            label1.Size = new Size(172, 20);
            label1.TabIndex = 9;
            label1.Text = "Справочник сотрудников";
            // 
            // Btn_delete
            // 
            Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
            Btn_delete.FlatAppearance.BorderSize = 0;
            Btn_delete.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_delete.FlatStyle = FlatStyle.Flat;
            Btn_delete.Font = new Font("Franklin Gothic Book", 9F);
            Btn_delete.Location = new Point(857, 589);
            Btn_delete.Name = "Btn_delete";
            Btn_delete.Size = new Size(69, 25);
            Btn_delete.TabIndex = 10;
            Btn_delete.Text = "Удалить";
            Btn_delete.UseVisualStyleBackColor = false;
            Btn_delete.Click += Btn_delete_Click;
            // 
            // Btn_update
            // 
            Btn_update.BackColor = Color.FromArgb(98, 171, 180);
            Btn_update.FlatAppearance.BorderSize = 0;
            Btn_update.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_update.FlatStyle = FlatStyle.Flat;
            Btn_update.Font = new Font("Franklin Gothic Book", 9F);
            Btn_update.Location = new Point(931, 589);
            Btn_update.Name = "Btn_update";
            Btn_update.Size = new Size(69, 25);
            Btn_update.TabIndex = 11;
            Btn_update.Text = "Обновить";
            Btn_update.UseVisualStyleBackColor = false;
            Btn_update.Click += Btn_update_Click;
            // 
            // Btn_save
            // 
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            Btn_save.FlatAppearance.BorderSize = 0;
            Btn_save.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_save.FlatStyle = FlatStyle.Flat;
            Btn_save.Font = new Font("Franklin Gothic Book", 9F);
            Btn_save.Location = new Point(1005, 589);
            Btn_save.Name = "Btn_save";
            Btn_save.Size = new Size(69, 25);
            Btn_save.TabIndex = 12;
            Btn_save.Text = "Сохранить";
            Btn_save.UseVisualStyleBackColor = false;
            Btn_save.Click += Btn_save_Click;
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9F);
            Btn_cancel.Location = new Point(1079, 589);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(69, 25);
            Btn_cancel.TabIndex = 13;
            Btn_cancel.Text = "Отмена";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // Txb_surnameEmployee
            // 
            Txb_surnameEmployee.BackColor = SystemColors.ControlLight;
            Txb_surnameEmployee.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_surnameEmployee.Location = new Point(12, 60);
            Txb_surnameEmployee.MaxLength = 35;
            Txb_surnameEmployee.Name = "Txb_surnameEmployee";
            Txb_surnameEmployee.PlaceholderText = "Фамилия сотрудника";
            Txb_surnameEmployee.Size = new Size(151, 22);
            Txb_surnameEmployee.TabIndex = 2;
            Txb_surnameEmployee.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_nameEmployee
            // 
            Txb_nameEmployee.BackColor = SystemColors.ControlLight;
            Txb_nameEmployee.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_nameEmployee.Location = new Point(12, 87);
            Txb_nameEmployee.MaxLength = 30;
            Txb_nameEmployee.Name = "Txb_nameEmployee";
            Txb_nameEmployee.PlaceholderText = "Имя сотрудника";
            Txb_nameEmployee.Size = new Size(151, 22);
            Txb_nameEmployee.TabIndex = 3;
            Txb_nameEmployee.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_middlenameEmployee
            // 
            Txb_middlenameEmployee.BackColor = SystemColors.ControlLight;
            Txb_middlenameEmployee.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_middlenameEmployee.Location = new Point(12, 115);
            Txb_middlenameEmployee.MaxLength = 30;
            Txb_middlenameEmployee.Name = "Txb_middlenameEmployee";
            Txb_middlenameEmployee.PlaceholderText = "Отчество сотрудника";
            Txb_middlenameEmployee.Size = new Size(151, 22);
            Txb_middlenameEmployee.TabIndex = 4;
            Txb_middlenameEmployee.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_namberEmployee
            // 
            Txb_namberEmployee.BackColor = SystemColors.ControlLight;
            Txb_namberEmployee.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_namberEmployee.Location = new Point(12, 143);
            Txb_namberEmployee.MaxLength = 35;
            Txb_namberEmployee.Name = "Txb_namberEmployee";
            Txb_namberEmployee.PlaceholderText = "ИНН сотрудника";
            Txb_namberEmployee.Size = new Size(151, 22);
            Txb_namberEmployee.TabIndex = 5;
            Txb_namberEmployee.TextAlign = HorizontalAlignment.Center;
            // 
            // Dtp_birthday
            // 
            Dtp_birthday.Location = new Point(12, 261);
            Dtp_birthday.MinDate = new DateTime(1945, 1, 1, 0, 0, 0, 0);
            Dtp_birthday.Name = "Dtp_birthday";
            Dtp_birthday.Size = new Size(151, 21);
            Dtp_birthday.TabIndex = 9;
            Dtp_birthday.Value = new DateTime(2024, 1, 23, 13, 27, 43, 0);
            // 
            // Cbx_organization
            // 
            Cbx_organization.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_organization.FormattingEnabled = true;
            Cbx_organization.Location = new Point(12, 171);
            Cbx_organization.Name = "Cbx_organization";
            Cbx_organization.Size = new Size(151, 24);
            Cbx_organization.TabIndex = 6;
            Cbx_organization.Click += Cbx_organization_Click;
            Cbx_organization.KeyPress += Cbx_organization_KeyPress;
            // 
            // Cbx_otdel
            // 
            Cbx_otdel.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_otdel.FormattingEnabled = true;
            Cbx_otdel.Location = new Point(12, 201);
            Cbx_otdel.Name = "Cbx_otdel";
            Cbx_otdel.Size = new Size(151, 24);
            Cbx_otdel.TabIndex = 7;
            Cbx_otdel.Click += Cbx_otdel_Click;
            Cbx_otdel.KeyPress += Cbx_otdel_KeyPress;
            // 
            // Cbx_staff
            // 
            Cbx_staff.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_staff.FormattingEnabled = true;
            Cbx_staff.Location = new Point(12, 231);
            Cbx_staff.Name = "Cbx_staff";
            Cbx_staff.Size = new Size(151, 24);
            Cbx_staff.TabIndex = 8;
            Cbx_staff.Click += Cbx_staff_Click;
            Cbx_staff.KeyPress += Cbx_staff_KeyPress;
            // 
            // Txb_id
            // 
            Txb_id.BackColor = SystemColors.ControlLight;
            Txb_id.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_id.Location = new Point(12, 32);
            Txb_id.MaxLength = 35;
            Txb_id.Name = "Txb_id";
            Txb_id.PlaceholderText = "id записи";
            Txb_id.ReadOnly = true;
            Txb_id.Size = new Size(151, 22);
            Txb_id.TabIndex = 14;
            Txb_id.TextAlign = HorizontalAlignment.Center;
            // 
            // Employee
            // 
            AutoScaleDimensions = new SizeF(6F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            ClientSize = new Size(1160, 626);
            Controls.Add(Txb_id);
            Controls.Add(Cbx_staff);
            Controls.Add(Cbx_otdel);
            Controls.Add(Cbx_organization);
            Controls.Add(Dtp_birthday);
            Controls.Add(Txb_middlenameEmployee);
            Controls.Add(Txb_nameEmployee);
            Controls.Add(Tbl_Employee);
            Controls.Add(label1);
            Controls.Add(Btn_delete);
            Controls.Add(Btn_update);
            Controls.Add(Btn_save);
            Controls.Add(Txb_namberEmployee);
            Controls.Add(Btn_cancel);
            Controls.Add(Txb_surnameEmployee);
            Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Employee";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Company";
            ((System.ComponentModel.ISupportInitialize)Tbl_Employee).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView Tbl_Employee;
        private Label label1;
        private Button Btn_delete;
        private Button Btn_update;
        private Button Btn_save;
        private Button Btn_cancel;
        private TextBox Txb_surnameEmployee;
        private TextBox Txb_nameEmployee;
        private TextBox Txb_middlenameEmployee;
        private TextBox Txb_namberEmployee;
        private DateTimePicker Dtp_birthday;
        private ComboBox Cbx_organization;
        private ComboBox Cbx_otdel;
        private ComboBox Cbx_staff;
        private TextBox Txb_id;
    }
}