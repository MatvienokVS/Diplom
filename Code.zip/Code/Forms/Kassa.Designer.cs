﻿namespace AIS.Forms
{
    partial class Kassa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            Tbl_Kassa = new DataGridView();
            Btn_cancel = new Button();
            Btn_kassa = new Button();
            Btn_download = new Button();
            Txb_search = new TextBox();
            Dtp_start = new DateTimePicker();
            Dtp_stop = new DateTimePicker();
            Btn_addOperation = new Button();
            Lbl_initialBalance = new Label();
            Lbl_entrance = new Label();
            Lbl_expenses = new Label();
            Lbl_finalBalance = new Label();
            Cbx_organization = new ComboBox();
            Cbx_otdel = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)Tbl_Kassa).BeginInit();
            SuspendLayout();
            // 
            // Tbl_Kassa
            // 
            Tbl_Kassa.AllowUserToAddRows = false;
            Tbl_Kassa.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(192, 255, 255);
            dataGridViewCellStyle1.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle1.NullValue = null;
            Tbl_Kassa.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            Tbl_Kassa.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCellsExceptHeader;
            Tbl_Kassa.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            Tbl_Kassa.BorderStyle = BorderStyle.Fixed3D;
            Tbl_Kassa.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Info;
            dataGridViewCellStyle2.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.Info;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            Tbl_Kassa.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            Tbl_Kassa.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle3.BackColor = SystemColors.Window;
            dataGridViewCellStyle3.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle3.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            Tbl_Kassa.DefaultCellStyle = dataGridViewCellStyle3;
            Tbl_Kassa.Location = new Point(9, 44);
            Tbl_Kassa.Margin = new Padding(0);
            Tbl_Kassa.Name = "Tbl_Kassa";
            Tbl_Kassa.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.Info;
            dataGridViewCellStyle4.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            Tbl_Kassa.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Tbl_Kassa.RowsDefaultCellStyle = dataGridViewCellStyle5;
            Tbl_Kassa.ScrollBars = ScrollBars.Vertical;
            Tbl_Kassa.Size = new Size(1545, 739);
            Tbl_Kassa.TabIndex = 1;
            Tbl_Kassa.CellMouseDoubleClick += Tbl_Kassa_CellMouseDoubleClick;
            Tbl_Kassa.KeyPress += Tbl_Kassa_KeyPress;
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Btn_cancel.Location = new Point(1483, 15);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(71, 23);
            Btn_cancel.TabIndex = 17;
            Btn_cancel.Text = "Выход";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // Btn_kassa
            // 
            Btn_kassa.BackColor = Color.FromArgb(98, 171, 180);
            Btn_kassa.FlatAppearance.BorderSize = 0;
            Btn_kassa.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_kassa.FlatStyle = FlatStyle.Flat;
            Btn_kassa.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Btn_kassa.Location = new Point(9, 15);
            Btn_kassa.Name = "Btn_kassa";
            Btn_kassa.Size = new Size(136, 23);
            Btn_kassa.TabIndex = 1;
            Btn_kassa.Text = "КАССА ----> { Банк }";
            Btn_kassa.UseVisualStyleBackColor = false;
            // 
            // Btn_download
            // 
            Btn_download.BackColor = Color.FromArgb(98, 171, 180);
            Btn_download.FlatAppearance.BorderSize = 0;
            Btn_download.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_download.FlatStyle = FlatStyle.Flat;
            Btn_download.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Btn_download.Location = new Point(151, 15);
            Btn_download.Name = "Btn_download";
            Btn_download.Size = new Size(109, 23);
            Btn_download.TabIndex = 16;
            Btn_download.Text = "Выгрузка данных";
            Btn_download.UseVisualStyleBackColor = false;
            Btn_download.Click += Btn_download_Click;
            // 
            // Txb_search
            // 
            Txb_search.BackColor = Color.FromArgb(98, 171, 180);
            Txb_search.BorderStyle = BorderStyle.None;
            Txb_search.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_search.Location = new Point(1305, 15);
            Txb_search.Multiline = true;
            Txb_search.Name = "Txb_search";
            Txb_search.PlaceholderText = "Поиск";
            Txb_search.Size = new Size(172, 23);
            Txb_search.TabIndex = 13;
            Txb_search.TextAlign = HorizontalAlignment.Center;
            Txb_search.TextChanged += Txb_search_TextChanged;
            Txb_search.KeyPress += Txb_search_KeyPress;
            // 
            // Dtp_start
            // 
            Dtp_start.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Dtp_start.Location = new Point(1047, 17);
            Dtp_start.Name = "Dtp_start";
            Dtp_start.Size = new Size(123, 21);
            Dtp_start.TabIndex = 14;
            Dtp_start.Value = new DateTime(2024, 1, 1, 0, 0, 0, 0);
            // 
            // Dtp_stop
            // 
            Dtp_stop.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Dtp_stop.Location = new Point(1176, 17);
            Dtp_stop.Name = "Dtp_stop";
            Dtp_stop.Size = new Size(123, 21);
            Dtp_stop.TabIndex = 15;
            Dtp_stop.ValueChanged += Dtp_stop_ValueChanged;
            // 
            // Btn_addOperation
            // 
            Btn_addOperation.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addOperation.FlatAppearance.BorderSize = 0;
            Btn_addOperation.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addOperation.FlatStyle = FlatStyle.Flat;
            Btn_addOperation.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Btn_addOperation.Location = new Point(266, 15);
            Btn_addOperation.Name = "Btn_addOperation";
            Btn_addOperation.Size = new Size(111, 23);
            Btn_addOperation.TabIndex = 16;
            Btn_addOperation.Text = "Создать документ";
            Btn_addOperation.UseVisualStyleBackColor = false;
            Btn_addOperation.Click += Btn_addOperation_Click;
            // 
            // Lbl_initialBalance
            // 
            Lbl_initialBalance.AutoSize = true;
            Lbl_initialBalance.Font = new Font("Franklin Gothic Book", 11.25F);
            Lbl_initialBalance.ForeColor = SystemColors.Info;
            Lbl_initialBalance.Location = new Point(543, 792);
            Lbl_initialBalance.Name = "Lbl_initialBalance";
            Lbl_initialBalance.Size = new Size(48, 20);
            Lbl_initialBalance.TabIndex = 18;
            Lbl_initialBalance.Text = "label1";
            // 
            // Lbl_entrance
            // 
            Lbl_entrance.AutoSize = true;
            Lbl_entrance.Font = new Font("Franklin Gothic Book", 11.25F);
            Lbl_entrance.ForeColor = SystemColors.Info;
            Lbl_entrance.Location = new Point(841, 792);
            Lbl_entrance.Name = "Lbl_entrance";
            Lbl_entrance.Size = new Size(48, 20);
            Lbl_entrance.TabIndex = 18;
            Lbl_entrance.Text = "label1";
            // 
            // Lbl_expenses
            // 
            Lbl_expenses.AutoSize = true;
            Lbl_expenses.Font = new Font("Franklin Gothic Book", 11.25F);
            Lbl_expenses.ForeColor = SystemColors.Info;
            Lbl_expenses.Location = new Point(1065, 792);
            Lbl_expenses.Name = "Lbl_expenses";
            Lbl_expenses.Size = new Size(48, 20);
            Lbl_expenses.TabIndex = 18;
            Lbl_expenses.Text = "label1";
            // 
            // Lbl_finalBalance
            // 
            Lbl_finalBalance.AutoSize = true;
            Lbl_finalBalance.Font = new Font("Franklin Gothic Book", 11.25F);
            Lbl_finalBalance.ForeColor = SystemColors.Info;
            Lbl_finalBalance.Location = new Point(1279, 792);
            Lbl_finalBalance.Name = "Lbl_finalBalance";
            Lbl_finalBalance.Size = new Size(48, 20);
            Lbl_finalBalance.TabIndex = 18;
            Lbl_finalBalance.Text = "label1";
            // 
            // Cbx_organization
            // 
            Cbx_organization.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Cbx_organization.FormattingEnabled = true;
            Cbx_organization.Location = new Point(869, 15);
            Cbx_organization.Name = "Cbx_organization";
            Cbx_organization.Size = new Size(172, 23);
            Cbx_organization.TabIndex = 19;
            Cbx_organization.TextChanged += Cbx_organization_TextChanged;
            // 
            // Cbx_otdel
            // 
            Cbx_otdel.Font = new Font("Franklin Gothic Book", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Cbx_otdel.FormattingEnabled = true;
            Cbx_otdel.Location = new Point(691, 15);
            Cbx_otdel.Name = "Cbx_otdel";
            Cbx_otdel.Size = new Size(172, 23);
            Cbx_otdel.TabIndex = 20;
            Cbx_otdel.TextChanged += Cbx_otdel_TextChanged;
            // 
            // Kassa
            // 
            AutoScaleDimensions = new SizeF(8F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.FromArgb(42, 54, 63);
            ClientSize = new Size(1572, 858);
            Controls.Add(Cbx_otdel);
            Controls.Add(Cbx_organization);
            Controls.Add(Lbl_finalBalance);
            Controls.Add(Lbl_expenses);
            Controls.Add(Lbl_entrance);
            Controls.Add(Lbl_initialBalance);
            Controls.Add(Dtp_stop);
            Controls.Add(Dtp_start);
            Controls.Add(Txb_search);
            Controls.Add(Btn_addOperation);
            Controls.Add(Btn_download);
            Controls.Add(Btn_kassa);
            Controls.Add(Btn_cancel);
            Controls.Add(Tbl_Kassa);
            Font = new Font("Franklin Gothic Book", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4);
            Name = "Kassa";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bank_kassa";
            ((System.ComponentModel.ISupportInitialize)Tbl_Kassa).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView Tbl_Kassa;
        private Button Btn_cancel;
        private Button Btn_kassa;
        private Button Btn_download;
        private TextBox Txb_search;
        private DateTimePicker Dtp_start;
        private DateTimePicker Dtp_stop;
        private Button Btn_addOperation;
        private Label Lbl_initialBalance;
        private Label Lbl_entrance;
        private Label Lbl_expenses;
        private Label Lbl_finalBalance;
        private ComboBox Cbx_organization;

        public ComboBox GetComboboxOrganization() { return Cbx_organization; }

        private ComboBox Cbx_otdel;
    }

}