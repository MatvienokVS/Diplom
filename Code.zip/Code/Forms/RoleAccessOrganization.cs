﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using Microsoft.VisualBasic.Logging;
using System.Data;

namespace AIS.Forms
{
    public partial class RoleAccessOrganization : Form
    {
        private IQuerySelect _querySelect;

        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;

        public string Login { get; set; }

        public RoleAccessOrganization()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            UpdateDataGridView();
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();
                ValidateRoleAccess();

                var emplCreator = GetEmplCreatorRoleOrganizationAccess();
                string queryCreateTable = emplCreator.CreateTableRoleOrganizationAccess();
                db.ExecuteNonQuery(queryCreateTable);

                var emplInsert = GetEmplInsertRoleOrganizationAccess();
                var arg = new InsertArgRoleOrganizationAccess()
                {
                    nameTable = RoleAccessOrganizationModel.USER_TABLE_ROLE_ORGANIZATION_ACCESS,
                    id_organization = Cbx_idOrganization.Text,
                    id_role = Cbx_idRole.Text,
                };


                // Записываем данные в базу данных
                string insertQuery = emplInsert.InsertDataRoleOrganizationAccess(arg);
                int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                UpdateDataGridView();

                if (numRowsInserted > 0) ;
                //MessageBox.Show("Данные успешно сохранены.");
                else
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);

                ClearForm();
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = RoleAccessOrganizationModel.USER_TABLE_ROLE_ORGANIZATION_ACCESS;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                var emplCreator = GetEmplCreatorRoleOrganizationAccess();
                string queryCreateTable = emplCreator.CreateTableRoleOrganizationAccess();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_roleAccess.DataSource = dataTable;
                //Tbl_Staff.Columns["codeStaff"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_roleAccess.Columns["id"].Width = 50;
                Tbl_roleAccess.Columns["id"].HeaderText = "id записи";
                Tbl_roleAccess.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_roleAccess.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_roleAccess.Columns["idOrganization"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_roleAccess.Columns["idOrganization"].HeaderText = "id организации";
                Tbl_roleAccess.Columns["idOrganization"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_roleAccess.Columns["idRoles"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_roleAccess.Columns["idRoles"].HeaderText = "id роль";
                Tbl_roleAccess.Columns["idRoles"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            db.DisConnect();
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

            string nameTable = RoleAccessOrganizationModel.USER_TABLE_ROLE_ORGANIZATION_ACCESS;
            string condition = RoleAccessOtdelModel.ID + " = '" + Txb_id.Text + "'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            db.ExecuteNonQuery(deleteQuery);

            UpdateDataGridView();

            Txb_id.Text = "";
            Cbx_idOrganization.Text = "";
            Cbx_idRole.Text = "";
            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
        }

        private void Tbl_Staff_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_id.Text = "";
                Cbx_idOrganization.Text = "";

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Tbl_Staff_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_roleAccess.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string idOtdel = selectedRow.Cells["idOtdel"].Value.ToString();
                string idRoles = selectedRow.Cells["idRoles"].Value.ToString();

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Cbx_idOrganization.Text = idOtdel;
                Cbx_idRole.Text = idRoles;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;
            }
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();
                ValidateRoleAccess();

                var emplUpdate = GetEmplUpdateRoleOrganizationAccess();
                var arg = new UpdateArgRoleOrganizationAccess()
                {
                    nameTable = RoleAccessOrganizationModel.USER_TABLE_ROLE_ORGANIZATION_ACCESS,
                    id = Txb_id.Text,
                    id_organization = Cbx_idOrganization.Text,
                    id_role = Cbx_idRole.Text,
                };

                string queryUpdateLine = emplUpdate.UpdateDataRoleOrganizationAccess(arg);
                int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);

                UpdateDataGridView();

                if (numRowsUpdated > 0) ;
                //MessageBox.Show("Данные успешно сохранены.");
                else
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);

                ClearForm();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        private void ClearForm()
        {
            Cbx_idOrganization.Text = "";
            Cbx_idRole.Text = "";
        }

        private bool ValidateRoleAccess()
        {
            if (string.IsNullOrEmpty(Cbx_idOrganization.Text) || string.IsNullOrEmpty(Cbx_idRole.Text))
            {
                MessageBox.Show("Введите корректные данные");
                return false;
            }
            return true;
        }

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }

        private string NameRole()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = RegistrationModel.USER_TABLE_User,
                searchField = RegistrationModel.NAME_ROLE,
                nameField = RegistrationModel.E_MAIL,
                valueField = Login,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }
            return resultString;
        }

        private void Cbx_idRole_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_idRole.Items.Clear();
            string nameTable = RoleModel.USER_TABLE_ROLE;
            string nameColumn = RoleModel.NAME_ROLE;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_idRole, nameColumn);
        }
        private void Cbx_idOrganization_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_idOrganization.Items.Clear();
            string nameTable = OrganizationModel.USER_TABLE_Organization;
            string nameColumn = OrganizationModel.NAME_ORGANIZATION;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_idOrganization, nameColumn);
        }

        private IEmplCreatorRoleOrganizationAccess GetEmplCreatorRoleOrganizationAccess()
        {
            return new RoleAccessOrganizationModel();
        }
        private IEmplUpdateRoleOrganizationAccess GetEmplUpdateRoleOrganizationAccess()
        {
            return new RoleAccessOrganizationModel();
        }
        private IEmplInsertRoleOrganizationAccess GetEmplInsertRoleOrganizationAccess()
        {
            return new RoleAccessOrganizationModel();
        }

    }
}


