﻿using AIS.DB;
using AIS.Func;
using AIS.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIS.Forms
{
    public partial class Bank : Form
    {
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;

        public Bank()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();
            //_ = ChangeOpacity();
        }

        //public async Task ChangeOpacity()
        //{
        //    ChangeOpacity _changeOpacity = new(this);
        //    await _changeOpacity._changeOpacity();
        //}

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_bank_Click(object sender, EventArgs e)
        {

        }


        //public void UpdateDataGridView()
        //{
        //    db.Connect();

        //    string nameTable = Const.USER_TABLE_Organization;
        //    string checkQuery = Const_Query.CheckTableQuery(nameTable);
        //    int checkQueryResult = db.ExecuteNonQuery(checkQuery);
        //    if (checkQueryResult == 0)
        //    {
        //        string queryCreateTable = Query.Const_Query.CreateTableOrganization();
        //        db.ExecuteNonQuery(queryCreateTable);
        //    }
        //    else
        //    {
        //        string selectQuery = Const_Query.ShowAllStringFromTable(nameTable);
        //        DataTable dataTable = db.ExecuteDataTable(selectQuery);

        //        DGW_kassa.DataSource = dataTable;
        //        DGW_kassa.Columns["codeOrganization"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;               
        //        DGW_kassa.Columns["codeOrganization"].HeaderText = "Код организации";
        //        DGW_kassa.Columns["codeOrganization"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
        //    }
        //    db.DisConnect();
        //}
    }
}
