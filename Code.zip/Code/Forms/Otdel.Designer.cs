﻿namespace AIS.Forms
{
    partial class Otdel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            Tbl_otdel = new DataGridView();
            label1 = new Label();
            Btn_delete = new Button();
            Btn_update = new Button();
            Btn_save = new Button();
            Btn_cancel = new Button();
            Txb_otdel = new TextBox();
            Txb_code = new TextBox();
            Txb_id = new TextBox();
            ((System.ComponentModel.ISupportInitialize)Tbl_otdel).BeginInit();
            SuspendLayout();
            // 
            // Tbl_otdel
            // 
            Tbl_otdel.AllowUserToAddRows = false;
            Tbl_otdel.AllowUserToDeleteRows = false;
            Tbl_otdel.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCellsExceptHeader;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            Tbl_otdel.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            Tbl_otdel.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            Tbl_otdel.DefaultCellStyle = dataGridViewCellStyle2;
            Tbl_otdel.Location = new Point(12, 115);
            Tbl_otdel.Name = "Tbl_otdel";
            Tbl_otdel.ReadOnly = true;
            Tbl_otdel.Size = new Size(440, 279);
            Tbl_otdel.TabIndex = 1;
            Tbl_otdel.CellDoubleClick += Tbl_otdel_CellDoubleClick;
            Tbl_otdel.KeyPress += Tbl_otdel_KeyPress;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Franklin Gothic Book", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.Info;
            label1.Location = new Point(143, 7);
            label1.Name = "label1";
            label1.Size = new Size(192, 20);
            label1.TabIndex = 1;
            label1.Text = "Справочник подразделений";
            // 
            // Btn_delete
            // 
            Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
            Btn_delete.FlatAppearance.BorderSize = 0;
            Btn_delete.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_delete.FlatStyle = FlatStyle.Flat;
            Btn_delete.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_delete.Location = new Point(114, 407);
            Btn_delete.Name = "Btn_delete";
            Btn_delete.Size = new Size(80, 23);
            Btn_delete.TabIndex = 5;
            Btn_delete.Text = "Удалить";
            Btn_delete.UseVisualStyleBackColor = false;
            Btn_delete.Click += Btn_delete_Click;
            // 
            // Btn_update
            // 
            Btn_update.BackColor = Color.FromArgb(98, 171, 180);
            Btn_update.FlatAppearance.BorderSize = 0;
            Btn_update.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_update.FlatStyle = FlatStyle.Flat;
            Btn_update.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_update.Location = new Point(200, 407);
            Btn_update.Name = "Btn_update";
            Btn_update.Size = new Size(80, 23);
            Btn_update.TabIndex = 6;
            Btn_update.Text = "Обновить";
            Btn_update.UseVisualStyleBackColor = false;
            Btn_update.Click += Btn_update_Click;
            // 
            // Btn_save
            // 
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            Btn_save.FlatAppearance.BorderSize = 0;
            Btn_save.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_save.FlatStyle = FlatStyle.Flat;
            Btn_save.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_save.Location = new Point(286, 407);
            Btn_save.Name = "Btn_save";
            Btn_save.Size = new Size(80, 23);
            Btn_save.TabIndex = 7;
            Btn_save.Text = "Сохранить";
            Btn_save.UseVisualStyleBackColor = false;
            Btn_save.Click += Btn_save_Click;
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9.75F);
            Btn_cancel.Location = new Point(372, 407);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(80, 23);
            Btn_cancel.TabIndex = 8;
            Btn_cancel.Text = "Отмена";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // Txb_otdel
            // 
            Txb_otdel.BackColor = SystemColors.ControlLight;
            Txb_otdel.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_otdel.Location = new Point(113, 87);
            Txb_otdel.Name = "Txb_otdel";
            Txb_otdel.PlaceholderText = "Наименование подразделения";
            Txb_otdel.Size = new Size(253, 22);
            Txb_otdel.TabIndex = 4;
            Txb_otdel.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_code
            // 
            Txb_code.BackColor = SystemColors.ControlLight;
            Txb_code.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_code.Location = new Point(113, 58);
            Txb_code.Name = "Txb_code";
            Txb_code.PlaceholderText = "Код подразделения";
            Txb_code.Size = new Size(253, 22);
            Txb_code.TabIndex = 3;
            Txb_code.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_id
            // 
            Txb_id.BackColor = SystemColors.ControlLight;
            Txb_id.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_id.Location = new Point(113, 30);
            Txb_id.Name = "Txb_id";
            Txb_id.PlaceholderText = "id записи";
            Txb_id.ReadOnly = true;
            Txb_id.Size = new Size(253, 22);
            Txb_id.TabIndex = 2;
            Txb_id.TextAlign = HorizontalAlignment.Center;
            // 
            // Otdel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            ClientSize = new Size(464, 451);
            Controls.Add(Txb_id);
            Controls.Add(Txb_code);
            Controls.Add(Tbl_otdel);
            Controls.Add(label1);
            Controls.Add(Btn_delete);
            Controls.Add(Btn_update);
            Controls.Add(Btn_save);
            Controls.Add(Btn_cancel);
            Controls.Add(Txb_otdel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Otdel";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Otdel";
            ((System.ComponentModel.ISupportInitialize)Tbl_otdel).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView Tbl_otdel;
        private Label label1;
        private Button Btn_delete;
        private Button Btn_update;
        private Button Btn_save;
        private Button Btn_cancel;
        private TextBox Txb_otdel;
        private TextBox Txb_code;
        private TextBox Txb_id;
    }
}