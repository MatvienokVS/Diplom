﻿using System.Windows.Forms;
using System.Xml.Linq;

namespace AIS.Forms
{
    partial class AddOperatoin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Btn_addOrganization = new Button();
            label1 = new Label();
            Dtp_dataOperation = new DateTimePicker();
            label2 = new Label();
            label3 = new Label();
            Cbx_nameArticleBDDS = new ComboBox();
            label4 = new Label();
            Cbx_nameEmployee = new ComboBox();
            label5 = new Label();
            Txb_payment = new TextBox();
            label6 = new Label();
            Cbx_formPay = new ComboBox();
            label7 = new Label();
            Txb_summ = new TextBox();
            label8 = new Label();
            label9 = new Label();
            Cbx_organization = new ComboBox();
            label10 = new Label();
            Cbx_otdel = new ComboBox();
            Btn_addOtdel = new Button();
            Btn_addOperation = new Button();
            Btn_addEmployee = new Button();
            LL_linkOnDoc = new LinkLabel();
            Btn_delete = new Button();
            Btn_update = new Button();
            Btn_save = new Button();
            Btn_cancel = new Button();
            Txb_type = new TextBox();
            Txb_id = new TextBox();
            SuspendLayout();
            // 
            // Btn_addOrganization
            // 
            Btn_addOrganization.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addOrganization.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addOrganization.FlatStyle = FlatStyle.Flat;
            Btn_addOrganization.Location = new Point(517, 298);
            Btn_addOrganization.Name = "Btn_addOrganization";
            Btn_addOrganization.Size = new Size(28, 23);
            Btn_addOrganization.TabIndex = 0;
            Btn_addOrganization.Text = "+";
            Btn_addOrganization.UseVisualStyleBackColor = false;
            Btn_addOrganization.Click += Btn_addOrganization_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.Menu;
            label1.Location = new Point(23, 364);
            label1.Name = "label1";
            label1.Size = new Size(128, 17);
            label1.TabIndex = 54;
            label1.Text = "Связанный документ";
            // 
            // Dtp_dataOperation
            // 
            Dtp_dataOperation.Location = new Point(186, 17);
            Dtp_dataOperation.MinDate = new DateTime(1945, 1, 1, 0, 0, 0, 0);
            Dtp_dataOperation.Name = "Dtp_dataOperation";
            Dtp_dataOperation.Size = new Size(140, 23);
            Dtp_dataOperation.TabIndex = 1;
            Dtp_dataOperation.Value = new DateTime(2024, 1, 29, 0, 0, 0, 0);
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.ForeColor = SystemColors.Menu;
            label2.Location = new Point(23, 23);
            label2.Name = "label2";
            label2.Size = new Size(94, 17);
            label2.TabIndex = 28;
            label2.Text = "Дата операции";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label3.ForeColor = SystemColors.Menu;
            label3.Location = new Point(23, 53);
            label3.Name = "label3";
            label3.Size = new Size(154, 17);
            label3.TabIndex = 29;
            label3.Text = "Наименование операции";
            // 
            // Cbx_nameArticleBDDS
            // 
            Cbx_nameArticleBDDS.BackColor = SystemColors.Window;
            Cbx_nameArticleBDDS.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_nameArticleBDDS.FormattingEnabled = true;
            Cbx_nameArticleBDDS.Location = new Point(186, 46);
            Cbx_nameArticleBDDS.Name = "Cbx_nameArticleBDDS";
            Cbx_nameArticleBDDS.Size = new Size(313, 24);
            Cbx_nameArticleBDDS.Sorted = true;
            Cbx_nameArticleBDDS.TabIndex = 2;
            Cbx_nameArticleBDDS.SelectedIndexChanged += Cbx_nameOperation_SelectedIndexChanged;
            Cbx_nameArticleBDDS.Click += Cbx_nameArticleBDDS_Click;
            Cbx_nameArticleBDDS.KeyPress += Cbx_nameOperation_KeyPress;
            Cbx_nameArticleBDDS.KeyUp += Cbx_nameOperation_KeyUp;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label4.ForeColor = SystemColors.Menu;
            label4.Location = new Point(23, 83);
            label4.Name = "label4";
            label4.Size = new Size(94, 17);
            label4.TabIndex = 31;
            label4.Text = "Кто получил ДС";
            // 
            // Cbx_nameEmployee
            // 
            Cbx_nameEmployee.BackColor = SystemColors.Window;
            Cbx_nameEmployee.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_nameEmployee.FormattingEnabled = true;
            Cbx_nameEmployee.Location = new Point(186, 76);
            Cbx_nameEmployee.Name = "Cbx_nameEmployee";
            Cbx_nameEmployee.Size = new Size(313, 24);
            Cbx_nameEmployee.Sorted = true;
            Cbx_nameEmployee.TabIndex = 3;
            Cbx_nameEmployee.Click += Cbx_nameEmployee_Click;
            Cbx_nameEmployee.KeyPress += Cbx_nameEmployee_KeyPress;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label5.ForeColor = SystemColors.Menu;
            label5.Location = new Point(23, 114);
            label5.Name = "label5";
            label5.Size = new Size(127, 17);
            label5.TabIndex = 33;
            label5.Text = "Назначение платежа";
            // 
            // Txb_payment
            // 
            Txb_payment.BackColor = SystemColors.Window;
            Txb_payment.Font = new Font("Franklin Gothic Book", 9F);
            Txb_payment.Location = new Point(186, 106);
            Txb_payment.Multiline = true;
            Txb_payment.Name = "Txb_payment";
            Txb_payment.Size = new Size(359, 93);
            Txb_payment.TabIndex = 4;
            Txb_payment.TextChanged += Txb_payment_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label6.ForeColor = SystemColors.Menu;
            label6.Location = new Point(23, 212);
            label6.Name = "label6";
            label6.Size = new Size(98, 17);
            label6.TabIndex = 35;
            label6.Text = "Форма платежа";
            // 
            // Cbx_formPay
            // 
            Cbx_formPay.BackColor = SystemColors.Window;
            Cbx_formPay.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_formPay.FormattingEnabled = true;
            Cbx_formPay.Location = new Point(186, 205);
            Cbx_formPay.Name = "Cbx_formPay";
            Cbx_formPay.Size = new Size(140, 24);
            Cbx_formPay.Sorted = true;
            Cbx_formPay.TabIndex = 5;
            Cbx_formPay.Click += Cbx_formPay_Click;
            Cbx_formPay.KeyPress += Cbx_formPay_KeyPress;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label7.ForeColor = SystemColors.Menu;
            label7.Location = new Point(23, 243);
            label7.Name = "label7";
            label7.Size = new Size(96, 17);
            label7.TabIndex = 37;
            label7.Text = "Сумма платежа";
            // 
            // Txb_summ
            // 
            Txb_summ.BackColor = SystemColors.Window;
            Txb_summ.Font = new Font("Franklin Gothic Book", 9F);
            Txb_summ.Location = new Point(186, 235);
            Txb_summ.Multiline = true;
            Txb_summ.Name = "Txb_summ";
            Txb_summ.Size = new Size(140, 25);
            Txb_summ.TabIndex = 6;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label8.ForeColor = SystemColors.Menu;
            label8.Location = new Point(23, 274);
            label8.Name = "label8";
            label8.Size = new Size(87, 17);
            label8.TabIndex = 39;
            label8.Text = "Тип операции";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label9.ForeColor = SystemColors.Menu;
            label9.Location = new Point(23, 304);
            label9.Name = "label9";
            label9.Size = new Size(83, 17);
            label9.TabIndex = 41;
            label9.Text = "Организация";
            // 
            // Cbx_organization
            // 
            Cbx_organization.BackColor = SystemColors.Window;
            Cbx_organization.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_organization.FormattingEnabled = true;
            Cbx_organization.Location = new Point(186, 298);
            Cbx_organization.Name = "Cbx_organization";
            Cbx_organization.Size = new Size(313, 24);
            Cbx_organization.Sorted = true;
            Cbx_organization.TabIndex = 8;
            Cbx_organization.Click += Cbx_nameOrganization_Click;
            Cbx_organization.KeyPress += Cbx_organization_KeyPress;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label10.ForeColor = SystemColors.Menu;
            label10.Location = new Point(23, 335);
            label10.Name = "label10";
            label10.Size = new Size(96, 17);
            label10.TabIndex = 43;
            label10.Text = "Подразделение";
            // 
            // Cbx_otdel
            // 
            Cbx_otdel.BackColor = SystemColors.Window;
            Cbx_otdel.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_otdel.FormattingEnabled = true;
            Cbx_otdel.Location = new Point(186, 328);
            Cbx_otdel.Name = "Cbx_otdel";
            Cbx_otdel.Size = new Size(313, 24);
            Cbx_otdel.Sorted = true;
            Cbx_otdel.TabIndex = 9;
            Cbx_otdel.Click += Cbx_otdel_Click;
            Cbx_otdel.KeyPress += Cbx_otdel_KeyPress;
            // 
            // Btn_addOtdel
            // 
            Btn_addOtdel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addOtdel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addOtdel.FlatStyle = FlatStyle.Flat;
            Btn_addOtdel.Location = new Point(517, 328);
            Btn_addOtdel.Name = "Btn_addOtdel";
            Btn_addOtdel.Size = new Size(28, 23);
            Btn_addOtdel.TabIndex = 45;
            Btn_addOtdel.Text = "+";
            Btn_addOtdel.UseVisualStyleBackColor = false;
            Btn_addOtdel.Click += Btn_addOtdel_Click;
            // 
            // Btn_addOperation
            // 
            Btn_addOperation.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addOperation.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addOperation.FlatStyle = FlatStyle.Flat;
            Btn_addOperation.Location = new Point(517, 47);
            Btn_addOperation.Name = "Btn_addOperation";
            Btn_addOperation.Size = new Size(28, 23);
            Btn_addOperation.TabIndex = 46;
            Btn_addOperation.Text = "+";
            Btn_addOperation.UseVisualStyleBackColor = false;
            Btn_addOperation.Click += Btn_addOperation_Click;
            // 
            // Btn_addEmployee
            // 
            Btn_addEmployee.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addEmployee.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addEmployee.FlatStyle = FlatStyle.Flat;
            Btn_addEmployee.Location = new Point(517, 77);
            Btn_addEmployee.Name = "Btn_addEmployee";
            Btn_addEmployee.Size = new Size(28, 23);
            Btn_addEmployee.TabIndex = 47;
            Btn_addEmployee.Text = "+";
            Btn_addEmployee.UseVisualStyleBackColor = false;
            Btn_addEmployee.Click += Btn_addEmployee_Click;
            // 
            // LL_linkOnDoc
            // 
            LL_linkOnDoc.AutoSize = true;
            LL_linkOnDoc.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            LL_linkOnDoc.LinkColor = Color.FromArgb(255, 255, 192);
            LL_linkOnDoc.Location = new Point(186, 364);
            LL_linkOnDoc.Name = "LL_linkOnDoc";
            LL_linkOnDoc.Size = new Size(109, 17);
            LL_linkOnDoc.TabIndex = 10;
            LL_linkOnDoc.TabStop = true;
            LL_linkOnDoc.Text = "Открыть документ";
            // 
            // Btn_delete
            // 
            Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
            Btn_delete.FlatAppearance.BorderSize = 0;
            Btn_delete.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_delete.FlatStyle = FlatStyle.Flat;
            Btn_delete.Font = new Font("Franklin Gothic Book", 9F);
            Btn_delete.Location = new Point(236, 395);
            Btn_delete.Name = "Btn_delete";
            Btn_delete.Size = new Size(69, 25);
            Btn_delete.TabIndex = 10;
            Btn_delete.Text = "Удалить";
            Btn_delete.UseVisualStyleBackColor = false;
            Btn_delete.Click += Btn_delete_Click;
            // 
            // Btn_update
            // 
            Btn_update.BackColor = Color.FromArgb(98, 171, 180);
            Btn_update.FlatAppearance.BorderSize = 0;
            Btn_update.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_update.FlatStyle = FlatStyle.Flat;
            Btn_update.Font = new Font("Franklin Gothic Book", 9F);
            Btn_update.Location = new Point(310, 395);
            Btn_update.Name = "Btn_update";
            Btn_update.Size = new Size(69, 25);
            Btn_update.TabIndex = 11;
            Btn_update.Text = "Обновить";
            Btn_update.UseVisualStyleBackColor = false;
            Btn_update.Click += Btn_update_Click;
            // 
            // Btn_save
            // 
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            Btn_save.FlatAppearance.BorderSize = 0;
            Btn_save.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_save.FlatStyle = FlatStyle.Flat;
            Btn_save.Font = new Font("Franklin Gothic Book", 9F);
            Btn_save.Location = new Point(384, 395);
            Btn_save.Name = "Btn_save";
            Btn_save.Size = new Size(69, 25);
            Btn_save.TabIndex = 12;
            Btn_save.Text = "Сохранить";
            Btn_save.UseVisualStyleBackColor = false;
            Btn_save.Click += Btn_save_Click;
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9F);
            Btn_cancel.Location = new Point(458, 395);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(69, 25);
            Btn_cancel.TabIndex = 13;
            Btn_cancel.Text = "Отмена";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // Txb_type
            // 
            Txb_type.BackColor = SystemColors.Window;
            Txb_type.Font = new Font("Franklin Gothic Book", 9F);
            Txb_type.Location = new Point(186, 266);
            Txb_type.Multiline = true;
            Txb_type.Name = "Txb_type";
            Txb_type.ReadOnly = true;
            Txb_type.Size = new Size(140, 25);
            Txb_type.TabIndex = 7;
            // 
            // Txb_id
            // 
            Txb_id.Anchor = AnchorStyles.None;
            Txb_id.BackColor = SystemColors.Window;
            Txb_id.BorderStyle = BorderStyle.None;
            Txb_id.Font = new Font("Franklin Gothic Book", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_id.ForeColor = SystemColors.WindowText;
            Txb_id.Location = new Point(342, 17);
            Txb_id.Multiline = true;
            Txb_id.Name = "Txb_id";
            Txb_id.PlaceholderText = "id операции";
            Txb_id.ReadOnly = true;
            Txb_id.Size = new Size(152, 23);
            Txb_id.TabIndex = 55;
            Txb_id.TabStop = false;
            Txb_id.TextAlign = HorizontalAlignment.Center;
            // 
            // AddOperatoin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            CancelButton = Btn_cancel;
            ClientSize = new Size(576, 441);
            Controls.Add(Txb_id);
            Controls.Add(Txb_type);
            Controls.Add(Btn_delete);
            Controls.Add(Btn_update);
            Controls.Add(Btn_save);
            Controls.Add(Btn_cancel);
            Controls.Add(LL_linkOnDoc);
            Controls.Add(Btn_addEmployee);
            Controls.Add(Btn_addOperation);
            Controls.Add(Btn_addOtdel);
            Controls.Add(Cbx_otdel);
            Controls.Add(label10);
            Controls.Add(Cbx_organization);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(Txb_summ);
            Controls.Add(label7);
            Controls.Add(Cbx_formPay);
            Controls.Add(label6);
            Controls.Add(Txb_payment);
            Controls.Add(label5);
            Controls.Add(Cbx_nameEmployee);
            Controls.Add(label4);
            Controls.Add(Cbx_nameArticleBDDS);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(Dtp_dataOperation);
            Controls.Add(Btn_addOrganization);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AddOperatoin";
            StartPosition = FormStartPosition.CenterScreen;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Btn_addOrganization;
        private Label label1;
        private DateTimePicker Dtp_dataOperation;
        private Label label2;
        private Label label3;
        private ComboBox Cbx_nameArticleBDDS;
        private Label label4;
        private ComboBox Cbx_nameEmployee;
        private Label label5;
        private TextBox Txb_payment;
        private Label label6;
        private ComboBox Cbx_formPay;
        private Label label7;
        private TextBox Txb_summ;
        private Label label8;
        private Label label9;
        private ComboBox Cbx_organization;
        private Label label10;
        private ComboBox Cbx_otdel;
        private Button Btn_addOtdel;
        private Button Btn_addOperation;
        private Button Btn_addEmployee;
        private LinkLabel LL_linkOnDoc;
        public Button Btn_delete;
        public Button Btn_update;
        public Button Btn_save;
        private Button Btn_cancel;
        private Label label11;
        private TextBox Txb_type;
        private TextBox Txb_id;


        public void SetTxb_Id(string value) { Txb_id.Text = value; }
        public void SetTxb_type(string value) { Txb_type.Text = value; }
        public void SetCbx_otdel(string value) { Cbx_otdel.Text = value; }
        public void SetCbx_organization(string value) { Cbx_organization.Text = value; }
        public void SetTxb_summ(string value) { Txb_summ.Text = value; }
        public void SetCbx_formPay(string value) { Cbx_formPay.Text = value; }
        public void SetCbx_payment(string value) { Txb_payment.Text = value; }
        public void SetCbx_nameEmployee(string value) { Cbx_nameEmployee.Text = value; }
        public void SetCbx_nameOperation(string value) { Cbx_nameArticleBDDS.Text = value; }
        public void SetDtp_dataOperation(DateTime value) { Dtp_dataOperation.Value = value; }
        public void SetLL_linkOnDoc(string value) { LL_linkOnDoc.Text = value; }

    }
}