﻿namespace AIS.Forms
{
    partial class ArticleBDDS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Tbl_Operation = new DataGridView();
            label1 = new Label();
            Btn_delete = new Button();
            Btn_update = new Button();
            Btn_save = new Button();
            Btn_cancel = new Button();
            Txb_nameArticle = new TextBox();
            Txb_articleBDDS = new TextBox();
            Txb_type = new TextBox();
            Txb_id = new TextBox();
            ((System.ComponentModel.ISupportInitialize)Tbl_Operation).BeginInit();
            SuspendLayout();
            // 
            // Tbl_Operation
            // 
            Tbl_Operation.AllowUserToAddRows = false;
            Tbl_Operation.AllowUserToDeleteRows = false;
            Tbl_Operation.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Tbl_Operation.Location = new Point(12, 144);
            Tbl_Operation.Name = "Tbl_Operation";
            Tbl_Operation.ReadOnly = true;
            Tbl_Operation.Size = new Size(577, 281);
            Tbl_Operation.TabIndex = 1;
            Tbl_Operation.CellDoubleClick += Tbl_Company_CellDoubleClick;
            Tbl_Operation.KeyPress += Tbl_Company_KeyPress;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Franklin Gothic Book", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.Info;
            label1.Location = new Point(213, 8);
            label1.Name = "label1";
            label1.Size = new Size(200, 20);
            label1.TabIndex = 9;
            label1.Text = "Справочник операций БДДС ";
            // 
            // Btn_delete
            // 
            Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
            Btn_delete.FlatAppearance.BorderSize = 0;
            Btn_delete.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_delete.FlatStyle = FlatStyle.Flat;
            Btn_delete.Font = new Font("Franklin Gothic Book", 9F);
            Btn_delete.Location = new Point(298, 433);
            Btn_delete.Name = "Btn_delete";
            Btn_delete.Size = new Size(69, 25);
            Btn_delete.TabIndex = 6;
            Btn_delete.Text = "Удалить";
            Btn_delete.UseVisualStyleBackColor = false;
            Btn_delete.Click += Btn_delete_Click;
            // 
            // Btn_update
            // 
            Btn_update.BackColor = Color.FromArgb(98, 171, 180);
            Btn_update.FlatAppearance.BorderSize = 0;
            Btn_update.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_update.FlatStyle = FlatStyle.Flat;
            Btn_update.Font = new Font("Franklin Gothic Book", 9F);
            Btn_update.Location = new Point(372, 433);
            Btn_update.Name = "Btn_update";
            Btn_update.Size = new Size(69, 25);
            Btn_update.TabIndex = 7;
            Btn_update.Text = "Обновить";
            Btn_update.UseVisualStyleBackColor = false;
            Btn_update.Click += Btn_update_Click;
            // 
            // Btn_save
            // 
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            Btn_save.FlatAppearance.BorderSize = 0;
            Btn_save.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_save.FlatStyle = FlatStyle.Flat;
            Btn_save.Font = new Font("Franklin Gothic Book", 9F);
            Btn_save.Location = new Point(446, 433);
            Btn_save.Name = "Btn_save";
            Btn_save.Size = new Size(69, 25);
            Btn_save.TabIndex = 8;
            Btn_save.Text = "Сохранить";
            Btn_save.UseVisualStyleBackColor = false;
            Btn_save.Click += Btn_save_Click;
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9F);
            Btn_cancel.Location = new Point(520, 433);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(69, 25);
            Btn_cancel.TabIndex = 9;
            Btn_cancel.Text = "Отмена";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // Txb_nameArticle
            // 
            Txb_nameArticle.BackColor = SystemColors.ControlLight;
            Txb_nameArticle.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_nameArticle.Location = new Point(204, 59);
            Txb_nameArticle.MaxLength = 35;
            Txb_nameArticle.Name = "Txb_nameArticle";
            Txb_nameArticle.PlaceholderText = "Наименование операции";
            Txb_nameArticle.Size = new Size(217, 22);
            Txb_nameArticle.TabIndex = 3;
            Txb_nameArticle.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_articleBDDS
            // 
            Txb_articleBDDS.BackColor = SystemColors.ControlLight;
            Txb_articleBDDS.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_articleBDDS.Location = new Point(204, 87);
            Txb_articleBDDS.MaxLength = 30;
            Txb_articleBDDS.Name = "Txb_articleBDDS";
            Txb_articleBDDS.PlaceholderText = "Статья БДДС";
            Txb_articleBDDS.Size = new Size(217, 22);
            Txb_articleBDDS.TabIndex = 4;
            Txb_articleBDDS.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_type
            // 
            Txb_type.BackColor = SystemColors.ControlLight;
            Txb_type.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_type.Location = new Point(204, 116);
            Txb_type.MaxLength = 30;
            Txb_type.Name = "Txb_type";
            Txb_type.PlaceholderText = "Тип статьи";
            Txb_type.Size = new Size(217, 22);
            Txb_type.TabIndex = 5;
            Txb_type.TextAlign = HorizontalAlignment.Center;
            // 
            // Txb_id
            // 
            Txb_id.BackColor = SystemColors.ControlLight;
            Txb_id.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_id.Location = new Point(204, 31);
            Txb_id.MaxLength = 35;
            Txb_id.Name = "Txb_id";
            Txb_id.PlaceholderText = "id записи";
            Txb_id.ReadOnly = true;
            Txb_id.Size = new Size(217, 22);
            Txb_id.TabIndex = 2;
            Txb_id.TextAlign = HorizontalAlignment.Center;
            // 
            // Operation
            // 
            AutoScaleDimensions = new SizeF(6F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            ClientSize = new Size(601, 470);
            Controls.Add(Txb_id);
            Controls.Add(Txb_type);
            Controls.Add(Txb_articleBDDS);
            Controls.Add(Tbl_Operation);
            Controls.Add(label1);
            Controls.Add(Btn_delete);
            Controls.Add(Btn_update);
            Controls.Add(Btn_save);
            Controls.Add(Btn_cancel);
            Controls.Add(Txb_nameArticle);
            Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Operation";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Company";
            ((System.ComponentModel.ISupportInitialize)Tbl_Operation).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView Tbl_Operation;
        private Label label1;
        private Button Btn_delete;
        private Button Btn_update;
        private Button Btn_save;
        private Button Btn_cancel;
        private TextBox Txb_nameArticle;
        private TextBox Txb_articleBDDS;
        private TextBox Txb_type;
        private TextBox Txb_id;
    }
}