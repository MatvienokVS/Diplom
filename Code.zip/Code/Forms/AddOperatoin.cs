﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using Microsoft.VisualBasic.Logging;
using System.Data;

namespace AIS.Forms
{
    public partial class AddOperatoin : Form
    {
        private IQuerySelect _querySelect;
        private readonly DB.DB db;
        public WindowMover _windowMover;
        public string nameTable = Const.USER_TABLE_KASSA;
        public string id = Const.ID;

        public string Login { get; set; }

        public AddOperatoin()
        {
            InitializeComponent();
            //_windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            Dtp_dataOperation.Value = DateTime.Now;
            Cbx_formPay.Text = "наличная";
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void Btn_addOperation_Click(object sender, EventArgs e)
        {
            ArticleBDDS articleBDDS = new();
            articleBDDS.ShowDialog();
        }

        private void Btn_addEmployee_Click(object sender, EventArgs e)
        {
            Forms.Employee employee = new();
            employee.ShowDialog();
        }

        private void Btn_addOrganization_Click(object sender, EventArgs e)
        {
            Forms.Organization organization = new();
            organization.ShowDialog();
        }

        private void Btn_addOtdel_Click(object sender, EventArgs e)
        {
            Forms.Otdel otdel = new();
            otdel.ShowDialog();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();
                var emplCreator = GetEmplCreatorKassa();
                string queryCreateTable = emplCreator.CreateTableKassa();
                db.ExecuteNonQuery(queryCreateTable);

                var emplInsert = GetEmplInsertAddOperation();
                var arg = new InsertArgAddOperation()
                {
                    dataOperation = Dtp_dataOperation.Value.Date,
                    nameArticle = Cbx_nameArticleBDDS.Text,
                    nameEmployee = Cbx_nameEmployee.Text,
                    payment = CorrectPayment(),
                    formPay = Cbx_formPay.Text,
                    summ = CorrectSumm(),
                    type = Txb_type.Text,
                    discriptor = Discriptor(),
                    organization = Cbx_organization.Text,
                    otdel = Cbx_otdel.Text,
                    articleBDDS = ArticleBDDS() + "-" + CodeOrganization() + "-" + CodeOtdel(),
                    nameRole = NameRole(),
                };
                if (!ValidateOperation())
                {
                    return;
                }

                string insertQuery = emplInsert.InsertOperation(arg);
                int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                SaveSuccess?.Invoke(this, null);

                if (numRowsInserted > 0)
                {
                    ClearForm();
                }
                else
                {
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        private void Cbx_nameOrganization_Click(object sender, EventArgs e)
        {
            var currentRole = NameRole();

            db.Connect();
            Cbx_organization.Items.Clear();
            string nameTable = OrganizationModel.USER_TABLE_Organization;
            string nameColumn = OrganizationModel.NAME_ORGANIZATION;
            string queryOrganizationlNames = QuerySelect.GetDataForCbxOrganization(nameColumn, nameTable, currentRole);
            db.ExecuteDataCombobox(queryOrganizationlNames, Cbx_organization, nameColumn);
        }

        private void Cbx_otdel_Click(object sender, EventArgs e)
        {
            var currentRole = NameRole();
            db.Connect();
            Cbx_otdel.Items.Clear();
            string nameTable = Const.USER_TABLE_OTDEL;
            string nameColumn = Const.NAME_OTDEL;
            string executeDataCombobox = QuerySelect.GetDataForCbxOtdel(nameColumn, nameTable, currentRole);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_otdel, nameColumn);
        }

        private void Cbx_nameEmployee_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_nameEmployee.Items.Clear();
            string nameTable = EmployeesModel.USER_TABLE_EMPLOYEE;
            string nameColumn = EmployeesModel.SURNAME_USER;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_nameEmployee, nameColumn);
        }

        private void Cbx_nameArticleBDDS_Click(object sender, EventArgs e)
        {
            db.Connect();

            Cbx_nameArticleBDDS.Items.Clear();
            string nameTable = ArticleBDDSModel.USER_TABLE_ARTICLE;
            string nameColumn = ArticleBDDSModel.NAME_ARTICLE;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_nameArticleBDDS, nameColumn);

            //string searchField = Cbx_nameOperation.Text;
            //string nameField = ArticleBDDSModel.NAME_ARTICLE;
            //string valueField = Cbx_nameOperation.Text;

            //string executeSearchField = ArticleBDDSModel.SearchField(nameTable, searchField, nameField, valueField);
            //db.ExecuteDataTable(executeSearchField);
        }

        private void Cbx_formPay_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_formPay.Items.Clear();
            string nameTable = Const.USER_TABLE_FORM_PAY;
            string nameColumn = Const.NAME_FORM_PAY;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_formPay, nameColumn);
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

            string condition = $"{id} = '{Txb_id.Text}'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            db.ExecuteNonQuery(deleteQuery);

            DeleteSuccess?.Invoke(this, null);

            ClearForm();
            ViewButtonDoubleClick();
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplUpdate = GetEmplUpdateOperation();
                var arg = new UpdateArgOperation()
                {
                    nameTable = KassaModel.USER_TABLE_KASSA,
                    id = Txb_id.Text,
                    dataOperation = Dtp_dataOperation.Value,
                    nameArticle = Cbx_nameArticleBDDS.Text,
                    nameEmployee = Cbx_nameEmployee.Text,
                    payment = CorrectPayment(),
                    formPay = Cbx_formPay.Text,
                    summ = CorrectSumm(),
                    type = Txb_type.Text,
                    discriptor = Discriptor(),
                    organization = Cbx_organization.Text,
                    otdel = Cbx_otdel.Text,
                    articleBDDS = ArticleBDDS() + "-" + CodeOrganization() + "-" + CodeOtdel(),
                    nameRole = NameRole(),

                };
                string queryUpdateLine = emplUpdate.UpdateOperation(arg);
                int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);

                UpdateSuccess?.Invoke(this, null);

                if (numRowsUpdated > 0)
                {
                    //MessageBox.Show("Данные успешно сохранены.");
                }
                else
                {
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);
                }
                ClearForm();
                ViewButtonDoubleClick();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
                this.Close();
            }
        }

        private void Cbx_formPay_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_nameOperation_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_nameEmployee_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_organization_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_otdel_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_nameOperation_SelectedIndexChanged(object sender, EventArgs e)
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = ArticleBDDSModel.USER_TABLE_ARTICLE,
                searchField = ArticleBDDSModel.TYPE_OPERATION,
                nameField = ArticleBDDSModel.NAME_ARTICLE,
                valueField = Cbx_nameArticleBDDS.Text,
            };
            string queryGetNumberBDDS = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(queryGetNumberBDDS);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
                Txb_type.Text = resultString;
            }
            db.DisConnect();
        }

        private void Txb_payment_TextChanged(object sender, EventArgs e)
        {
            Txb_payment.MaxLength = 210;
        }

        private void Cbx_nameOperation_KeyUp(object sender, KeyEventArgs e)
        {
            if (Char.IsLetter((char)e.KeyCode))
            {
                string typedText = Cbx_nameArticleBDDS.Text.ToLower();
                int selectionStart = Cbx_nameArticleBDDS.SelectionStart;

                for (int i = 0; i < Cbx_nameArticleBDDS.Items.Count; i++)
                {
                    string item = Cbx_nameArticleBDDS.Items[i].ToString().ToLower();
                    if (item.StartsWith(typedText))
                    {
                        Cbx_nameArticleBDDS.SelectedIndex = i;
                        Cbx_nameArticleBDDS.Text = typedText;
                        Cbx_nameArticleBDDS.SelectionStart = typedText.Length;
                        Cbx_nameArticleBDDS.SelectionLength = item.Length - typedText.Length;
                        break;
                    }
                }
            }
        }

        private IEmplCreatorKassa GetEmplCreatorKassa()
        {
            return new KassaModel();
        }

        private IEmplInsertAddOperation GetEmplInsertAddOperation()
        {
            return new KassaModel();
        }

        private IEmplUpdateOperation GetEmplUpdateOperation()
        {
            return new KassaModel();
        }

        // Заполняем поле статья БДДС
        private string ArticleBDDS()
        {           
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = ArticleBDDSModel.USER_TABLE_ARTICLE,
                searchField = ArticleBDDSModel.ARTICLE_BDDS,
                nameField = ArticleBDDSModel.NAME_ARTICLE,
                valueField = Cbx_nameArticleBDDS.Text,
            };
            string queryGetNumberBDDS = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(queryGetNumberBDDS);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }
            return resultString;            
        }
        private string CodeOrganization()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = OrganizationModel.USER_TABLE_Organization,
                searchField = OrganizationModel.CODE_ORGANIZATION,
                nameField = OrganizationModel.NAME_ORGANIZATION,
                valueField = Cbx_organization.Text,
            };
            string queryGetNumberBDDS = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(queryGetNumberBDDS);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }

            return resultString;     
        }
        private string CodeOtdel()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = OtdelModel.USER_TABLE_OTDEL,
                searchField = OtdelModel.CODE_OTDEL,
                nameField = OtdelModel.NAME_OTDEL,
                valueField = Cbx_otdel.Text,
            };
            string queryGetNumberBDDS = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(queryGetNumberBDDS);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }
            return resultString;            
        }
        private string CorrectPayment()
        {
            string inputpayment = Txb_payment.Text;
            if (inputpayment.Contains(","))
            {
                // Заменяем запятую на точку
                inputpayment = inputpayment.Replace(",", ".");
                Txb_payment.Text = inputpayment;
                Txb_payment.SelectionStart = inputpayment.Length;
            }
            return inputpayment;
        }
        private string CorrectSumm()
        {
            string inputsumm = Txb_summ.Text;
            if (inputsumm.Contains(","))
            {
                // Заменяем запятую на точку
                inputsumm = inputsumm.Replace(",", ".");

                // Оставляем только два знака после точки
                int index = inputsumm.IndexOf(".");
                if (index != -1 && inputsumm.Length > index + 3)
                {
                    inputsumm = inputsumm.Substring(0, index + 3);
                }

                // Обновляем текст в поле ввода
                Txb_summ.Text = inputsumm;
                Txb_summ.SelectionStart = inputsumm.Length;
            }
            return inputsumm;
        }
        private string Discriptor()
        {
            string discriptor = Environment.UserName;
            return discriptor;
        }
        private void ClearForm()
        {
            Txb_id.Text = "";
            Dtp_dataOperation.Value = DateTime.Now;
            Cbx_nameArticleBDDS.Text = "";
            Cbx_nameEmployee.Text = "";
            Txb_payment.Text = "";
            Txb_summ.Text = "";
            Txb_type.Text = "";
            Cbx_organization.Text = "";
            Cbx_otdel.Text = "";
        }
        private void ViewButtonDoubleClick()
        {
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
        }
        private bool ValidateOperation()
        {
            if (string.IsNullOrEmpty(Cbx_nameArticleBDDS.Text) ||
                string.IsNullOrEmpty(Txb_payment.Text) ||
                string.IsNullOrEmpty(Cbx_formPay.Text) ||
                string.IsNullOrEmpty(Txb_summ.Text) ||
                string.IsNullOrEmpty(Cbx_organization.Text) ||
                string.IsNullOrEmpty(Cbx_otdel.Text))
            {
                MessageBox.Show("Введите данные финансовой операции");
                return false;
            }
            return true;
        }
        private string NameRole()
        {
            db.Connect();

            var arg = new SearchArgField()
            {
                nameTable = RegistrationModel.USER_TABLE_User,
                searchField = RegistrationModel.NAME_ROLE,
                nameField = RegistrationModel.E_MAIL,
                valueField = Login,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }
            return resultString;
        }
        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }

        // TODO 1. почитать как создавать события
        // TODO 2 почитать про нотификациЮ (события от БД), чтобы получить обновы от других юзеров (в целом это звоется MS SQL insert notification)
        // https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/sql/enabling-query-notifications
        public event EventHandler SaveSuccess;
        public event EventHandler UpdateSuccess;
        public event EventHandler DeleteSuccess;

    }
}

