﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIS.Forms
{
    public partial class Company : Form
    {
        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;

        public Company()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();


            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;

            UpdateDataGridView();
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                if (string.IsNullOrEmpty(Txb_innCompany.Text) ||
                    string.IsNullOrEmpty(Txb_nameCompany.Text) ||
                    string.IsNullOrEmpty(Txb_contactPerson.Text))
                {
                    MessageBox.Show("Введите инн, наименование организации и контактное лицо");
                }
                else
                {
                    string nameTable = CompanyModel.USER_TABLE_COMPANY;
                    string queryCreateTable = CompanyModel.CreateTableCompany();
                    db.ExecuteNonQuery(queryCreateTable);

                    if (string.IsNullOrEmpty(Txb_innCompany.Text) ||
                    string.IsNullOrEmpty(Txb_nameCompany.Text) ||
                    string.IsNullOrEmpty(Txb_contactPerson.Text))
                    {
                        MessageBox.Show("Введите код и наименование организации");
                    }

                    // Записываем данные в базу данных
                    string insertQuery = CompanyModel.InsertDataCompany(nameTable, Txb_innCompany.Text,
                                                                      Txb_nameCompany.Text,
                                                                      Txb_contactPerson.Text);
                    int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                    UpdateDataGridView();

                    if (numRowsInserted > 0) ;
                    //MessageBox.Show("Данные успешно сохранены.");
                    else
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);

                    Txb_innCompany.Text = "";
                    Txb_nameCompany.Text = "";
                    Txb_contactPerson.Text = "";

                    db.DisConnect();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }
        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = CompanyModel.USER_TABLE_COMPANY;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                string queryCreateTable = CompanyModel.CreateTableCompany();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);

                Tbl_Company.DataSource = dataTable;
                Tbl_Company.Columns["id"].Width = 50;
                Tbl_Company.Columns["id"].HeaderText = "id записи";
                Tbl_Company.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Company.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Company.Columns["innCompany"].Width = 80;
                Tbl_Company.Columns["innCompany"].HeaderText = "ИНН контрагента";
                Tbl_Company.Columns["innCompany"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Tbl_Company.Columns["innCompany"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Company.Columns["nameCompany"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_Company.Columns["nameCompany"].HeaderText = "Наименование контрагента";
                Tbl_Company.Columns["nameCompany"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                Tbl_Company.Columns["contactPerson"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tbl_Company.Columns["contactPerson"].HeaderText = "Контактное лицо контрагента";
                Tbl_Company.Columns["contactPerson"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            db.DisConnect();
        }

        private void Tbl_Company_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_id.Text = "";
                Txb_innCompany.Text = "";
                Txb_nameCompany.Text = "";
                Txb_contactPerson.Text = "";

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Tbl_Company_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_Company.Rows[e.RowIndex];

                // Получаем данные из выбранной строки

                string id = selectedRow.Cells["id"].Value.ToString();
                string inn = selectedRow.Cells["innCompany"].Value.ToString();
                string nameCompany = selectedRow.Cells["nameCompany"].Value.ToString();
                string contactPerson = selectedRow.Cells["contactPerson"].Value.ToString();

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Txb_innCompany.Text = inn;
                Txb_nameCompany.Text = nameCompany;
                Txb_contactPerson.Text = contactPerson;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;
            }
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            db.Connect();

            string nameTable = CompanyModel.USER_TABLE_COMPANY;
            string condition = CompanyModel.INN_COMPANY + " = '" + Txb_innCompany.Text + "'";
            string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
            _ = db.ExecuteNonQuery(deleteQuery);

            UpdateDataGridView();

            Txb_id.Text = "";
            Txb_innCompany.Text = "";
            Txb_nameCompany.Text = "";
            Txb_contactPerson.Text = "";

            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;
            Btn_save.Enabled = true;
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Txb_innCompany.Text) || string.IsNullOrEmpty(Txb_nameCompany.Text) || string.IsNullOrEmpty(Txb_contactPerson.Text))
                {
                    MessageBox.Show("Введите ИНН, Наименование контрагента и контатное лицо ");
                }
                else
                {
                    db.Connect();

                    string nameTable = CompanyModel.USER_TABLE_COMPANY;
                    string id = Txb_id.Text;
                    string inn = Txb_innCompany.Text;
                    string nameCompany = Txb_nameCompany.Text;
                    string contactPerson = Txb_contactPerson.Text;

                    string queryUpdateLine = CompanyModel.UpdateDateOtdel(nameTable, id, inn,  nameCompany, contactPerson);
                    int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);


                    UpdateDataGridView();

                    if (numRowsUpdated > 0) ;
                    //MessageBox.Show("Данные успешно сохранены.");
                    else
                        MessageBox.Show("Ошибка вставки данных " + db.LastError);

                    Txb_id.Text = "";
                    Txb_innCompany.Text = "";
                    Txb_nameCompany.Text = "";
                    Txb_contactPerson.Text = "";

                    Btn_update.Enabled = false;
                    Btn_update.BackColor = Color.LightGray;
                    Btn_delete.Enabled = false;
                    Btn_delete.BackColor = Color.LightGray;
                    Btn_save.Enabled = true;
                    Btn_save.BackColor = Color.FromArgb(98, 171, 180);

                    db.DisConnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
        }

        private IQuerySelect _querySelect;
        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }

}
