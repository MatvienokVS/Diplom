﻿using System.Windows.Forms;
using System.Xml.Linq;

namespace AIS.Forms
{
    partial class AddPayEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Btn_addOrganization = new Button();
            Dtp_dataOperation = new DateTimePicker();
            label2 = new Label();
            label3 = new Label();
            Cbx_Staff = new ComboBox();
            label4 = new Label();
            Cbx_nameEmployee = new ComboBox();
            label7 = new Label();
            Txb_oklad = new TextBox();
            label9 = new Label();
            Cbx_organization = new ComboBox();
            label10 = new Label();
            Cbx_otdel = new ComboBox();
            Btn_addOtdel = new Button();
            Btn_addStaff = new Button();
            Btn_addEmployee = new Button();
            Btn_delete = new Button();
            Btn_update = new Button();
            Btn_save = new Button();
            Btn_cancel = new Button();
            label1 = new Label();
            Txb_kpiOne = new TextBox();
            label5 = new Label();
            Txb_kpiTwo = new TextBox();
            label6 = new Label();
            Txb_nalichie = new TextBox();
            label8 = new Label();
            Txb_zakaz = new TextBox();
            label11 = new Label();
            Txb_Soputka = new TextBox();
            Txb_Bonus = new TextBox();
            label12 = new Label();
            Txb_Refund = new TextBox();
            label13 = new Label();
            groupBox1 = new GroupBox();
            Txb_Otpusk = new TextBox();
            label18 = new Label();
            groupBox2 = new GroupBox();
            Dtp_Otpusk = new DateTimePicker();
            label16 = new Label();
            Txb_PayOtpusk = new TextBox();
            label17 = new Label();
            Dtp_Avans = new DateTimePicker();
            label15 = new Label();
            Txb_Avans = new TextBox();
            label14 = new Label();
            Txb_id = new TextBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // Btn_addOrganization
            // 
            Btn_addOrganization.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addOrganization.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addOrganization.FlatStyle = FlatStyle.Flat;
            Btn_addOrganization.Location = new Point(517, 47);
            Btn_addOrganization.Name = "Btn_addOrganization";
            Btn_addOrganization.Size = new Size(28, 23);
            Btn_addOrganization.TabIndex = 0;
            Btn_addOrganization.Text = "+";
            Btn_addOrganization.UseVisualStyleBackColor = false;
            Btn_addOrganization.Click += Btn_addOrganization_Click;
            // 
            // Dtp_dataOperation
            // 
            Dtp_dataOperation.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Dtp_dataOperation.Location = new Point(186, 20);
            Dtp_dataOperation.MinDate = new DateTime(1945, 1, 1, 0, 0, 0, 0);
            Dtp_dataOperation.Name = "Dtp_dataOperation";
            Dtp_dataOperation.Size = new Size(140, 21);
            Dtp_dataOperation.TabIndex = 1;
            Dtp_dataOperation.Value = new DateTime(2024, 1, 29, 0, 0, 0, 0);
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.ForeColor = SystemColors.Menu;
            label2.Location = new Point(23, 24);
            label2.Name = "label2";
            label2.Size = new Size(94, 17);
            label2.TabIndex = 28;
            label2.Text = "Дата операции";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label3.ForeColor = SystemColors.Menu;
            label3.Location = new Point(23, 113);
            label3.Name = "label3";
            label3.Size = new Size(134, 17);
            label3.TabIndex = 29;
            label3.Text = "Должность сотрудника";
            // 
            // Cbx_Staff
            // 
            Cbx_Staff.BackColor = SystemColors.Window;
            Cbx_Staff.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_Staff.FormattingEnabled = true;
            Cbx_Staff.Location = new Point(186, 106);
            Cbx_Staff.Name = "Cbx_Staff";
            Cbx_Staff.Size = new Size(313, 24);
            Cbx_Staff.Sorted = true;
            Cbx_Staff.TabIndex = 3;
            Cbx_Staff.Click += Cbx_Staff_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label4.ForeColor = SystemColors.Menu;
            label4.Location = new Point(23, 143);
            label4.Name = "label4";
            label4.Size = new Size(127, 17);
            label4.TabIndex = 31;
            label4.Text = "Фамилия сотрудника";
            // 
            // Cbx_nameEmployee
            // 
            Cbx_nameEmployee.BackColor = SystemColors.Window;
            Cbx_nameEmployee.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_nameEmployee.FormattingEnabled = true;
            Cbx_nameEmployee.Location = new Point(186, 136);
            Cbx_nameEmployee.Name = "Cbx_nameEmployee";
            Cbx_nameEmployee.Size = new Size(313, 24);
            Cbx_nameEmployee.Sorted = true;
            Cbx_nameEmployee.TabIndex = 4;
            Cbx_nameEmployee.Click += Cbx_nameEmployee_Click;
            Cbx_nameEmployee.KeyPress += Cbx_nameEmployee_KeyPress;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label7.ForeColor = SystemColors.Menu;
            label7.Location = new Point(18, 182);
            label7.Name = "label7";
            label7.Size = new Size(41, 17);
            label7.TabIndex = 37;
            label7.Text = "Оклад";
            // 
            // Txb_oklad
            // 
            Txb_oklad.BackColor = SystemColors.Window;
            Txb_oklad.Font = new Font("Franklin Gothic Book", 9F);
            Txb_oklad.Location = new Point(336, 174);
            Txb_oklad.Multiline = true;
            Txb_oklad.Name = "Txb_oklad";
            Txb_oklad.Size = new Size(140, 25);
            Txb_oklad.TabIndex = 10;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label9.ForeColor = SystemColors.Menu;
            label9.Location = new Point(23, 52);
            label9.Name = "label9";
            label9.Size = new Size(83, 17);
            label9.TabIndex = 41;
            label9.Text = "Организация";
            // 
            // Cbx_organization
            // 
            Cbx_organization.BackColor = SystemColors.Window;
            Cbx_organization.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_organization.FormattingEnabled = true;
            Cbx_organization.Location = new Point(186, 46);
            Cbx_organization.Name = "Cbx_organization";
            Cbx_organization.Size = new Size(313, 24);
            Cbx_organization.Sorted = true;
            Cbx_organization.TabIndex = 1;
            Cbx_organization.Click += Cbx_organization_Click;
            Cbx_organization.KeyPress += Cbx_organization_KeyPress;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label10.ForeColor = SystemColors.Menu;
            label10.Location = new Point(23, 83);
            label10.Name = "label10";
            label10.Size = new Size(96, 17);
            label10.TabIndex = 43;
            label10.Text = "Подразделение";
            // 
            // Cbx_otdel
            // 
            Cbx_otdel.BackColor = SystemColors.Window;
            Cbx_otdel.Font = new Font("Franklin Gothic Book", 9F);
            Cbx_otdel.FormattingEnabled = true;
            Cbx_otdel.Location = new Point(186, 76);
            Cbx_otdel.Name = "Cbx_otdel";
            Cbx_otdel.Size = new Size(313, 24);
            Cbx_otdel.Sorted = true;
            Cbx_otdel.TabIndex = 2;
            Cbx_otdel.Click += Cbx_otdel_Click;
            Cbx_otdel.KeyPress += Cbx_otdel_KeyPress;
            // 
            // Btn_addOtdel
            // 
            Btn_addOtdel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addOtdel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addOtdel.FlatStyle = FlatStyle.Flat;
            Btn_addOtdel.Location = new Point(517, 77);
            Btn_addOtdel.Name = "Btn_addOtdel";
            Btn_addOtdel.Size = new Size(28, 23);
            Btn_addOtdel.TabIndex = 45;
            Btn_addOtdel.Text = "+";
            Btn_addOtdel.UseVisualStyleBackColor = false;
            Btn_addOtdel.Click += Btn_addOtdel_Click;
            // 
            // Btn_addStaff
            // 
            Btn_addStaff.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addStaff.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addStaff.FlatStyle = FlatStyle.Flat;
            Btn_addStaff.Location = new Point(517, 107);
            Btn_addStaff.Name = "Btn_addStaff";
            Btn_addStaff.Size = new Size(28, 23);
            Btn_addStaff.TabIndex = 46;
            Btn_addStaff.Text = "+";
            Btn_addStaff.UseVisualStyleBackColor = false;
            Btn_addStaff.Click += Btn_addStaff_Click;
            // 
            // Btn_addEmployee
            // 
            Btn_addEmployee.BackColor = Color.FromArgb(98, 171, 180);
            Btn_addEmployee.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_addEmployee.FlatStyle = FlatStyle.Flat;
            Btn_addEmployee.Location = new Point(517, 137);
            Btn_addEmployee.Name = "Btn_addEmployee";
            Btn_addEmployee.Size = new Size(28, 23);
            Btn_addEmployee.TabIndex = 47;
            Btn_addEmployee.Text = "+";
            Btn_addEmployee.UseVisualStyleBackColor = false;
            Btn_addEmployee.Click += Btn_addEmployee_Click;
            // 
            // Btn_delete
            // 
            Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
            Btn_delete.FlatAppearance.BorderSize = 0;
            Btn_delete.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_delete.FlatStyle = FlatStyle.Flat;
            Btn_delete.Font = new Font("Franklin Gothic Book", 9F);
            Btn_delete.Location = new Point(254, 647);
            Btn_delete.Name = "Btn_delete";
            Btn_delete.Size = new Size(69, 25);
            Btn_delete.TabIndex = 10;
            Btn_delete.Text = "Удалить";
            Btn_delete.UseVisualStyleBackColor = false;
            Btn_delete.Click += Btn_delete_Click;
            // 
            // Btn_update
            // 
            Btn_update.BackColor = Color.FromArgb(98, 171, 180);
            Btn_update.FlatAppearance.BorderSize = 0;
            Btn_update.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_update.FlatStyle = FlatStyle.Flat;
            Btn_update.Font = new Font("Franklin Gothic Book", 9F);
            Btn_update.Location = new Point(328, 647);
            Btn_update.Name = "Btn_update";
            Btn_update.Size = new Size(69, 25);
            Btn_update.TabIndex = 11;
            Btn_update.Text = "Обновить";
            Btn_update.UseVisualStyleBackColor = false;
            Btn_update.Click += Btn_update_Click;
            // 
            // Btn_save
            // 
            Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            Btn_save.FlatAppearance.BorderSize = 0;
            Btn_save.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_save.FlatStyle = FlatStyle.Flat;
            Btn_save.Font = new Font("Franklin Gothic Book", 9F);
            Btn_save.Location = new Point(402, 647);
            Btn_save.Name = "Btn_save";
            Btn_save.Size = new Size(69, 25);
            Btn_save.TabIndex = 12;
            Btn_save.Text = "Сохранить";
            Btn_save.UseVisualStyleBackColor = false;
            Btn_save.Click += Btn_save_Click;
            // 
            // Btn_cancel
            // 
            Btn_cancel.BackColor = Color.FromArgb(98, 171, 180);
            Btn_cancel.FlatAppearance.BorderSize = 0;
            Btn_cancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            Btn_cancel.FlatStyle = FlatStyle.Flat;
            Btn_cancel.Font = new Font("Franklin Gothic Book", 9F);
            Btn_cancel.Location = new Point(476, 647);
            Btn_cancel.Name = "Btn_cancel";
            Btn_cancel.Size = new Size(69, 25);
            Btn_cancel.TabIndex = 13;
            Btn_cancel.Text = "Отмена";
            Btn_cancel.UseVisualStyleBackColor = false;
            Btn_cancel.Click += Btn_cancel_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.Menu;
            label1.Location = new Point(18, 213);
            label1.Name = "label1";
            label1.Size = new Size(47, 17);
            label1.TabIndex = 37;
            label1.Text = "kpiOne";
            // 
            // Txb_kpiOne
            // 
            Txb_kpiOne.BackColor = SystemColors.Window;
            Txb_kpiOne.Font = new Font("Franklin Gothic Book", 9F);
            Txb_kpiOne.Location = new Point(336, 205);
            Txb_kpiOne.Multiline = true;
            Txb_kpiOne.Name = "Txb_kpiOne";
            Txb_kpiOne.Size = new Size(140, 25);
            Txb_kpiOne.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label5.ForeColor = SystemColors.Menu;
            label5.Location = new Point(18, 244);
            label5.Name = "label5";
            label5.Size = new Size(47, 17);
            label5.TabIndex = 37;
            label5.Text = "kpiTwo";
            // 
            // Txb_kpiTwo
            // 
            Txb_kpiTwo.BackColor = SystemColors.Window;
            Txb_kpiTwo.Font = new Font("Franklin Gothic Book", 9F);
            Txb_kpiTwo.Location = new Point(336, 236);
            Txb_kpiTwo.Multiline = true;
            Txb_kpiTwo.Name = "Txb_kpiTwo";
            Txb_kpiTwo.Size = new Size(140, 25);
            Txb_kpiTwo.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label6.ForeColor = SystemColors.Menu;
            label6.Location = new Point(18, 29);
            label6.Name = "label6";
            label6.Size = new Size(157, 17);
            label6.TabIndex = 37;
            label6.Text = "Сумма продаж из наличия";
            // 
            // Txb_nalichie
            // 
            Txb_nalichie.BackColor = SystemColors.Window;
            Txb_nalichie.Font = new Font("Franklin Gothic Book", 9F);
            Txb_nalichie.Location = new Point(336, 21);
            Txb_nalichie.Multiline = true;
            Txb_nalichie.Name = "Txb_nalichie";
            Txb_nalichie.Size = new Size(140, 25);
            Txb_nalichie.TabIndex = 5;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label8.ForeColor = SystemColors.Menu;
            label8.Location = new Point(18, 60);
            label8.Name = "label8";
            label8.Size = new Size(149, 17);
            label8.TabIndex = 37;
            label8.Text = "Сумма продаж под заказ";
            // 
            // Txb_zakaz
            // 
            Txb_zakaz.BackColor = SystemColors.Window;
            Txb_zakaz.Font = new Font("Franklin Gothic Book", 9F);
            Txb_zakaz.Location = new Point(336, 52);
            Txb_zakaz.Multiline = true;
            Txb_zakaz.Name = "Txb_zakaz";
            Txb_zakaz.Size = new Size(140, 25);
            Txb_zakaz.TabIndex = 6;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label11.ForeColor = SystemColors.Menu;
            label11.Location = new Point(18, 91);
            label11.Name = "label11";
            label11.Size = new Size(230, 17);
            label11.TabIndex = 37;
            label11.Text = "Сумма продаж сопутствующих товаров";
            // 
            // Txb_Soputka
            // 
            Txb_Soputka.BackColor = SystemColors.Window;
            Txb_Soputka.Font = new Font("Franklin Gothic Book", 9F);
            Txb_Soputka.Location = new Point(336, 83);
            Txb_Soputka.Multiline = true;
            Txb_Soputka.Name = "Txb_Soputka";
            Txb_Soputka.Size = new Size(140, 25);
            Txb_Soputka.TabIndex = 7;
            // 
            // Txb_Bonus
            // 
            Txb_Bonus.BackColor = SystemColors.Window;
            Txb_Bonus.Font = new Font("Franklin Gothic Book", 9F);
            Txb_Bonus.Location = new Point(336, 113);
            Txb_Bonus.Multiline = true;
            Txb_Bonus.Name = "Txb_Bonus";
            Txb_Bonus.Size = new Size(140, 25);
            Txb_Bonus.TabIndex = 8;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label12.ForeColor = SystemColors.Menu;
            label12.Location = new Point(18, 121);
            label12.Name = "label12";
            label12.Size = new Size(50, 17);
            label12.TabIndex = 57;
            label12.Text = "Бонусы";
            // 
            // Txb_Refund
            // 
            Txb_Refund.BackColor = SystemColors.Window;
            Txb_Refund.Font = new Font("Franklin Gothic Book", 9F);
            Txb_Refund.Location = new Point(336, 143);
            Txb_Refund.Multiline = true;
            Txb_Refund.Name = "Txb_Refund";
            Txb_Refund.Size = new Size(140, 25);
            Txb_Refund.TabIndex = 9;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label13.ForeColor = SystemColors.Menu;
            label13.Location = new Point(18, 151);
            label13.Name = "label13";
            label13.Size = new Size(64, 17);
            label13.TabIndex = 59;
            label13.Text = "Возвраты";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(Txb_Otpusk);
            groupBox1.Controls.Add(label18);
            groupBox1.Controls.Add(Txb_nalichie);
            groupBox1.Controls.Add(Txb_Refund);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(Txb_Bonus);
            groupBox1.Controls.Add(Txb_zakaz);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(Txb_Soputka);
            groupBox1.Controls.Add(Txb_oklad);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(Txb_kpiOne);
            groupBox1.Controls.Add(Txb_kpiTwo);
            groupBox1.Controls.Add(label5);
            groupBox1.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Italic, GraphicsUnit.Point, 204);
            groupBox1.ForeColor = SystemColors.Info;
            groupBox1.Location = new Point(23, 168);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(522, 307);
            groupBox1.TabIndex = 60;
            groupBox1.TabStop = false;
            groupBox1.Text = "Показатели для расчёта зарабатной платы";
            // 
            // Txb_Otpusk
            // 
            Txb_Otpusk.BackColor = SystemColors.Window;
            Txb_Otpusk.Font = new Font("Franklin Gothic Book", 9F);
            Txb_Otpusk.Location = new Point(336, 267);
            Txb_Otpusk.Multiline = true;
            Txb_Otpusk.Name = "Txb_Otpusk";
            Txb_Otpusk.Size = new Size(140, 25);
            Txb_Otpusk.TabIndex = 13;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label18.ForeColor = SystemColors.Menu;
            label18.Location = new Point(18, 275);
            label18.Name = "label18";
            label18.Size = new Size(68, 17);
            label18.TabIndex = 61;
            label18.Text = "Отпускные";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(Dtp_Otpusk);
            groupBox2.Controls.Add(label16);
            groupBox2.Controls.Add(Txb_PayOtpusk);
            groupBox2.Controls.Add(label17);
            groupBox2.Controls.Add(Dtp_Avans);
            groupBox2.Controls.Add(label15);
            groupBox2.Controls.Add(Txb_Avans);
            groupBox2.Controls.Add(label14);
            groupBox2.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Italic, GraphicsUnit.Point, 204);
            groupBox2.ForeColor = SystemColors.Info;
            groupBox2.Location = new Point(23, 481);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(522, 144);
            groupBox2.TabIndex = 61;
            groupBox2.TabStop = false;
            groupBox2.Text = "Выплаты в пользу сотрудника";
            // 
            // Dtp_Otpusk
            // 
            Dtp_Otpusk.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Dtp_Otpusk.Location = new Point(336, 109);
            Dtp_Otpusk.Name = "Dtp_Otpusk";
            Dtp_Otpusk.Size = new Size(140, 21);
            Dtp_Otpusk.TabIndex = 17;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label16.ForeColor = SystemColors.Menu;
            label16.Location = new Point(18, 113);
            label16.Name = "label16";
            label16.Size = new Size(149, 17);
            label16.TabIndex = 66;
            label16.Text = "Дата выплаты отпускных";
            // 
            // Txb_PayOtpusk
            // 
            Txb_PayOtpusk.BackColor = SystemColors.Window;
            Txb_PayOtpusk.Font = new Font("Franklin Gothic Book", 9F);
            Txb_PayOtpusk.Location = new Point(336, 78);
            Txb_PayOtpusk.Multiline = true;
            Txb_PayOtpusk.Name = "Txb_PayOtpusk";
            Txb_PayOtpusk.Size = new Size(140, 25);
            Txb_PayOtpusk.TabIndex = 16;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label17.ForeColor = SystemColors.Menu;
            label17.Location = new Point(18, 86);
            label17.Name = "label17";
            label17.Size = new Size(68, 17);
            label17.TabIndex = 65;
            label17.Text = "Отпускные";
            // 
            // Dtp_Avans
            // 
            Dtp_Avans.Font = new Font("Franklin Gothic Book", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Dtp_Avans.Location = new Point(336, 51);
            Dtp_Avans.Name = "Dtp_Avans";
            Dtp_Avans.Size = new Size(140, 21);
            Dtp_Avans.TabIndex = 15;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label15.ForeColor = SystemColors.Menu;
            label15.Location = new Point(18, 55);
            label15.Name = "label15";
            label15.Size = new Size(132, 17);
            label15.TabIndex = 62;
            label15.Text = "Дата выплаты аванса";
            // 
            // Txb_Avans
            // 
            Txb_Avans.BackColor = SystemColors.Window;
            Txb_Avans.Font = new Font("Franklin Gothic Book", 9F);
            Txb_Avans.Location = new Point(336, 20);
            Txb_Avans.Multiline = true;
            Txb_Avans.Name = "Txb_Avans";
            Txb_Avans.Size = new Size(140, 25);
            Txb_Avans.TabIndex = 14;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label14.ForeColor = SystemColors.Menu;
            label14.Location = new Point(18, 28);
            label14.Name = "label14";
            label14.Size = new Size(42, 17);
            label14.TabIndex = 61;
            label14.Text = "Аванс";
            // 
            // Txb_id
            // 
            Txb_id.BackColor = SystemColors.ControlLight;
            Txb_id.Font = new Font("Franklin Gothic Book", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Txb_id.Location = new Point(332, 19);
            Txb_id.MaxLength = 35;
            Txb_id.Name = "Txb_id";
            Txb_id.PlaceholderText = "id записи";
            Txb_id.ReadOnly = true;
            Txb_id.Size = new Size(167, 22);
            Txb_id.TabIndex = 62;
            Txb_id.TextAlign = HorizontalAlignment.Center;
            // 
            // AddPayEmployee
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 54, 63);
            CancelButton = Btn_cancel;
            ClientSize = new Size(576, 688);
            Controls.Add(Txb_id);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(Btn_delete);
            Controls.Add(Btn_update);
            Controls.Add(Btn_save);
            Controls.Add(Btn_cancel);
            Controls.Add(Btn_addEmployee);
            Controls.Add(Btn_addStaff);
            Controls.Add(Btn_addOtdel);
            Controls.Add(Cbx_otdel);
            Controls.Add(label10);
            Controls.Add(Cbx_organization);
            Controls.Add(label9);
            Controls.Add(Cbx_nameEmployee);
            Controls.Add(label4);
            Controls.Add(Cbx_Staff);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(Dtp_dataOperation);
            Controls.Add(Btn_addOrganization);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AddPayEmployee";
            StartPosition = FormStartPosition.CenterScreen;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Btn_addOrganization;
        private DateTimePicker Dtp_dataOperation;
        private Label label2;
        private Label label3;
        private ComboBox Cbx_Staff;
        private Label label4;
        private ComboBox Cbx_nameEmployee;
        private Label label7;
        private TextBox Txb_oklad;
        private Label label9;
        private ComboBox Cbx_organization;
        private Label label10;
        private ComboBox Cbx_otdel;
        private Button Btn_addOtdel;
        private Button Btn_addStaff;
        private Button Btn_addEmployee;
        public Button Btn_delete;
        public Button Btn_update;
        public Button Btn_save;
        private Button Btn_cancel;
        private Label label11;
        private Label label1;
        private TextBox Txb_kpiOne;
        private Label label5;
        private TextBox Txb_kpiTwo;
        private Label label6;
        private TextBox Txb_nalichie;
        private Label label8;
        private TextBox Txb_zakaz;
        private TextBox Txb_Soputka;
        private TextBox Txb_Bonus;
        private Label label12;
        private TextBox Txb_Refund;
        private Label label13;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private DateTimePicker Dtp_Otpusk;
        private Label label16;
        private TextBox Txb_PayOtpusk;
        private Label label17;
        private DateTimePicker Dtp_Avans;
        private Label label15;
        private TextBox Txb_Avans;
        private Label label14;
        private TextBox Txb_Otpusk;
        private Label label18;
        private TextBox Txb_id;
        
        
        public void SetTxb_Id(string value) { Txb_id.Text = value; }
        public void SetDtp_dataOperation(DateTime value) { Dtp_dataOperation.Value = value; }
        public void SetCbx_organization(string value) { Cbx_organization.Text = value; }
        public void SetCbx_otdel(string value) { Cbx_otdel.Text = value; }
        public void SetCbx_Staff(string value) { Cbx_Staff.Text = value; }
        public void SetTxb_nalichie(string value) { Txb_nalichie.Text = value; }
        public void SetTxb_zakaz(string value) { Txb_zakaz.Text = value; }
        public void SetTxb_Soputka(string value) { Txb_Soputka.Text = value; }
        public void SetTxb_Bonus(string value) { Txb_Bonus.Text = value; }
        public void SetTxb_Refund(string value) { Txb_Refund.Text = value; }
        public void SetTxb_oklad(string value) { Txb_oklad.Text = value; }
        public void SetTxb_kpiOne(string value) { Txb_kpiOne.Text = value; }
        public void SetTxb_kpiTwo(string value) { Txb_kpiTwo.Text = value; }
        public void SetTxb_Otpusk(string value) { Txb_Otpusk.Text = value; }
        public void SetTxb_Avans(string value) { Txb_Avans.Text = value; }
        public void SetDtp_Avans(DateTime value) { Dtp_Avans.Value = value; }
        public void SetTxb_PayOtpusk(string value) { Txb_PayOtpusk.Text = value; }
        public void SetDtp_Otpusk(DateTime value) { Dtp_Otpusk.Value = value; }
        public void SetCbx_nameEmployee(string value) { Cbx_nameEmployee.Text = value; }
    }

}