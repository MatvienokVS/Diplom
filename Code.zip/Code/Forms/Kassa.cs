﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System.Data;

namespace AIS.Forms
{
    public partial class Kassa : Form
    {
        private readonly DB.DB db;
        public readonly DataTable dataTable;

        private IQuerySelect _querySelect;

        public string selectedFilePath;
        public string id = Const.ID;
        public string nameTable = Const.USER_TABLE_KASSA;
        public string Login { get; set; }

        public Kassa()
        {
            InitializeComponent();

            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            DateTime today = DateTime.Today;
            DateTime firstDayOfMonth = new(today.Year, today.Month, 1);

            Dtp_start.Value = firstDayOfMonth;

            Dtp_start.ValueChanged += Dtp_start_ValueChanged;

            this.Load += (sender, e) =>
            {
                //ComboManage();
                //Cbx_otdel.Text = NameOtdel();
                //Cbx_organization.Text = NameOrganization();
            };
            _ = changeOpacity();

        }
        // Асинхронная функция задержки открытия окна
        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }
        private void Btn_addOperation_Click(object sender, EventArgs e)
        {
            AddOperatoin addOperatoin = new();
            addOperatoin.Btn_delete.Enabled = false;
            addOperatoin.Btn_delete.BackColor = Color.LightGray;
            addOperatoin.Btn_update.Enabled = false;
            addOperatoin.Btn_update.BackColor = Color.LightGray;
            addOperatoin.Login = Login;

            addOperatoin.SaveSuccess += AddOperatoin_SaveSuccess;

            addOperatoin.ShowDialog();
        }
        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            TabControlManager.CloseCurrentTab(this);
            this.Dispose(); // Освобождаем ресурсы формы
        }
        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = KassaModel.USER_TABLE_KASSA;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            string dataOperation = KassaModel.DATA_OPERATION;
            string search = Txb_search.Text.Replace(",", ".");

            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                var emplCreator = GetEmplCreatorKassa();
                string queryCreateTable = emplCreator.CreateTableKassa();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string nameOtdel = AcceessRoleNameOtdel();
                string nameOrganization = AcceessRoleNameOrganization();
                string role = NameRole();

                string periodStart = Dtp_start.Value.ToString("yyyy-MM-dd");
                string periodStop = Dtp_stop.Value.ToString("yyyy-MM-dd");

                string selectQuery = KassaModel.ShowAllStringFromTable(nameTable, 
                                                                       periodStart, 
                                                                       periodStop, 
                                                                       dataOperation, 
                                                                       search, 
                                                                       nameOrganization, 
                                                                       nameOtdel,
                                                                       role);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);
                Tbl_Kassa.DataSource = dataTable;
                NameFieldsTableView();

            }
            db.DisConnect();
        }
        private void Tbl_Kassa_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            AddOperatoin addOperatoin = new();
            addOperatoin.Btn_save.Enabled = false;
            addOperatoin.Btn_save.BackColor = Color.LightGray;
            addOperatoin.Login = Login;

            DataGridViewRow selectedRow = Tbl_Kassa.Rows[e.RowIndex];

            // Получаем данные из выбранной строки
            string id = selectedRow.Cells["id"].Value.ToString();
            string dataOperationString = selectedRow.Cells["dataOperation"].Value.ToString();
            DateTime dataOperation = DateTime.Parse(dataOperationString);
            string nameArticle = selectedRow.Cells["nameArticle"].Value.ToString();
            string surnameUser = selectedRow.Cells["surnameUser"].Value.ToString();
            string payment = selectedRow.Cells["payment"].Value.ToString();
            string formPay = selectedRow.Cells["formPay"].Value.ToString();
            decimal summ = decimal.Parse(selectedRow.Cells["summ"].Value.ToString());
            string typeOperation = selectedRow.Cells["typeOperation"].Value.ToString();
            //string discriptor = selectedRow.Cells["discriptor"].Value.ToString();
            string nameOrganization = selectedRow.Cells["nameOrganization"].Value.ToString();
            string nameOtdel = selectedRow.Cells["nameOtdel"].Value.ToString();
            //string articleBDDS = selectedRow.Cells["articleBDDS"].Value.ToString();

            //Заполняем поля для редактирования или удаления данных
            addOperatoin.SetTxb_Id(id);
            addOperatoin.SetDtp_dataOperation(dataOperation);
            addOperatoin.SetCbx_nameOperation(nameArticle);
            addOperatoin.SetCbx_nameEmployee(surnameUser);
            addOperatoin.SetCbx_payment(payment);
            addOperatoin.SetCbx_formPay(formPay);

            string summString = summ.ToString("F2");
            summString = summString.Replace(",", ".");
            addOperatoin.SetTxb_summ(summString);

            addOperatoin.SetTxb_type(typeOperation);
            addOperatoin.SetCbx_organization(nameOrganization);
            addOperatoin.SetCbx_otdel(nameOtdel);

            addOperatoin.UpdateSuccess += AddOperatoin_UpdateSuccess;
            addOperatoin.DeleteSuccess += AddOperatoin_DeleteSuccess;

            addOperatoin.ShowDialog();
        }
        private void Dtp_start_ValueChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
            UpdateSumLabel();
        }
        private void Dtp_stop_ValueChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
            UpdateSumLabel();
        }
        private void Btn_download_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new()
            {
                Filter = "Excel Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*"
            };
            //openFileDialog.ShowDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                selectedFilePath = openFileDialog.FileName;
            }

            db.Connect();

            // Чтение данных из файла Excel
            //using ExcelPackage package = new(new FileInfo(selectedFilePath));
            //ExcelWorksheet worksheet = package.Workbook.Worksheets[0];
            //DataTable dt = new();

            //// Заполнение DataTable данными из файла Excel
            //foreach (var firstRowCell in worksheet.Cells[1, 1, 1, worksheet.Dimension.End.Column])
            //{
            //    dt.Columns.Add(firstRowCell.Text.Trim());
            //}

            //for (var rowNumber = 2; rowNumber <= worksheet.Dimension.End.Row; rowNumber++)
            //{
            //    var row = worksheet.Cells[rowNumber, 1, rowNumber, worksheet.Dimension.End.Column];
            //    var newRow = dt.NewRow();

            //    foreach (var cell in row)
            //    {
            //        newRow[cell.Start.Column - 1] = cell.Text;
            //    }

            //    dt.Rows.Add(newRow);
            //}

            //// Запись данных в базу данных
            //using SqlConnection connection = new SqlConnection("YOUR_CONNECTION_STRING");
            //connection.Open();

            //using SqlBulkCopy bulkCopy = new SqlBulkCopy(connection);
            //bulkCopy.DestinationTableName = "YOUR_TABLE_NAME";
            //bulkCopy.WriteToServer(dt);
        }
        private void Txb_search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {   
                Txb_search.Text = "";
            }
        }
        private void Tbl_Kassa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                Txb_search.Text = "";
            }
        }
        private void AddOperatoin_SaveSuccess(object? sender, EventArgs e)
        {
            UpdateDataGridView();
            UpdateSumLabel();
        }
        private void AddOperatoin_DeleteSuccess(object? sender, EventArgs e)
        {
            UpdateDataGridView();
            UpdateSumLabel();
        }
        private void AddOperatoin_UpdateSuccess(object? sender, EventArgs e)
        {
            UpdateDataGridView();
            UpdateSumLabel();
        }
        public void UpdateSumLabel()
        {
            // Начальный остаток
            decimal sum_initialBalance = 0;
            Lbl_initialBalance.Text = "Начальный остаток: " + sum_initialBalance.ToString("N");

            // Приход
            decimal sum_entrance = 0;
            foreach (DataGridViewRow row in Tbl_Kassa.Rows)
            {
                if (row.Visible)
                {
                    if (row.Cells["typeOperation"].Value.ToString() == "приход") // Проверка значения в соседнем столбце "Тип"
                    {
                        if (decimal.TryParse(row.Cells["summ"].Value.ToString(), out decimal value))
                        {
                            sum_entrance += value;
                        }
                    }
                }
                Lbl_entrance.Text = "Приход: " + sum_entrance.ToString("N");
            }
            // Расход
            decimal sum_expenses = 0;
            foreach (DataGridViewRow row in Tbl_Kassa.Rows)
            {
                if (row.Visible)
                {
                    if (row.Cells["typeOperation"].Value.ToString() == "расход") // Проверка значения в соседнем столбце "Тип"
                    {
                        if (decimal.TryParse(row.Cells["summ"].Value.ToString(), out decimal value))
                        {
                            sum_expenses += value;
                        }
                    }
                }
                Lbl_expenses.Text = "Расход: " + sum_expenses.ToString("N");
            }

            // Конечный остаток
            decimal finalBalance = sum_entrance - sum_expenses;
            Lbl_finalBalance.Text = "Конечный остаток: " + finalBalance.ToString("N"); // Или finalBalance.ToString("C")
        }
        private string NameOrganization()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = RegistrationModel.USER_TABLE_User,
                searchField = RegistrationModel.NAME_ORGANIZATION,
                nameField = RegistrationModel.E_MAIL,
                valueField = Login,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();

            }
            return resultString;
        }
        private string NameOtdel()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = RegistrationModel.USER_TABLE_User,
                searchField = RegistrationModel.NAME_OTDEL,
                nameField = RegistrationModel.E_MAIL,
                valueField = Login,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }

            return resultString;
        }
        private IEmplCreatorKassa GetEmplCreatorKassa()
        {
            return new KassaModel();
        }
        private void Txb_search_TextChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
            UpdateSumLabel();
        }        
        private void Cbx_organization_TextChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
            UpdateSumLabel();
        }
        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
        private void NameFieldsTableView()
        {
            Tbl_Kassa.Columns["dataOperation"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Tbl_Kassa.Columns["dataOperation"].HeaderText = "Дата операции";
            Tbl_Kassa.Columns["dataOperation"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Kassa.Columns["nameArticle"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Tbl_Kassa.Columns["nameArticle"].HeaderText = "Наименование операции";
            Tbl_Kassa.Columns["nameArticle"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Kassa.Columns["surnameUser"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Tbl_Kassa.Columns["surnameUser"].HeaderText = "Кто получил деньги";
            Tbl_Kassa.Columns["surnameUser"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Kassa.Columns["payment"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Tbl_Kassa.Columns["payment"].HeaderText = "Назначение платежа";
            Tbl_Kassa.Columns["payment"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Kassa.Columns["formPay"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Tbl_Kassa.Columns["formPay"].HeaderText = "Форма платежа";
            Tbl_Kassa.Columns["formPay"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Kassa.Columns["summ"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Tbl_Kassa.Columns["summ"].HeaderText = "Сумма";
            Tbl_Kassa.Columns["summ"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Tbl_Kassa.Columns["summ"].DefaultCellStyle.Format = "N2";
            Tbl_Kassa.Columns["summ"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            Tbl_Kassa.Columns["typeOperation"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Tbl_Kassa.Columns["typeOperation"].HeaderText = "Тип операции";
            Tbl_Kassa.Columns["typeOperation"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Tbl_Kassa.Columns["discriptor"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            //Tbl_Kassa.Columns["discriptor"].HeaderText = "Дискриптор";
            //Tbl_Kassa.Columns["discriptor"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Kassa.Columns["nameOrganization"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Tbl_Kassa.Columns["nameOrganization"].HeaderText = "Организация";
            Tbl_Kassa.Columns["nameOrganization"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Kassa.Columns["nameOtdel"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Tbl_Kassa.Columns["nameOtdel"].HeaderText = "Подразделение";
            Tbl_Kassa.Columns["nameOtdel"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Kassa.Columns["articleBDDS"].Width = 100;
            Tbl_Kassa.Columns["articleBDDS"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Tbl_Kassa.Columns["articleBDDS"].HeaderText = "Статья БДДС";
            Tbl_Kassa.Columns["articleBDDS"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Tbl_Kassa.Columns["nameRole"].Width = 100;
            //Tbl_Kassa.Columns["nameRole"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            //Tbl_Kassa.Columns["nameRole"].HeaderText = "Роль";
            //Tbl_Kassa.Columns["nameRole"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
        private string NameRole()
        {
            db.Connect();
            var arg = new SearchArgField()
            {
                nameTable = RegistrationModel.USER_TABLE_User,
                searchField = RegistrationModel.NAME_ROLE,
                nameField = RegistrationModel.E_MAIL,
                valueField = Login,
            };
            string searchField = QuerySelect.SearchField(arg);
            DataTable result = db.ExecuteDataTable(searchField);
            string resultString = "";
            if (result.Rows.Count > 0)
            {
                resultString = result.Rows[0][0].ToString();
            }
            return resultString;
        }
        private string AcceessRoleNameOtdel()
        {
            string role = NameRole();
            string nameOtdel;
            switch (role)
            {
                case "user":
                    nameOtdel = NameOtdel();
                    Cbx_otdel.Enabled = false;
                    break;

                case "admin":
                    nameOtdel = Cbx_otdel.Text;
                    break;

                case "директор":
                    nameOtdel = Cbx_otdel.Text;
                    break;

                case "менеджер":
                    nameOtdel = NameOtdel();
                    Cbx_otdel.Enabled = false;
                    break;

                case "бухгалтер":
                    nameOtdel = NameOtdel();
                    Cbx_otdel.Enabled = false;
                    break;

                case "руководитель":
                    nameOtdel = NameOtdel();
                    Cbx_otdel.Enabled = true;

                    break;

                default:
                    nameOtdel = NameOtdel();
                    Cbx_otdel.Enabled = false;
                    break;
            }
            return nameOtdel;
        }
        private string AcceessRoleNameOrganization()
        {
            string role = NameRole();

            string nameOrganization;
            switch (role)
            {
                case "user":
                    nameOrganization = NameOrganization();
                    Cbx_organization.Enabled = false;
                    break;

                case "admin":
                    nameOrganization = Cbx_organization.Text;
                    break;

                case "директор":
                    nameOrganization = Cbx_organization.Text;
                    break;

                case "менеджер":
                    nameOrganization = NameOrganization();
                    Cbx_organization.Enabled = false;
                    break;

                case "бухгалтер":
                    nameOrganization = Cbx_organization.Text;
                    break;

                case "руководитель":
                    nameOrganization = NameOrganization();
                    Cbx_otdel.Enabled = true;
                    break;

                default:
                    nameOrganization = NameOrganization();
                    Cbx_organization.Enabled = false;
                    break;
            }
            return nameOrganization;
        }
        public void FillCbxOrganization()
        {
            var currentRole = NameRole();

            db.Connect();
            Cbx_organization.Items.Clear();
            string nameTable = Const.USER_TABLE_ORGANIZATION;
            string nameColumn = Const.NAME_ORGANIZATION;
            string queryOrganizationlNames = QuerySelect.GetDataForCbxOrganization(nameColumn, nameTable, currentRole);
            db.ExecuteDataCombobox(queryOrganizationlNames, Cbx_organization, nameColumn);
        }
        public void FillCbxOtdel()
        {
            var currentRole = NameRole();

            db.Connect();
            string nameTable = Const.USER_TABLE_OTDEL;
            string nameColumn = Const.NAME_OTDEL;
            string queryOtdelNames = QuerySelect.GetDataForCbxOtdel(nameColumn, nameTable, currentRole);
            db.ExecuteDataCombobox(queryOtdelNames, Cbx_otdel, nameColumn);
        }
        private void Cbx_otdel_TextChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
            UpdateSumLabel();
        }
        private void ComboManage()
        {
            Cbx_organization.FillDefaultValue("Название организации");
            Cbx_otdel.FillDefaultValue("Название подразделения");
        }

    }   
}

