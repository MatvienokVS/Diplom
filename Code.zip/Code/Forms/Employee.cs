﻿using AIS.DB;
using AIS.Func;
using AIS.Models;
using AIS.Query;
using System.Data;

namespace AIS.Forms
{
    public partial class Employee : Form
    {
        private IQuerySelect _querySelect;

        private readonly DB.DB db;
        public readonly DataTable dataTable;
        public WindowMover _windowMover;


        public Employee()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            db = new DB.DB(Config.DB_hostname, Config.DB_name, Config.DB_user, Config.DB_password);
            dataTable = new DataTable();

            ComboManage();

            Dtp_birthday.Value = DateTime.Now;
            Btn_update.Enabled = false;
            Btn_update.BackColor = Color.LightGray;
            Btn_delete.Enabled = false;
            Btn_delete.BackColor = Color.LightGray;

            UpdateDataGridView();
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplCreator = GetEmplCreatorEmployee();
                string queryCreateTable = emplCreator.CreateTableEmployees();
                db.ExecuteNonQuery(queryCreateTable);

                if (!ValidateEmployee())
                {
                    return;
                }

                var emplInsert = GetEmplInsertEmployee();
                var arg = new InsertArgEmployees()
                {
                    numberEmployee = Txb_namberEmployee.Text,
                    surnameUser = Txb_surnameEmployee.Text,
                    nameUser = Txb_nameEmployee.Text,
                    middleName = Txb_middlenameEmployee.Text,
                    nameOrganization = Cbx_organization.Text,
                    nameOtdel = Cbx_otdel.Text,
                    nameStaff = Cbx_staff.Text,
                    birthday = Dtp_birthday.Value.Date,
                };
                // Записываем данные в базу данных

                string insertQuery = emplInsert.InsertDataEmployees(arg);
                int numRowsInserted = db.ExecuteNonQuery(insertQuery);

                if (numRowsInserted > 0)
                {
                    //MessageBox.Show("Данные успешно сохранены.");
                }
                else
                {
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);
                }

                UpdateDataGridView();
                ClearForm();
                ComboManage();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                // TODO првоерить весь код
                db.DisConnect();
            }
        }

        private void ComboManage()
        {
            Cbx_organization.FillDefaultValue("Название организации");

            Cbx_staff.FillDefaultValue("Название должности");

            Cbx_otdel.FillDefaultValue("Название подразделения");
        }

        private bool ValidateEmployee()
        {
            if (string.IsNullOrEmpty(Txb_surnameEmployee.Text) ||
                string.IsNullOrEmpty(Txb_nameEmployee.Text) ||
                string.IsNullOrEmpty(Txb_middlenameEmployee.Text) ||
                string.IsNullOrEmpty(Txb_namberEmployee.Text) ||
                string.IsNullOrEmpty(Cbx_organization.SelectedItem as string) ||
                string.IsNullOrEmpty(Cbx_staff.SelectedItem as string) ||
                string.IsNullOrEmpty(Cbx_otdel.SelectedItem as string))
            {
                MessageBox.Show("Введите данные сотрудника");
                return false;
            }
            return true;
        }

        private void ClearForm()
        {
            Txb_namberEmployee.Text = "";
            Txb_surnameEmployee.Text = "";
            Txb_nameEmployee.Text = "";
            Txb_middlenameEmployee.Text = "";
            Cbx_organization.Text = "";
            Cbx_staff.Text = "";
            Cbx_otdel.Text = "";
            Dtp_birthday.Value = DateTime.Now;
            Txb_id.Text = "";
        }

        public void UpdateDataGridView()
        {
            db.Connect();

            string nameTable = EmployeesModel.USER_TABLE_EMPLOYEE;
            string checkQuery = QuerySelect.CheckTableQuery(nameTable);
            int checkQueryResult = db.ExecuteNonQuery(checkQuery);
            if (checkQueryResult == 0)
            {
                var emplCreator = GetEmplCreatorEmployee();
                string queryCreateTable = emplCreator.CreateTableEmployees();
                db.ExecuteNonQuery(queryCreateTable);
            }
            else
            {
                string selectQuery = QuerySelect.ShowAllStringFromTable(nameTable);
                DataTable dataTable = db.ExecuteDataTable(selectQuery);
                Tbl_Employee.DataSource = dataTable;

                NameFieldsTableView();
            }
            db.DisConnect();
        }

        private void Tbl_Employee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                ClearForm();

                ComboManage();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
        }

        private void Tbl_Employee_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = Tbl_Employee.Rows[e.RowIndex];

                // Получаем данные из выбранной строки
                string id = selectedRow.Cells["id"].Value.ToString();
                string numberEmployee = selectedRow.Cells["namberEmployee"].Value.ToString();
                string surnameUser = selectedRow.Cells["surnameUser"].Value.ToString();
                string nameUser = selectedRow.Cells["nameUser"].Value.ToString();
                string middleName = selectedRow.Cells["middleName"].Value.ToString();
                string nameOrganization = selectedRow.Cells["nameOrganization"].Value.ToString();
                string nameOtdel = selectedRow.Cells["nameOtdel"].Value.ToString();
                string nameStaff = selectedRow.Cells["nameStaff"].Value.ToString();
                string birthdayString = selectedRow.Cells["birthday"].Value.ToString();

                DateTime birthday = DateTime.Parse(s: birthdayString);

                //Заполняем поля для редактирования или удаления данных
                Txb_id.Text = id;
                Txb_namberEmployee.Text = numberEmployee;
                Txb_surnameEmployee.Text = surnameUser;
                Txb_nameEmployee.Text = nameUser;
                Txb_middlenameEmployee.Text = middleName;
                Cbx_organization.Text = nameOrganization;
                Cbx_otdel.Text = nameOtdel;
                Cbx_staff.Text = nameStaff;
                Dtp_birthday.Value = birthday;

                Btn_update.Enabled = true;
                Btn_update.BackColor = Color.FromArgb(98, 171, 180);
                Btn_delete.Enabled = true;
                Btn_delete.BackColor = Color.FromArgb(98, 171, 180);
                Btn_save.Enabled = false;
                Btn_save.BackColor = Color.LightGray;

            }
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                string nameTable = EmployeesModel.USER_TABLE_EMPLOYEE;
                string condition = EmployeesModel.NAMBER_EMPLOYEE + " = '" + Txb_namberEmployee.Text + "'";
                string deleteQuery = QuerySelect.DeleteStringDateTableQuery(nameTable, condition);
                db.ExecuteNonQuery(deleteQuery);

                UpdateDataGridView();
                ClearForm();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                // TODO првоерить весь код
                db.DisConnect();
            }
        }

        private void Cbx_organization_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_organization.Items.Clear();
            string nameTable = Const.USER_TABLE_ORGANIZATION;
            string nameColumn = Const.NAME_ORGANIZATION;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_organization, nameColumn);
        }

        private void Cbx_otdel_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_otdel.Items.Clear();
            string nameTable = Const.USER_TABLE_OTDEL;
            string nameColumn = Const.NAME_OTDEL;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_otdel, nameColumn);
        }

        private void Cbx_staff_Click(object sender, EventArgs e)
        {
            db.Connect();
            Cbx_staff.Items.Clear();
            string nameTable = Const.USER_TABLE_STAFF;
            string nameColumn = Const.NAME_STAFF;
            string executeDataCombobox = QuerySelect.GetDataForCombobox(nameColumn, nameTable);
            db.ExecuteDataCombobox(executeDataCombobox, Cbx_staff, nameColumn);
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                db.Connect();

                var emplUpdate = GetEmplUpdateEmployee();
                var arg = new UpdateArgEmployees()
                {
                    nameTable = EmployeesModel.USER_TABLE_EMPLOYEE,
                    namberEmployee = Txb_namberEmployee.Text,
                    surnameUser = Txb_surnameEmployee.Text,
                    nameUser = Txb_nameEmployee.Text,
                    middleName = Txb_middlenameEmployee.Text,
                    nameOrganization = Cbx_organization.Text,
                    nameOtdel = Cbx_otdel.Text,
                    nameStaff = Cbx_staff.Text,
                    birthday = Dtp_birthday.Value,
                    id = Txb_id.Text
                };

                string queryUpdateLine = emplUpdate.UpdateDateEmployees(arg);
                int numRowsUpdated = db.ExecuteNonQuery(queryUpdateLine);

                if (numRowsUpdated > 0) ;
                //MessageBox.Show("Данные успешно сохранены.");
                else
                    MessageBox.Show("Ошибка вставки данных " + db.LastError);

                UpdateDataGridView();
                ClearForm();

                Btn_update.Enabled = false;
                Btn_update.BackColor = Color.LightGray;
                Btn_delete.Enabled = false;
                Btn_delete.BackColor = Color.LightGray;
                Btn_save.Enabled = true;
                Btn_save.BackColor = Color.FromArgb(98, 171, 180);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при записи данных в базу данных: " + ex.Message);
            }
            finally
            {
                db.DisConnect();
            }
        }

        private void Cbx_organization_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_otdel_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Cbx_staff_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private IEmplCreatorEmployee GetEmplCreatorEmployee()
        {
            return new EmployeesModel();
        }

        private IEmplInsertEmployee GetEmplInsertEmployee()
        {
            return new EmployeesModel();
        }

        private IEmplUpdateEmployee GetEmplUpdateEmployee()
        {
            return new EmployeesModel();
        }

        private void NameFieldsTableView()
        {
            Tbl_Employee.Columns["id"].Width = 40;
            Tbl_Employee.Columns["id"].HeaderText = "id";
            Tbl_Employee.Columns["id"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Tbl_Employee.Columns["id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Employee.Columns["namberEmployee"].Width = 80;
            Tbl_Employee.Columns["namberEmployee"].HeaderText = "Табельный номер";
            Tbl_Employee.Columns["namberEmployee"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Tbl_Employee.Columns["namberEmployee"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Employee.Columns["surnameUser"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Tbl_Employee.Columns["surnameUser"].HeaderText = "Фамилия";
            Tbl_Employee.Columns["surnameUser"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Employee.Columns["nameUser"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Tbl_Employee.Columns["nameUser"].HeaderText = "Имя";
            Tbl_Employee.Columns["nameUser"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Employee.Columns["middleName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Tbl_Employee.Columns["middleName"].HeaderText = "Отчество";
            Tbl_Employee.Columns["middleName"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Employee.Columns["nameOrganization"].Width = 140;
            Tbl_Employee.Columns["nameOrganization"].HeaderText = "Организация";
            Tbl_Employee.Columns["nameOrganization"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Employee.Columns["nameOtdel"].Width = 100;
            Tbl_Employee.Columns["nameOtdel"].HeaderText = "Подразделение";
            Tbl_Employee.Columns["nameOtdel"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Employee.Columns["nameStaff"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Tbl_Employee.Columns["nameStaff"].HeaderText = "Должность";
            Tbl_Employee.Columns["nameStaff"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tbl_Employee.Columns["birthday"].Width = 80;
            Tbl_Employee.Columns["birthday"].HeaderText = "Дата рождения";
            Tbl_Employee.Columns["birthday"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Tbl_Employee.Columns["birthday"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private IQuerySelect QuerySelect
        {
            get
            {
                if (_querySelect != null) return _querySelect;

                return new QuerySelect();
            }
        }
    }
}
