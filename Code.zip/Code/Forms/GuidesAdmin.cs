﻿using AIS.Func;

namespace AIS.Forms
{
    public partial class GuidesAdmin : Form
    {
        public WindowMover _windowMover;
        public GuidesAdmin()
        {
            InitializeComponent();
            _windowMover = new WindowMover(this);
            _ = changeOpacity();
        }

        public async Task changeOpacity()
        {
            ChangeOpacity _changeOpacity = new(this);
            await _changeOpacity._changeOpacity();
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_personal_Click(object sender, EventArgs e)
        {
            RegistrationUser registrationUser = new RegistrationUser();
            registrationUser.ShowDialog();
        }

        private void Btn_access_Click(object sender, EventArgs e)
        {
            Role role = new();
            role.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RoleAccessOtdel roleAccess = new RoleAccessOtdel();
            roleAccess.ShowDialog();
        }

        private void Btn_organizationAccess_Click(object sender, EventArgs e)
        {
            RoleAccessOrganization roleAccess = new RoleAccessOrganization();
            roleAccess.ShowDialog();
        }
    }
}
