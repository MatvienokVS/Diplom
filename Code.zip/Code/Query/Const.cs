﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIS.Query
{
    internal class Const
    {
        public static string USER_TABLE_ORGANIZATION = "organization";
        public static string ID = "id";
        public static string CODE_ORGANIZATION = "codeOrganization";
        public static string NAME_ORGANIZATION = "nameOrganization";
        public static string USER_TABLE_User = "usersLogin"; // Название таблицы для регистрации пользователя
        public static string NAME_USER = "nameUser"; // Имя
        public static string SURNAME_USER = "surnameUser"; // Фамилия
        public static string MIDDLE_NAME = "middleName"; // Отчество
        public static string DISCRIPTOR_NAME = "discriptor"; // Имя учётной зависи Виндовс

        // Организация берём nameOrganization
        public static string USER_TABLE_STAFF = "staff"; // Название таблицы для добавления должности
        public static string NAME_STAFF = "nameStaff"; // Должность
        public static string CODE_STAFF = "codeStaff"; // код Должности
        public static string USER_TABLE_OTDEL = "otdels"; // Название таблицы для добавления отдела
        public static string NAME_OTDEL = "nameOtdel"; // Отдел
        public static string CODE_OTDEL = "codeOtdel"; // код отдела
        public static string E_MAIL = "email"; // Электронная почта
        public static string PASSWORD = "password"; // Пароль
        public static string HASHPASSWORD = "hashpassword"; // Хеш пароля

        // Данные таблицы сотрудников
        public static string USER_TABLE_EMPLOYEE = "employee"; // Название таблицы справочника сотрудников
        public static string NAMBER_EMPLOYEE = "namberEmployee"; // Табельный номер
        // Фамилию берём из SURNAME_USER.
        // Имя берем из NAME_USER.
        // Отчество берем из MIDDLENAME.
        // Должность берем из STAFF.
        // ИНН берём из INN.
        // Организацию берем из NAME_ORGANIZATION.
        public static string BIRTHDAY = "birthday";

        // Данные таблицы контрагенты

        public static string USER_TABLE_COMPANY = "company";
        public static string INN_COMPANY = "innCompany";
        public static string NAME_COMPANY = "nameCompany"; // Название компании
        // ИНН
        public static string CONTACT_PERSON = "contactPerson"; // Контактное лицо

        // Данные таблицы операции БДДС
        public static string USER_TABLE_ARTICLE = "operation";
        public static string NAME_ARTICLE = "nameArticle";
        public static string ARTICLE_BDDS = "articleBDDS";

        
        // Данные таблицы операции кассы
        public static string USER_TABLE_KASSA = "kassa";
        public static string DATA_OPERATION = "dataOperation";
        public static string NAME_OPERATION = "nameOperation";
        // Фамилию берём из SURNAME_USER.
        public static string PAYMENT = "payment";
        public static string FORM_PAY = "formPay";
        public static string SUMM = "summ";
        public static string TYPE_OPERATION = "typeOperation";
        // Дискриптор берём из DISCRIPTOR_NAME.
        // Организация берём из NAME_ORGANIZATION.
        // Отдел берём из NAME_OTDEL.
        // Статью берём из ARTICLE_BDDS.
        public static string LINK_DOCUMENT = "linkDocument";

        // Данные таблицы операции формы платежа
        public static string USER_TABLE_FORM_PAY = "formPay";
        public static string CODE_PAY = "codePay";
        public static string NAME_FORM_PAY = "nameFormPay";






    }
}
