﻿using AIS.Models;

namespace AIS.Query
{
    interface IQuerySelect
    {
        string ShowAllStringFromTable(string nameTable);
        string CheckTableQuery(string nameTable);
        string SearchDataForAuth(string nameTable, string login, string password);
        string GetDataForCombobox(string nameColumn, string nameTable);
        string GetDataForCbxOtdel(string nameColumn, string nameTable, string roleName);
        string GetDataForCbxOrganization(string nameColumn, string nameTable, string roleName);
        string DeleteStringDateTableQuery(string nameTable, string condition);
        string SearchField(SearchArgField searchArgField);

    }


    internal class QuerySelect : IQuerySelect
    {
        // Запрос на получение всех строк в таблице
        public string ShowAllStringFromTable(string nameTable)
        {
            return $"SELECT * FROM {nameTable}";
        }

        // Запрос на создание таблицы организаций если её не существует в базе данных
        public string CheckTableQuery(string nameTable)
        {
            return $"SELECT 1 FROM {nameTable}";
        }

        // Запрос на удаление строки таблицы
        public string DeleteStringDateTableQuery(string nameTable, string condition)
        {
            return $"DELETE FROM {nameTable} WHERE {condition}";
        }

        // Запрос на проверку данных для авторизаци
        public string SearchDataForAuth(string nameTable, string login, string password)
        {
            return $"SELECT * FROM {nameTable} WHERE email = '{login}' AND password = '{password}'";
        }

        // Запрос на получение данных для выподающего списка
        public string GetDataForCbxOtdel(string nameColumn, string nameTable, string roleName)
        {
            // TODO создать в бд таблицу RoleAccess
            // TODO заполнить ее (руками написать insert into .....)
            return @$"
                SELECT {nameColumn} 
                FROM {nameTable} 
                INNER JOIN roleOtdelAccess ra ON {nameTable}.nameOtdel = ra.idOtdel
                INNER JOIN role r ON ra.idRoles = r.nameRole
                WHERE r.nameRole = '{roleName}'";
        }
        public string GetDataForCbxOrganization(string nameColumn, string nameTable, string roleName)
        {
            return @$"
                SELECT {nameColumn} 
                FROM {nameTable} 
                INNER JOIN roleOrganizationAccess ra ON {nameTable}.nameOrganization = ra.idOrganization
                INNER JOIN role r ON ra.idRoles = r.nameRole
                WHERE r.nameRole = '{roleName}'";
        }

        public string GetDataForCombobox(string nameColumn, string nameTable)
        {
            
            return $"SELECT {nameColumn} FROM {nameTable}";
        }

        // Запрос на получение поля из любой таблицы
        public string SearchField(SearchArgField searchArgField)
        {
            return $"SELECT {searchArgField.searchField} FROM {searchArgField.nameTable} WHERE {searchArgField.nameField} = '{searchArgField.valueField}'";
        }
    }

    class SearchArgField
    {
        public string nameTable { get; init; }
        public string searchField { get; init; }
        public string nameField { get; init; }
        public string valueField { get; init; }
    }
}
