﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIS.Query
{
    internal class Phrase
    {
        public static string phraseOperation = "Название статьи";
        public static string phraseEmployee = "Фамилия сотрудника";
        public static string phraseOrganization = "Наименование организации";
        public static string phraseOtdel = "Наименование отдела";
        public static string phraseformPay = "Форма оплаты";

    }
}
