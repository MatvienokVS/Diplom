using MySql.Data.MySqlClient;
using System;

using System.Timers;

namespace AIS
{
    internal static class Program
    {

        [STAThread]
        static void Main()
        {              
            ApplicationConfiguration.Initialize();
            Application.Run(new Autorization());

        }
    }
}