﻿namespace AIS.Func
{
    internal class CorrectSumm
    {
        
    }
}
