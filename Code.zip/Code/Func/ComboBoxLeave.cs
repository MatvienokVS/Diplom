﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIS.Func
{
    // TODO устаревший класс, удалить
    internal class ComboBoxLeave
    {
        private ComboBox comboBox;
        private string phrase;

        public ComboBoxLeave(ComboBox comboBox, string phrase)
        {
            this.comboBox = comboBox;
            this.phrase = phrase;
            Initialize();
        }

        private void Initialize()
        {
            // Установка подсказки
            comboBox.Text = phrase;
            // Установка цвета подсказки
            comboBox.ForeColor = Color.Gray;

            // Подключение обработчиков событий

            comboBox.Leave += ComboBox_Leave;
        }


        private void ComboBox_Leave(object sender, EventArgs e)
        {
            // Восстановление подсказки, если ComboBox остается пустым
            if (string.IsNullOrWhiteSpace(comboBox.Text))
            {
                comboBox.Text = phrase;
                comboBox.ForeColor = Color.Gray;
            }
            else
            {
                comboBox.ForeColor = Color.Black;
            }
        }
    }  
}
