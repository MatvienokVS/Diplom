﻿using Microsoft.Data.SqlClient;
using OfficeOpenXml;

namespace AIS.Func
{
    internal class ExcelDataLoader
    {
        private string connectionString;

        public ExcelDataLoader(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public void LoadDataFromExcel(string filePath, string sheetName)
        {
            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                var workbook = package.Workbook;
                var worksheet = workbook.Worksheets[sheetName];

                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    for (int row = worksheet.Dimension.Start.Row + 1; row <= worksheet.Dimension.End.Row; row++)
                    {
                        // Получите значения ячеек из листа Excel
                        var value1 = worksheet.Cells[row, 1].Value?.ToString();
                        var value2 = worksheet.Cells[row, 2].Value?.ToString();

                        // Ваш код для обработки и сохранения данных в базе данных
                        SaveDataToDatabase(connection, value1, value2);
                    }
                }
            }
        }

        private void SaveDataToDatabase(SqlConnection connection, string value1, string value2)
        {
            using (var command = new SqlCommand("INSERT INTO YourTableName (Column1, Column2) VALUES (@Value1, @Value2)", connection))
            {
                command.Parameters.AddWithValue("@Value1", value1);
                command.Parameters.AddWithValue("@Value2", value2);
                command.ExecuteNonQuery();
            }
        }
    }
}
