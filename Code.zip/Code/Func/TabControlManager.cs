﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIS.Func
{
    internal class TabControlManager
    {
        public static void CloseCurrentTab(Control control)
        {
            TabPage selectedTabPage = control.Parent as TabPage;
            if (selectedTabPage != null)
            {
                TabControl tabControl = selectedTabPage.Parent as TabControl;
                if (tabControl != null)
                {
                    tabControl.TabPages.Remove(selectedTabPage);
                }
            }
        }
    }
}
