﻿namespace AIS.Func
{
    public class WindowMover
    {
        private readonly Control _form;
        private Point _lastPoint;

        public WindowMover(Control form)
        {
            _form = form;
            _form.MouseDown += Form_MouseDown;
            _form.MouseMove += Form_MouseMove;
        }

        private void Form_MouseDown(object sender, MouseEventArgs e)
        {
            _lastPoint = e.Location;
        }

        private void Form_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _form.Left += e.X - _lastPoint.X;
                _form.Top += e.Y - _lastPoint.Y;
            }
        }
    }
}
