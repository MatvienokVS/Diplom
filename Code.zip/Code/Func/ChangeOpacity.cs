﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIS.Func
{
    public class ChangeOpacity
    {

        private readonly Form _form;

        public ChangeOpacity(Form form)
        {
            _form = form;
        }

        public async Task _changeOpacity()
        {
            for (_form.Opacity = 0; _form.Opacity <= 100; _form.Opacity += 0.10)
            {
                await Task.Delay(1);
            }
        }
    }
}
