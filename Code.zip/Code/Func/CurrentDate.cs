﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIS.Func
{
    public class CurrentDate
    {
        public static void SetCurrentDate(Label nameLabel)
        {
            DateTime currentDate = DateTime.Now;
            string dateString = "Сегодня " + currentDate.ToString("dd.MM.yyyy");
            nameLabel.Text = dateString;
        }
    }
}
