﻿using AIS.Query;

namespace AIS.Func
{
    // TODO устаревший класс, удалить
    //internal class ComboBoxEnter
    //{
    //    private ComboBox comboBox;
    //    private string phrase;

    //    public ComboBoxEnter(ComboBox comboBox, string phrase)
    //    {
    //        this.comboBox = comboBox;
    //        this.phrase = phrase;
    //        Initialize();
    //    }

    //    private void Initialize()
    //    {
    //        // Установка подсказки
    //        comboBox.Text = phrase;
    //        // Установка цвета подсказки
    //        comboBox.ForeColor = Color.Gray;

    //        // Подключение обработчиков событий
    //        comboBox.Enter += ComboBox_Enter;

        //}

        //private void ComboBox_Enter(object sender, EventArgs e)
        //{
        //    // Очистка подсказки при фокусировке на ComboBox
        //    if (comboBox.Text == phrase)
        //    {
        //        comboBox.Text = "";
        //        comboBox.ForeColor = Color.Gray;
        //    }
        //}

    //}


    // TODO почитать что такое extensions
    static internal class ComboBoxExtensions
    {
        public static void FillDefaultValue(this ComboBox comboBox, string phrase)
        {
            // Установка подсказки
            comboBox.Text = phrase;
            // Установка цвета подсказки
            comboBox.ForeColor = Color.Gray;

            // Подключение обработчиков событий
            comboBox.Enter += (object sender, EventArgs e) =>
            {
                if (comboBox.Text == phrase)
                {
                    comboBox.Text = "";
                    comboBox.ForeColor = Color.Black;
                }             
            };

            comboBox.Leave += (object sender, EventArgs e) =>
            {
                // Восстановление подсказки, если ComboBox остается пустым
                if (string.IsNullOrWhiteSpace(comboBox.Text))
                {
                    comboBox.Text = phrase;
                    comboBox.ForeColor = Color.Gray;
                }
                else
                {
                    comboBox.ForeColor = Color.Black;
                }
            };
        }
    }
}
