﻿//#define sborka_dla_client1
namespace AIS.DB
{
    // TODO почитать про иммутабельность
    internal class Config
    {
        protected static string db_hostname_debug = "MATVIENOKHOME";
        protected static string db_hostname_debugMobile = "MATVIENOKVS";
        protected static string db_hostname_production = "VRT";
        protected static string db_user = "mat";
        protected static string db_password = "mat1234";
        protected static string db_name = "ais_osnova";

        public static string DB_hostname
        {
            get
            {
#if DEBUG
        return db_hostname_debug;
#elif DEBUGMOBILE
                return db_hostname_debugMobile;
#else
        return db_hostname_production;
#endif
            }
        }
        public static string DB_user
        {
            get => db_user;
        }
        public static string DB_password
        {
            get => db_password;
        }
        public static string DB_name
        {
            get => db_name;
        }


    }
}
