﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace AIS.DB
{
    internal class DB
    {
        private readonly SqlConnection _connection;

        public bool Connect()
        {
            if (_connection.State != ConnectionState.Open)
                _connection.Open();

            return _connection.State == System.Data.ConnectionState.Open;
        }


        public int ExecuteNonQuery(string sql)
        {
            try
            {
                SqlCommand sqlCommand = new(sql, _connection);
                return sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
                return 0;
            }
        }


        public DataTable ExecuteDataTable(string sql)
        {
            DataTable dataTable = new();
            try
            {
                SqlDataAdapter dataAdapter = new(sql, _connection);
                dataAdapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
            }
            return dataTable;
        }

        public void ExecuteDataCombobox(string sql, ComboBox comboBox, string column)
        {
            try
            {
                SqlCommand cmd = new(sql, _connection);
                SqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    string name = dataReader[column].ToString();
                    comboBox.Items.Add(name);
                }

                dataReader.Close();
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
            }
        }


        /// <summary>
        /// Последняя ошибка
        /// </summary>
        public string LastError { get; set; }

        public void DisConnect()
        {
            _connection.Close();
        }

        public DB(string server, string database, string username, string password)
        {
            string connectionString = $"Data Source={server};" +
                                      $"Initial Catalog={database};" +
                                      $"Uid={username}; Password={password}; " +
                                      $"Trust Server Certificate = True";
            _connection = new SqlConnection(connectionString);
        }

    }
}